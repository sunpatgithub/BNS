﻿using HR.WebApi.DAL;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using HR.WebApi.ModelView;
using HR.WebApi.Repositories;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace HR.WebApi.Common
{
    public class Documents : IDocuments
    {
        private readonly string DocumentPath = AppSettings.DocumentPath;
        private readonly string DocumentPathBackup = AppSettings.DocumentPathBackup;

        public Documents()
        {
           
        }

        public bool BackupFile(string fileName,string folderName)
        {
            bool blnBackUpFile = false;
            try
            {
                string[] strFiles = Directory.GetFiles(GetPath(folderName), fileName);

                // Copy the files and overwrite destination files if they already exist.
                foreach (string strFile in strFiles)
                {
                    var saveBackUpFile = GetBackupPath(folderName);

                    //if folder not exist then Create folder
                    if (!Directory.Exists(saveBackUpFile))
                        Directory.CreateDirectory(saveBackUpFile);

                    // Use static Path methods to extract only the file name from the path.
                    fileName = Path.GetFileName(strFile);
                    fileName = GenerateFileName(fileName);
                    saveBackUpFile = Path.Combine(saveBackUpFile, fileName);
                    File.Copy(strFile, saveBackUpFile, true);
                }
                blnBackUpFile = true;
            }
            catch (Exception ex)
            {
                blnBackUpFile = false;
                throw ex;
            }
            return blnBackUpFile;
        }

        public bool DeleteFile(string folderName,string fileName)
        {
            bool blnDeleteFile = false;
            try
            {
               var vPathToSave = GetPath(folderName);
                var vFullPath = Path.Combine(vPathToSave, fileName);
                File.Delete(vFullPath);
            }
            catch (Exception ex)
            {
                blnDeleteFile = false;
                throw ex;
            }
            return blnDeleteFile;            
        }

        public string DownloadFile(string emp_Doc_Id)
        {
            string strFilePath;
            try
            {
                //strFilePath = GetPath(emp_Id);
                //if (!string.IsNullOrEmpty(fileName))
                //    strFilePath = Path.Combine(strFilePath, fileName);
                strFilePath = Path.Combine(DocumentPath, emp_Doc_Id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return strFilePath;
        }

        public string GenerateFileName(string fileName)
        {
            try
            {
                string strFileName = string.Empty;
                string[] strName = fileName.Split('.');
                strFileName = strName[0] + "_" + DateTime.Now.ToString("yyyyMMdd") + "." + strName[strName.Length - 1];
                return strFileName;
            }
            catch (Exception ex)
            {

                throw ex;
            }            
        }

        public string GetBackupPath(string folderName)
        {
            try
            {
                return Path.Combine(DocumentPathBackup, folderName);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }

        public string GetPath(string folderName)
        {
            try
            {
                return Path.Combine(DocumentPath, folderName);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }

        public bool isFileExists(string fileName)
        {
            try
            {
                bool blnFileExists = false;
                if (File.Exists(fileName))
                    blnFileExists = true;
                return blnFileExists;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            
        }

        public string UploadFile(IFormFile file, string folderPath)
        {
            string StrValue = string.Empty;
            try
            {
                var vpathToSave = GetPath(folderPath);

                //if folder not exist then Create folder
                if (!Directory.Exists(vpathToSave))
                    Directory.CreateDirectory(vpathToSave);

               
                    if (file.Length > 0)
                    {
                        var vfileName = file.FileName;
                        var vfullPath = Path.Combine(vpathToSave, vfileName);

                        if (isFileExists(vfullPath))
                            BackupFile(vfileName, folderPath);

                        using (var stream = new FileStream(vfullPath, FileMode.Create))
                        {
                            file.CopyTo(stream);
                        }
                        StrValue = Path.Combine(folderPath, vfileName); 
                    }
                
            }
            catch (Exception ex)
            {
                StrValue = "";
                throw ex;
            }
            return StrValue;
        }       
    }
}
