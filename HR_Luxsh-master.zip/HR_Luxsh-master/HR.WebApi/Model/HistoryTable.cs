﻿using System;
using System.ComponentModel.DataAnnotations;

namespace HR.WebApi.Model
{
    public class HistoryTable
    {
        [Key]
        public int Id { get; set; }
        public string TableName { get; set; }
        public string Action { get; set; }
        public string OldValue { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedOn { get; set; }
    }
}