﻿using System;
using System.ComponentModel.DataAnnotations;

namespace HR.WebApi.Model
{
    public class Raf_Approved
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        public int Raf_Id { get; set; }
        
        [Required]
        public int Raf_Approval_Id { get; set; }
        
        [Required]
        public int Company_Id { get; set; }
        
        [Required]
        public int Dept_Id { get; set; }
        
        [Required]
        public int Desig_Id { get; set; }
        
        [MaxLength(1000)]
        public string Description { get; set; }
        
        [Required]
        public int ApprovedBy { get; set; }
        
        public DateTime? ApprovedOn { get; set; }

        [Required]
        public int AddedBy { get; set; }
        
        public DateTime AddedOn { get; set; } = DateTime.Now;
    }
}
