﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HR.WebApi.Model
{
    public class Emp_Leave_Approve_History
    {
        [Key]
        public Int64 emp_leave_audit_id { get; set; }
        public Int64 emp_leave_id { get; set; }
        public string status { get; set; }
        [MaxLength(500)]
        public string Comments { get; set; }
        public int updated_by { get; set; }
        public DateTime updated_on { get; set; }
    }
}
