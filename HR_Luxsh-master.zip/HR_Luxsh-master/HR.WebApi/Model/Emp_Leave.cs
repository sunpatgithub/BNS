﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HR.WebApi.Model
{
    public class Emp_Leave
    {
        [Key]
        public Int64 emp_leave_id { get; set; }
        public Int64 emp_yearly_leave_id { get; set; }
        public DateTime start_date { get; set; }
        public string startdate_leave_type { get; set; }
        public DateTime end_date { get; set; }
        public string enddate_leave_type { get; set; }
        public string status { get; set; }
        public DateTime apply_date { get; set; }
        public int apply_by { get; set; }
        public string Comments { get; set; }
        public double taken_leave { get; set; }
        public Emp_Leave_Approve_History Emp_Leave_Approve_History { get; set; }
    }
}
