﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HR.WebApi.Model
{
    public class Report_Builder
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        public int Report_Group_Id { get; set; }
        
        [Required]
        [StringLength(2000, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 3)]
        [RegularExpression(@"\b[a-z_]+\b", ErrorMessage = "Value must contain any of the following : lower case (a-z)")]
        public string Name { get; set; }

        [MaxLength(2000)]
        public string DisplayName { get; set; }
        
        public string QueryParam { get; set; }
        
        public int AddedBy { get; set; }
        
        public DateTime AddedOn { get; set; } = DateTime.Now;
       
    }
}
