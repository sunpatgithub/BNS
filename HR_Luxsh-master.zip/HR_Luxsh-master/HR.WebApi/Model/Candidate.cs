﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HR.WebApi.Model
{
    public class Candidate
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 3)]
        [RegularExpression(@"\b[a-zA-Z]+\b",
            ErrorMessage = "Value must contain any of the following without space: upper case (A-Z), lower case (a-z)")]
        public string FirstName { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 1)]
        [RegularExpression(@"^[a-zA-Z]{1,100}$",
            ErrorMessage = "Value must contain any of the following without space: upper case (A-Z), lower case (a-z)")]
        public string MiddleName { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 3)]
        [RegularExpression(@"\b[a-zA-Z]+\b",
            ErrorMessage = "Value must contain any of the following without space: upper case (A-Z), lower case (a-z)")]
        public string LastName { get; set; }

        [Required]
        [StringLength(200, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 5)]
        public string EMail { get; set; }

        [Required]
        [Phone]
        [StringLength(50, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 9)]
        public string Mobile { get; set; }
        [StringLength(1000, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 3)]
        public string TotalExperience { get; set; }
        [StringLength(2000, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 3)]
        public string ReferenceFrom { get; set; }
        public int? ReferenceBy { get; set; }

        [Required]
        public DateTime JobStartDate { get; set; }
        [StringLength(2000, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 3)]
        public string Notes { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedOn { get; set; } = DateTime.Now;
    }
}
