﻿using System;
using System.ComponentModel.DataAnnotations;


namespace HR.WebApi.Model
{
    public class Emp_Yearly_Leave
    {
        [Key]
        public Int64 emp_yearly_leave_id { get; set; }
        public int leave_type_id { get; set; }
        public int emp_id { get; set; }
        public string emp_type { get; set; }
        public double assigned_leave { get; set; }
        public double emp_takenleave { get; set; }
        public double emp_remaining_leave { get; set; }
        public DateTime schedule_date { get; set; }
        public string leave_year { get; set; }
    }
}
