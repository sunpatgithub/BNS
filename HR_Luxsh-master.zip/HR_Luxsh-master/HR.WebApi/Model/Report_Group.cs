﻿using System;
using System.ComponentModel.DataAnnotations;

namespace HR.WebApi.Model
{
    public class Report_Group
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(2000, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 3)]
        [RegularExpression(@"\b[a-z_]+\b", ErrorMessage = "Value must contain any of the following without space: lower case (a-z), underscore(_)")]
        public string TableName { get; set; }

        [MaxLength(2000)]
        public string DisplayName { get; set; }

        [Required]
        public int AddedBy { get; set; }

        public DateTime AddedOn { get; set; } = DateTime.Now;
    }
}
