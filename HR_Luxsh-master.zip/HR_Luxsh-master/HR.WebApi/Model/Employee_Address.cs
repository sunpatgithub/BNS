﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace HR.WebApi.Model
{
    public class Employee_Address
    {
        [Key]
        public int Emp_Address_Id { get; set; }
        [Required]
        public int Emp_Id { get; set; }
       
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 3)]
        public string Address_Type { get; set; }
        
        [Required]
        [StringLength(200, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 5)]
        public string Address1 { get; set; }
        
        [StringLength(200, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 3)]
        public string Address2 { get; set; }
        
        [StringLength(200, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 3)]
        public string Address3 { get; set; }
       
        [StringLength(200, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 3)]
        public string Address4 { get; set; }
        
        [StringLength(200, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [RegularExpression(@"\b[\d\s-]+\b",ErrorMessage = "Value must contain any of the following:  number(0-9), dash(-)")]
        public string PostCode { get; set; }
        
        [Required]
        [StringLength(200, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 5)]
        [RegularExpression(@"\b[a-zA-Z\s]+\b",ErrorMessage = "Value must contain any of the following : upper case (A-Z), lower case (a-z)")]       
        public string City { get; set; }
        
        [Required]
        [StringLength(200, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 5)]
        [RegularExpression(@"\b[a-zA-Z\s]+\b",ErrorMessage = "Value must contain any of the following : upper case (A-Z), lower case (a-z)")]
        public string State { get; set; }
        
        [Required]
        [StringLength(200, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 5)]
        [RegularExpression(@"\b[a-zA-Z\s]+\b",ErrorMessage = "Value must contain any of the following : upper case (A-Z), lower case (a-z)")]
        public string Country { get; set; }

        [StringLength(20, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 5)]
        [Phone]
        public string LandlineNo { get; set; }
        public Int16? isDefault { get; set; }
        public int? Emp_Doc_Id { get; set; }

        [RegularExpression(@"\b[0-1]{1}\b", ErrorMessage = "Value must be 0 or 1.")]
        public Int16 isActive { get; set; }
        public int AddedBy { get; set; }

        public DateTime AddedOn { get; set; } = DateTime.Now;

        public int? UpdatedBy { get; set; }

        public DateTime? UpdatedOn { get; set; }
    }
}
