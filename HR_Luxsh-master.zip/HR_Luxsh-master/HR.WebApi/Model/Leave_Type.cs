﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace HR.WebApi.Model
{
    public class Leave_Type
    {
        [Key]
        public int leave_type_id { get; set; }

        [Required, MaxLength(45)]
        public string leave_type { get; set; }
        public decimal no_of_leave { get; set; }
        public int is_carry_forward { get; set; }
        public decimal is_encashment_percentage { get; set; }
        public int is_active { get; set; }
    }
}
