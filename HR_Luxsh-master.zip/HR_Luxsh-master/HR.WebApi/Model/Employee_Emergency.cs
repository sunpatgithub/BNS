﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HR.WebApi.Model
{
    public class Employee_Emergency
    {
        [Key]
        public int Emp_Emergency_Id { get; set; }
        [Required]
        public int Emp_Id { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 3)]
        [RegularExpression(@"\b[a-zA-Z\s]+\b",ErrorMessage = "Value must contain any of the following without space: upper case (A-Z), lower case (a-z)")]
        public string ContactName { get; set; }
        
        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 10)]
        [Phone]
        public string ContactNo { get; set; }       

        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 3)]
        [RegularExpression(@"\b[a-zA-Z]+\b",ErrorMessage = "Value must contain any of the following without space: upper case (A-Z), lower case (a-z)")]
        public string Relationship { get; set; }
        public Int16? isDefault { get; set; }

        [RegularExpression(@"\b[0-1]{1}\b", ErrorMessage = "Value must be 0 or 1.")]
        public Int16 isActive { get; set; }
        public int AddedBy { get; set; }

        public DateTime AddedOn { get; set; } = DateTime.Now;

        public int? UpdatedBy { get; set; }

        public DateTime? UpdatedOn { get; set; }
    }
}
