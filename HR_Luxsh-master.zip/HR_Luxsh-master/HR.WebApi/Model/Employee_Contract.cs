﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HR.WebApi.Model
{
    public class Employee_Contract
    {
        [Key]
        public int Emp_Contract_Id { get; set; }
        public int? Contract_Id { get; set; }
        [Required]
        public int Emp_Id { get; set; }
        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 3)]
        [RegularExpression(@"\b[\w]+\b",ErrorMessage = "Value must contain any of the following without space: upper case (A-Z), lower case (a-z), number(0-9)")]
        public string Emp_Contract_Code { get; set; }
        [Required]
        [StringLength(500, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 3)]
        [RegularExpression(@"\b[a-zA-Z\s]+\b",ErrorMessage = "Value must contain any of the following without space: upper case (A-Z), lower case (a-z)")]
        public string Emp_Contract_Name { get; set; }
        public int? Emp_Contract_HoursDaily { get; set; }
        public int? Emp_Contract_HoursWeekly { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 3)]
        [RegularExpression(@"\b[a-zA-Z]+\b",ErrorMessage = "Value must contain any of the following without space: upper case (A-Z), lower case (a-z)")]
        public string Emp_Contract_Days { get; set; }

        [StringLength(500, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 3)]
        [RegularExpression(@"\b[\w]+\b",ErrorMessage = "Value must contain any of the following without space: upper case (A-Z), lower case (a-z), number(0-9)")]
        public string Emp_Contract_Type { get; set; }
        [Required]
        public DateTime Emp_Contract_Start { get; set; }
        [Required]
        public DateTime Emp_Contract_End { get; set; }
        public int? Emp_Doc_Id { get; set; }
        public Int16? isRequired { get; set; }
        [MaxLength(2000)]
        public string Notes { get; set; }
        [MaxLength(20)]
        public string Version_Id { get; set; }

        [RegularExpression(@"\b[0-1]{1}\b", ErrorMessage = "Value must be 0 or 1.")]
        public Int16 isActive { get; set; }
        public int AddedBy { get; set; }

        public DateTime AddedOn { get; set; } = DateTime.Now;

        public int? UpdatedBy { get; set; }

        public DateTime? UpdatedOn { get; set; }
    }
}
