﻿using HR.WebApi.DAL;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using HR.WebApi.ModelView;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace HR.WebApi.Activities
{
    public class PayrollActivity : IActivity<EmployeeView>
    {
        private readonly ApplicationDbContext adbContext;

        public PayrollActivity(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }

        public async Task Execute(EmployeeView entity, string Status)
        {
            try
            {
                var vCount = adbContext.employee.Where(w => w.Emp_Id == entity.Emp_Id).ToList();
                if (vCount.Count() > 0)
                {
                    string strdescription = "New Employee " + Status + " : " + entity.emp_basicinfo.FirstName + " " + entity.emp_basicinfo.LastName;

                    var vList = new Task_Activity
                    {
                        Emp_Id = entity.Emp_Id,
                        Description = strdescription,
                        Activity = Status,
                        Notes = "",
                        Status = "Open",
                        AssignTo = 0,
                        AssignDept = 1,
                        AssignEmail = "",
                        isActive = 1,
                        AddedBy = entity.AddedBy,
                        AddedOn = DateTime.Now
                    };
                    adbContext.task_activity.Add(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
