﻿using HR.WebApi.DAL;
using HR.WebApi.Exceptions;
using HR.WebApi.ModelView;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HR.WebApi.Activities
{
    public class PayrollService
    {
        private readonly ApplicationDbContext adbContext;
        public PayrollService(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }
        public async Task<IEnumerable<PayrollView>> GetDetails(string Status)
        {
            try
            {
                var vList = (from ta in adbContext.task_activity
                             join emp in adbContext.employee on ta.Emp_Id equals emp.Emp_Id into zemp
                             from emp in zemp.DefaultIfEmpty()

                             join empbasic in adbContext.employee_basicinfo on ta.Emp_Id equals empbasic.Emp_Id into zempbasic
                             from empbasic in zempbasic.DefaultIfEmpty()
                             
                             join empref in adbContext.employee_reference on ta.Emp_Id equals empref.Emp_Id into zempref
                             from empref in zempref.DefaultIfEmpty()
                             
                             join empadd in adbContext.employee_address on ta.Emp_Id equals empadd.Emp_Id into zempadd
                             from empadd in zempadd.DefaultIfEmpty()
                             
                             join empsal in adbContext.employee_salary on ta.Emp_Id equals empsal.Emp_Id into zempsal
                             from empsal in zempsal.DefaultIfEmpty()
                             
                             join empcontract in adbContext.employee_contract on ta.Emp_Id equals empcontract.Emp_Id into zempct
                             from empcontract in zempct.DefaultIfEmpty()
                             
                             //join empcontact in adbContext.employee_contact on emp.Emp_Id equals empcontact.Emp_Id into zempc
                             //from empcontact in zempc.DefaultIfEmpty()
                             
                             join empbank in adbContext.employee_bank on ta.Emp_Id equals empbank.Emp_Id into zempbank
                             from empbank in zempbank.DefaultIfEmpty()
                             
                             join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id into zcmp
                             from cmp in zcmp.DefaultIfEmpty()
                             
                             join dept in adbContext.department on emp.Dept_Id equals dept.Dept_Id into zdept
                             from dept in zdept.DefaultIfEmpty()

                             join Desig in adbContext.designation on emp.Desig_Id equals Desig.Desig_Id into zdesg
                             from Desig in zdesg.DefaultIfEmpty()

                             where ta.Status == Status
                             select new PayrollView
                             {
                                 Company_Name = Convert.ToString(cmp.Company_Name),
                                 Dept_Name = Convert.ToString(dept.Dept_Name),

                                 EmpReference = Convert.ToString(empref.Ref_Name),
                                 WorksReference = string.Empty,

                                 Title = Convert.ToString(empbasic.Title),
                                 Initial = string.Empty,
                                 FirstName = Convert.ToString(empbasic.FirstName),
                                 LastName = Convert.ToString(empbasic.LastName),
                                 Address1 = Convert.ToString(empadd.Address1),
                                 Address2 = Convert.ToString(empadd.Address2),
                                 Address3 = Convert.ToString(empadd.Address3),
                                 Address4 = Convert.ToString(empadd.Address4),
                                 Address5 = string.Empty,
                                 PostCode = Convert.ToString(empadd.PostCode),

                                 //Email = adbContext.employee_contact.Where(t => t.Emp_Id == ta.Emp_Id && t.Contact_Value.Contains('@')).DefaultIfEmpty().ToString(),
                                 //Number = adbContext.employee_contact.Where(t => t.Emp_Id == ta.Emp_Id).DefaultIfEmpty().ToString(),
                                 //Email  = empcontact.Contact_Value.Contains('@').ToString(),
                                 Email = Convert.ToString(adbContext.employee_contact.Where(t => t.Emp_Id == ta.Emp_Id && t.Contact_Type == "Email").SingleOrDefault().Contact_Value),
                                 Number = Convert.ToString(adbContext.employee_contact.Where(t => t.Emp_Id == ta.Emp_Id && t.Contact_Type == "PhoneNo").SingleOrDefault().Contact_Value),
                                 Gender = Convert.ToString(empbasic.Gender),
                                 MaritalStatus = string.Empty,
                                 DOB = Convert.ToString(empbasic.DOB),

                                 WorkStartDate = Convert.ToString(emp.JoiningDate),
                                 WorkEndDate = string.Empty,
                                 NiNo = Convert.ToString(emp.NiNo + " " + emp.NiCategory),
                                 TaxCode = string.Empty,
                                 Wk1Mth1 = string.Empty,
                                 Basis = string.Empty,

                                 Pension1 = string.Empty,
                                 Pension2 = string.Empty,
                                 Pension3 = string.Empty,
                                 Pension4 = string.Empty,
                                 Pension5 = string.Empty,

                                 PaymentMethod = string.Empty,
                                 PaymentFrequency = string.Empty,

                                 GrossSalary = Convert.ToString(empsal.Salary),
                                 SalaryPerPeriod = string.Empty,

                                 ContractedHours = Convert.ToString(empcontract.Emp_Contract_HoursDaily),
                                 ContractedHoursPerPeriod = Convert.ToString(empcontract.Emp_Contract_HoursWeekly),
                                 AccessLevel = string.Empty,
                                 DirectorStatus = string.Empty,
                                 DirectorStatusDate = string.Empty,
                                 Notes = string.Empty,
                                 RefContact = Convert.ToString(empref.Ref_Name),
                                 RefContactRelation = Convert.ToString(empref.Ref_Relationship),
                                 RefContactNo = Convert.ToString(empref.Ref_ContactNo),
                                
                                 BankAcc_Number = Convert.ToString(empbank.Account_No),
                                 BankAcc_Name = Convert.ToString(empbank.Account_Holder),
                                 BankAcc_Type = Convert.ToString(empbank.Account_Type),
                                 SortCode = Convert.ToString(empbank.Bank_Code),
                                 Building_Soc = string.Empty,
                                 BacsRef = string.Empty,
                                 BankName = Convert.ToString(empbank.Bank_Name),
                                 BankAdd_1 = string.Empty,
                                 BankAdd_2 = string.Empty,
                                 BankAdd_3 = string.Empty,
                                 BankAdd_4 = string.Empty,
                                 BankAdd_5 = string.Empty,
                                 BankPostcode = string.Empty,
                                 BankTelephone = string.Empty,
                                 BankFax = string.Empty,
                                 Mobile = string.Empty,

                                 JobTitle = Convert.ToString(Desig.Desig_Name),
                                 EmpType = string.Empty,

                                 SendPayslip = string.Empty,
                                 Confirmed_Date = string.Empty,
                                 //PayslipEmail = adbContext.employee_contact.AsQueryable().Where(t => t.Emp_Id == ta.Emp_Id && t.Contact_Value.Contains('@')).DefaultIfEmpty().ToString(),
                                 PayslipEmail = Convert.ToString(adbContext.employee_contact.Where(t => t.Emp_Id == ta.Emp_Id && t.Contact_Type == "Email").FirstOrDefault().Contact_Value),
                                 PayslipPassword = Convert.ToString(empbasic.DOB.Value.Date)
                             }).ToList();

                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ToogleStatus(int id, string status)
        {
            try
            {
                var vList = adbContext.task_activity.Where(w => w.Id == id && w.Status != status).SingleOrDefault();
                if (vList != null)
                {
                    vList.Status = status;
                    vList.UpdatedOn = DateTime.Now;
                    adbContext.task_activity.Update(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
                else
                {
                    throw new RecoredNotFoundException("Data Not Available");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}