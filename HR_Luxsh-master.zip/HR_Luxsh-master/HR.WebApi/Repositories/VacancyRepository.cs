﻿using HR.WebApi.DAL;
using HR.WebApi.Exceptions;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using HR.WebApi.ModelView;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading.Tasks;

namespace HR.WebApi.Repositories
{
    public class VacancyRepository<T> : ICommonRepository<VacancyView>, ICommonQuery<VacancyView>
    {
        private readonly ApplicationDbContext adbContext;
        public VacancyRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }

        public async Task<IEnumerable<VacancyView>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<VacancyView> vList;
                if (RecordLimit > 0)
                {
                    vList = (from vac in adbContext.vacancy
                             join comp in adbContext.company on vac.Company_Id equals comp.Company_Id
                             join dept in adbContext.department on vac.Dept_Id equals dept.Dept_Id
                             join site in adbContext.site on vac.Site_Id equals site.Site_Id
                             select new VacancyView
                             {
                                 Id = vac.Id,

                                 Company_Id = vac.Company_Id,
                                 Company_Name = comp.Company_Name,

                                 Site_Id = vac.Site_Id,
                                 Site_Name = site.Site_Name,

                                 Dept_Id = vac.Dept_Id,
                                 Dept_Name = dept.Dept_Name,

                                 JobTitle = vac.JobTitle,
                                 Description = vac.Description,
                                 Notes = vac.Notes,
                                 ValidFrom = vac.ValidFrom,
                                 ValidUpto = vac.ValidUpto,
                                 NoOfPositions = vac.NoOfPositions,
                                 isActive = vac.isActive
                             }).Take(RecordLimit).ToList();
                }
                else
                {
                    vList = (from vac in adbContext.vacancy
                             join comp in adbContext.company on vac.Company_Id equals comp.Company_Id
                             join dept in adbContext.department on vac.Dept_Id equals dept.Dept_Id
                             join site in adbContext.site on vac.Site_Id equals site.Site_Id
                             select new VacancyView
                             {
                                 Id = vac.Id,

                                 Company_Id = vac.Company_Id,
                                 Company_Name = comp.Company_Name,

                                 Site_Id = vac.Site_Id,
                                 Site_Name = site.Site_Name,

                                 Dept_Id = vac.Dept_Id,
                                 Dept_Name = dept.Dept_Name,

                                 JobTitle = vac.JobTitle,
                                 Description = vac.Description,
                                 Notes = vac.Notes,
                                 ValidFrom = vac.ValidFrom,
                                 ValidUpto = vac.ValidUpto,
                                 NoOfPositions = vac.NoOfPositions,
                                 isActive = vac.isActive
                             }).ToList();
                }
                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<VacancyView>> Get(int id)
        {
            try
            {
                IEnumerable<VacancyView> vList;
                vList = (from vac in adbContext.vacancy
                         join comp in adbContext.company on vac.Company_Id equals comp.Company_Id
                         join dept in adbContext.department on vac.Dept_Id equals dept.Dept_Id
                         join site in adbContext.site on vac.Site_Id equals site.Site_Id
                         where vac.Id == id
                         select new VacancyView
                         {
                             Id = vac.Id,

                             Company_Id = vac.Company_Id,
                             Company_Name = comp.Company_Name,

                             Site_Id = vac.Site_Id,
                             Site_Name = site.Site_Name,

                             Dept_Id = vac.Dept_Id,
                             Dept_Name = dept.Dept_Name,

                             JobTitle = vac.JobTitle,
                             Description = vac.Description,
                             Notes = vac.Notes,
                             ValidFrom = vac.ValidFrom,
                             ValidUpto = vac.ValidUpto,
                             NoOfPositions = vac.NoOfPositions,
                             isActive = vac.isActive
                         }).ToList();

                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<VacancyView>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            try
            {
                IEnumerable<VacancyView> vList;
                if (String.IsNullOrEmpty(searchValue))
                {
                    //Find with Paging
                    vList = (from vac in adbContext.vacancy
                             join comp in adbContext.company on vac.Company_Id equals comp.Company_Id
                             join dept in adbContext.department on vac.Dept_Id equals dept.Dept_Id
                             join site in adbContext.site on vac.Site_Id equals site.Site_Id
                             select new VacancyView
                             {
                                 Id = vac.Id,

                                 Company_Id = vac.Company_Id,
                                 Company_Name = comp.Company_Name,

                                 Site_Id = vac.Site_Id,
                                 Site_Name = site.Site_Name,

                                 Dept_Id = vac.Dept_Id,
                                 Dept_Name = dept.Dept_Name,

                                 JobTitle = vac.JobTitle,
                                 Description = vac.Description,
                                 Notes = vac.Notes,
                                 ValidFrom = vac.ValidFrom,
                                 ValidUpto = vac.ValidUpto,
                                 NoOfPositions = vac.NoOfPositions,
                                 isActive = vac.isActive
                             }).Skip(pageIndex * pageSize).Take(pageSize).ToList();
                }
                else
                {
                    //Find with Paging & Searching
                    vList = (from vac in adbContext.vacancy.Where(w => new[] { w.JobTitle.ToLower(), w.Description.ToLower(), Convert.ToString(w.NoOfPositions) }.Any(a => a.Contains(searchValue.ToLower())))
                             join comp in adbContext.company on vac.Company_Id equals comp.Company_Id
                             join dept in adbContext.department on vac.Dept_Id equals dept.Dept_Id
                             join site in adbContext.site on vac.Site_Id equals site.Site_Id
                             select new VacancyView
                             {
                                 Id = vac.Id,

                                 Company_Id = vac.Company_Id,
                                 Company_Name = comp.Company_Name,

                                 Site_Id = vac.Site_Id,
                                 Site_Name = site.Site_Name,

                                 Dept_Id = vac.Dept_Id,
                                 Dept_Name = dept.Dept_Name,

                                 JobTitle = vac.JobTitle,
                                 Description = vac.Description,
                                 Notes = vac.Notes,
                                 ValidFrom = vac.ValidFrom,
                                 ValidUpto = vac.ValidUpto,
                                 NoOfPositions = vac.NoOfPositions,
                                 isActive = vac.isActive
                             }).Skip(pageIndex * pageSize).Take(pageSize).ToList();
                }
                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<VacancyView>> GetBy(SearchBy searchBy)
        {
            try
            {
                var vList = (from vac in adbContext.vacancy.Where(String.Format("{0}=={1}", searchBy.FieldName, searchBy.FieldValue))
                             join comp in adbContext.company on vac.Company_Id equals comp.Company_Id
                             join dept in adbContext.department on vac.Dept_Id equals dept.Dept_Id
                             join site in adbContext.site on vac.Site_Id equals site.Site_Id
                             select new VacancyView
                             {
                                 Id = vac.Id,

                                 Company_Id = vac.Company_Id,
                                 Company_Name = comp.Company_Name,

                                 Site_Id = vac.Site_Id,
                                 Site_Name = site.Site_Name,

                                 Dept_Id = vac.Dept_Id,
                                 Dept_Name = dept.Dept_Name,

                                 JobTitle = vac.JobTitle,
                                 Description = vac.Description,
                                 Notes = vac.Notes,
                                 ValidFrom = vac.ValidFrom,
                                 ValidUpto = vac.ValidUpto,
                                 NoOfPositions = vac.NoOfPositions,
                                 isActive = vac.isActive
                             }).Take(searchBy.RecordLimit).ToList();

                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert(VacancyView entity)
        {
            try
            {
                var vList = new Vacancy
                {
                    Company_Id = entity.Company_Id,
                    Site_Id = entity.Site_Id,
                    Dept_Id = entity.Dept_Id,
                    JobTitle = entity.JobTitle,
                    Description = entity.Description,
                    Notes = entity.Notes,
                    ValidFrom = entity.ValidFrom,
                    ValidUpto = entity.ValidUpto,
                    NoOfPositions = entity.NoOfPositions,
                    isActive = entity.isActive,
                    AddedBy = entity.AddedBy,
                    AddedOn = DateTime.Now
                };

                adbContext.vacancy.Add(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Update(VacancyView entity)
        {
            try
            {
                //Update Old Vacancy
                var vList = adbContext.vacancy.Where(x => x.Id == entity.Id).FirstOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.Company_Id = entity.Company_Id;
                vList.Site_Id = entity.Site_Id;
                vList.Dept_Id = entity.Dept_Id;
                vList.JobTitle = entity.JobTitle;
                vList.Description = entity.Description;
                vList.Notes = entity.Notes;
                vList.ValidFrom = entity.ValidFrom;
                vList.ValidUpto = entity.ValidUpto;
                vList.NoOfPositions = entity.NoOfPositions;
                vList.isActive = entity.isActive;
                vList.UpdatedBy = entity.UpdatedBy;
                vList.UpdatedOn = DateTime.Now;

                adbContext.vacancy.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ToogleStatus(int id, short isActive)
        {
            try
            {
                //update flag isActive
                var vList = adbContext.vacancy.Where(w => w.Id == id && w.isActive != isActive).SingleOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.isActive = isActive;
                adbContext.vacancy.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Delete(int id)
        {
            try
            {
                //Delete vacancy
                var vList = adbContext.vacancy.Where(w => w.Id == id).ToList().SingleOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                adbContext.vacancy.Remove(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int RecordCount(string searchValue)
        {
            try
            {
                if (String.IsNullOrEmpty(searchValue))
                {
                    //Find all no of rows
                    var vCount = (from vac in adbContext.vacancy
                                  join comp in adbContext.company on vac.Company_Id equals comp.Company_Id
                                  join dept in adbContext.department on vac.Dept_Id equals dept.Dept_Id
                                  join site in adbContext.site on vac.Site_Id equals site.Site_Id
                                  select vac.Id
                                ).Count();
                    return vCount;
                }
                else
                {
                    //Find no of rows with Searching
                    var vCount = (from vac in adbContext.vacancy.Where(w => new[] { w.JobTitle.ToLower(), w.Description.ToLower(), Convert.ToString(w.NoOfPositions) }.Any(a => a.Contains(searchValue.ToLower())))
                                  join comp in adbContext.company on vac.Company_Id equals comp.Company_Id
                                  join dept in adbContext.department on vac.Dept_Id equals dept.Dept_Id
                                  join site in adbContext.site on vac.Site_Id equals site.Site_Id
                                  select vac.Id
                                ).Count();
                    return vCount;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Exists(VacancyView entity)
        {
            int intCount = 0;
            if (entity.Id > 0) //Update Validation
                intCount = adbContext.vacancy.Where(w => w.Company_Id == entity.Company_Id && w.Site_Id == entity.Site_Id && w.Id != entity.Id && (w.JobTitle == entity.JobTitle)).Count();
            else //Insert Validation
                intCount = adbContext.vacancy.Where(w => w.Company_Id == entity.Company_Id && w.Site_Id == entity.Site_Id && (w.JobTitle == entity.JobTitle)).Count();
            return (intCount > 0 ? true : false);
        }

    }
}
