﻿using HR.WebApi.DAL;
using HR.WebApi.Exceptions;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using HR.WebApi.ModelView;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading.Tasks;

namespace HR.WebApi.Repositories
{
    public class Report_GroupRepository<T> : IReportBuilder<Report_Group>
    {
        private readonly ApplicationDbContext adbContext;

        public Report_GroupRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }

        public async Task<IEnumerable<Report_Group>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<Report_Group> vList;
                if (RecordLimit > 0)
                    vList = adbContext.report_group.Take(RecordLimit).ToList();
                else
                    vList = adbContext.report_group.ToList();
                
                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Report_Group>> Get(int id)
        {
            try
            {
                var vList = adbContext.report_group.Where(w => w.Id == id).ToList();
                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ReturnBy<Report_Group>> GetPaginated(PaginationBy search)
        {
            try
            {
                string strOrder = string.IsNullOrEmpty(search.OrderBy) ? "Id" : search.OrderBy;
                string strWhere = Common.Search.WhereString(search);

                IEnumerable<Report_Group> vReport;
                if (!String.IsNullOrEmpty(search.CommonSearch))
                    vReport = adbContext.report_group.Where(w => new[] { w.TableName, w.DisplayName, Convert.ToString(w.Id)}.Any(a => a.Contains(search.CommonSearch.ToLower()))).OrderBy(strOrder).ToList();

                else
                    vReport = adbContext.report_group.Where(strWhere).OrderBy(strOrder).ToList();

                ReturnBy<Report_Group> vList = new ReturnBy<Report_Group>()
                {
                    list = vReport.Skip(search.PageIndex * search.PageSize).Take(search.PageSize).ToList(),
                    RecordCount = vReport.Count()
                };

                if (vList.list == null || vList.RecordCount == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert(Report_Group entity)
        {
            try
            {
                adbContext.report_group.Add(entity);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Update(Report_Group entity)
        {
            try
            {
                var vList = adbContext.report_group.Where(x => x.Id == entity.Id).FirstOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.TableName = entity.TableName;
                vList.DisplayName = entity.DisplayName;

                adbContext.report_group.Update(vList);

                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Delete(int id)
        {
            try
            {
                //Delete Report_Group
                var vList = adbContext.report_group.Where(w => w.Id == id).ToList().SingleOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                adbContext.report_group.Remove(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public bool Exists(Report_Group entity)
        {
            try
            {
                int intCount = 0;
                //if (entity.Id > 0)
                //    intCount = adbContext.report_group.Where(w => w.Id != entity.Id && (w.TableName == entity.TableName)).Count();
                //else
                intCount = adbContext.report_group.Where(w =>w.TableName == entity.TableName).Count();
                return (intCount > 0 ? true : false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
