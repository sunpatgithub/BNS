﻿using HR.WebApi.DAL;
using HR.WebApi.Exceptions;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace HR.WebApi.Repositories
{
    public class CandidateRepository<T> : ICommonRepository<Candidate>
    {
        private readonly ApplicationDbContext adbContext;

        public CandidateRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }

        public async Task<IEnumerable<Candidate>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<Candidate> vList;
                if (RecordLimit > 0)
                    vList = adbContext.candidate.Take(RecordLimit).ToList();
                else
                    vList = adbContext.candidate.ToList();

                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Candidate>> Get(int id)
        {
            try
            {
                IEnumerable<Candidate> lstCandidate = adbContext.candidate.Where(w => w.Id == id).ToList();
                if (lstCandidate == null || lstCandidate.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(lstCandidate);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Candidate>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            try
            {
                IEnumerable<Candidate> vList;
                if (String.IsNullOrEmpty(searchValue))
                    vList = adbContext.candidate.Skip(pageIndex * pageSize).Take(pageSize).ToList();
                else
                    vList = adbContext.candidate.Where(w => new[] { w.FirstName.ToLower(), w.MiddleName.ToLower(), w.LastName.ToLower(), w.EMail.ToLower(), w.Mobile.ToLower(), w.TotalExperience.ToLower(), w.ReferenceFrom.ToLower(), w.Notes.ToLower() }.Any(a => a.Contains(searchValue.ToLower()))).Skip(pageIndex * pageSize).Take(pageSize).ToList();

                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Data Not Available");
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert(Candidate entity)
        {
            try
            {
                entity.AddedOn = DateTime.Now;

                adbContext.candidate.Add(entity);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Update(Candidate entity)
        {
            try
            {
                //Update Old Candidate
                Candidate lstCandidate = new Candidate();
                lstCandidate = adbContext.candidate.Where(x => x.Id == entity.Id).FirstOrDefault();
                if (lstCandidate == null)
                    throw new RecoredNotFoundException("Data Not Available");

                    adbContext.candidate.Update(entity);

                    await Task.FromResult(adbContext.SaveChanges());                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ToogleStatus(int id, Int16 isActive)
        {
            try
            {
                //update flag isActive=0
                            
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Delete(int id)
        {
            try
            {
                //Delete Designation
                var vList = adbContext.candidate.Where(w => w.Id == id).SingleOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                    adbContext.candidate.Remove(vList);
                    await Task.FromResult(adbContext.SaveChanges());
               
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Exists(Candidate entity)
        {
            try
            {
                int intCount = 0;
                if (entity.Id > 0)  //Update Validation
                    intCount = adbContext.candidate.Where(w => w.Id != entity.Id && (w.FirstName == entity.FirstName && w.MiddleName == entity.MiddleName && w.LastName == entity.LastName)).Count();
                else  //Insert Validation
                    intCount = adbContext.candidate.Where(w => w.FirstName == entity.FirstName && w.MiddleName == entity.MiddleName && w.LastName == entity.LastName).Count();
                return (intCount > 0 ? true : false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int RecordCount(string searchValue)
        {
            try
            {
                if (String.IsNullOrEmpty(searchValue))
                {
                    //Find Candidate all no of rows
                    var vCount = adbContext.candidate.Count();
                    return vCount;
                }
                else
                {
                    //Find Candidate no of rows with Searching
                    var vCount = adbContext.candidate.Where(w => new[] { w.FirstName.ToLower(), w.MiddleName.ToLower(), w.LastName.ToLower(), w.EMail.ToLower(), w.Mobile.ToLower(), w.TotalExperience.ToLower(), w.ReferenceFrom.ToLower(), w.Notes.ToLower() }.Any(a => a.Contains(searchValue.ToLower()))).Count();
                    return vCount;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
