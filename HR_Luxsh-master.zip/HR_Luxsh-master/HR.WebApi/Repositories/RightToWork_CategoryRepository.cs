﻿using HR.WebApi.DAL;
using HR.WebApi.Exceptions;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HR.WebApi.Repositories
{
    public class RightToWork_CategoryRepository<T> : ICommonRepository<RightToWork_Category>
    {
        private readonly ApplicationDbContext adbContext;

        public RightToWork_CategoryRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }

        public async Task<IEnumerable<RightToWork_Category>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<RightToWork_Category> vList;
                if (RecordLimit > 0)
                    vList = adbContext.righttowork_category.Take(RecordLimit).ToList();
                else
                    vList = adbContext.righttowork_category.ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<RightToWork_Category>> Get(int id)
        {
            try
            {
                var vList = adbContext.righttowork_category.Where(w => w.RWC_Id == id).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<RightToWork_Category>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            try
            {
                IEnumerable<RightToWork_Category> vList;
                if (String.IsNullOrEmpty(searchValue))
                    vList = adbContext.righttowork_category.Skip(pageIndex * pageSize).Take(pageSize).ToList();
                else
                    vList = adbContext.righttowork_category.Where(w => new[] { Convert.ToString(w.Company_Id), w.Category.ToLower(), w.Name.ToLower(), w.Notes.ToLower() }.Any(a => a.Contains(searchValue.ToLower()))).Skip(pageIndex * pageSize).Take(pageSize).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert(RightToWork_Category entity)
        {
            try
            {
                entity.AddedOn = DateTime.Now;
                adbContext.righttowork_category.Add(entity);

                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Update(RightToWork_Category entity)
        {
            try
            {
                //Update Old RightToWork_Category
                var lstRightToWork_Category = adbContext.righttowork_category.Where(x => x.RWC_Id == entity.RWC_Id).FirstOrDefault();
                if (lstRightToWork_Category == null)
                    throw new RecoredNotFoundException("Data Not Available");
                lstRightToWork_Category.Company_Id = entity.Company_Id;
                lstRightToWork_Category.Category = entity.Category;
                lstRightToWork_Category.Name = entity.Name;
                lstRightToWork_Category.Description = entity.Description;
                lstRightToWork_Category.hasExpiryDate = entity.hasExpiryDate;
                lstRightToWork_Category.isDocumentRequired = entity.isDocumentRequired;
                lstRightToWork_Category.Notes = entity.Notes;

                lstRightToWork_Category.isActive = entity.isActive;
                lstRightToWork_Category.UpdatedBy = entity.UpdatedBy;
                lstRightToWork_Category.UpdatedOn = DateTime.Now;

                adbContext.righttowork_category.Update(lstRightToWork_Category);
                await Task.FromResult(adbContext.SaveChanges());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ToogleStatus(int id, Int16 isActive)
        {
            try
            {
                //update flag isActive=0
                var vList = adbContext.righttowork_category.Where(w => w.RWC_Id == id && w.isActive != isActive).SingleOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");
                vList.isActive = isActive;
                adbContext.righttowork_category.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Delete(int id)
        {
            try
            {
                //Delete RightToWork_Category
                var vList = adbContext.righttowork_category.Where(w => w.RWC_Id == id).SingleOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");
                adbContext.righttowork_category.Remove(vList);
                await Task.FromResult(adbContext.SaveChanges());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Exists(RightToWork_Category entity)
        {
            try
            {
                int intCount = 0;
                if (entity.RWC_Id > 0) //Update Validation
                    intCount = adbContext.righttowork_category.Where(w => w.Company_Id == entity.Company_Id && w.RWC_Id != entity.RWC_Id && (w.Name == entity.Name || w.Category == entity.Category)).Count();
                else //Insert Validation
                    intCount = adbContext.righttowork_category.Where(w => w.Company_Id == entity.Company_Id && (w.Name == entity.Name || w.Category == entity.Category)).Count();
                return (intCount > 0 ? true : false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int RecordCount(string searchValue)
        {
            try
            {
                if (String.IsNullOrEmpty(searchValue))
                {
                    //Find RightToWork_Category all no of rows
                    var vCount = adbContext.righttowork_category.Count();
                    return vCount;
                }
                else
                {
                    //Find RightToWork_Category no of rows with Searching
                    var vCount = adbContext.righttowork_category.Where(w => new[] { Convert.ToString(w.Company_Id), w.Category.ToLower(), w.Name.ToLower(), w.Notes.ToLower() }.Any(a => a.Contains(searchValue.ToLower()))).Count();
                    return vCount;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
