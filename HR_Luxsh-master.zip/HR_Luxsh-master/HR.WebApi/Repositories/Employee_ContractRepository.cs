﻿using HR.WebApi.DAL;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using HR.WebApi.Exceptions;
using HR.WebApi.ModelView;
using System.Text;
using System.Linq.Dynamic.Core;

namespace HR.WebApi.Repositories
{
    public class Employee_ContractRepository<T> : ICommonRepository<Employee_Contract>, IPaginated<Employee_ContractView>
    {
        private readonly ApplicationDbContext adbContext;

        public Employee_ContractRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }

        public async Task<IEnumerable<Employee_Contract>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<Employee_Contract> vList;
                if (RecordLimit > 0)
                    vList = adbContext.employee_contract.Take(RecordLimit).ToList();
                else
                    vList = adbContext.employee_contract.ToList();

                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_Contract>> GetByEmp_Id(int emp_Id)
        {
            try
            {
                IEnumerable<Employee_Contract> vList = adbContext.employee_contract.Where(w => w.Emp_Id == emp_Id).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_Contract>> Get(int id)
        {
            try
            {
                IEnumerable<Employee_Contract> vList = adbContext.employee_contract.Where(w => w.Emp_Contract_Id == id).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert(Employee_Contract entity)
        {
            try
            {
                if (entity.Emp_Id == 0)
                    throw new RecoredNotFoundException("Employee Not Available");

                entity.AddedOn = DateTime.Now;
                adbContext.employee_contract.Add(entity);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert_Multiple(IEnumerable<Employee_Contract> entity)
        {
            try
            {
                if (entity != null && entity.Count() > 0)
                {
                    foreach (var employee in entity)
                    {
                        if (employee.Emp_Id == 0)
                            throw new RecoredNotFoundException("Employee Not Available");
                    }
                    entity.ToList().ForEach(w => w.AddedOn = DateTime.Now);
                    adbContext.employee_contract.AddRange(entity);
                    await Task.FromResult(adbContext.SaveChangesAsync());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Update(Employee_Contract entity)
        {
            try
            {
                var lstEmp_contract = adbContext.employee_contract.Where(x => x.Emp_Contract_Id == entity.Emp_Contract_Id && x.Emp_Id == entity.Emp_Id).FirstOrDefault();

                if (lstEmp_contract == null)
                    throw new RecoredNotFoundException("Data Not Available");

                lstEmp_contract.Emp_Id = entity.Emp_Id;
                lstEmp_contract.Contract_Id = entity.Contract_Id;
                lstEmp_contract.Emp_Contract_Code = entity.Emp_Contract_Code;
                lstEmp_contract.Emp_Contract_Name = entity.Emp_Contract_Name;
                lstEmp_contract.Emp_Contract_HoursDaily = entity.Emp_Contract_HoursDaily;
                lstEmp_contract.Emp_Contract_HoursWeekly = entity.Emp_Contract_HoursWeekly;
                lstEmp_contract.Emp_Contract_Days = entity.Emp_Contract_Days;
                lstEmp_contract.Emp_Contract_Type = entity.Emp_Contract_Type;
                lstEmp_contract.Emp_Contract_Start = entity.Emp_Contract_Start;
                lstEmp_contract.Emp_Contract_End = entity.Emp_Contract_End;
                lstEmp_contract.Emp_Doc_Id = entity.Emp_Doc_Id;
                lstEmp_contract.isRequired = entity.isRequired;
                lstEmp_contract.Notes = entity.Notes;
                lstEmp_contract.Version_Id = entity.Version_Id;

                lstEmp_contract.isActive = entity.isActive;
                lstEmp_contract.UpdatedBy = entity.UpdatedBy;
                lstEmp_contract.UpdatedOn = DateTime.Now;

                adbContext.employee_contract.Update(lstEmp_contract);
                await Task.FromResult(adbContext.SaveChanges());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Update_Contract(IList<Employee_Contract> entity)
        {
            if (entity != null && entity.Count() > 0)
            {
                foreach (var employee in entity)
                {
                    if (employee.Emp_Id == 0)
                        throw new RecoredNotFoundException("Employee Not Available");

                    await Update(employee);
                }
            }
        }

        public async Task ToogleStatusByEmp_Id(int emp_Id, short isActive)
        {
            try
            {
                //update flag isActive
                var vList = adbContext.employee_contract.Where(w => w.Emp_Id == emp_Id && w.isActive != isActive).ToList();
                if (vList.Count() > 0)
                {
                    vList.ForEach(w => w.isActive = isActive);
                    adbContext.employee_contract.UpdateRange(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ToogleStatus(int id, short isActive)
        {
            try
            {
                //update flag isActive
                var vList = adbContext.employee_contract.Where(w => w.Emp_Contract_Id == id && w.isActive != isActive).FirstOrDefault();

                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.isActive = isActive;
                adbContext.employee_contract.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task DeleteByEmp_Id(int emp_Id)
        {
            try
            {
                var vList = adbContext.employee_contract.Where(w => w.Emp_Id == emp_Id).ToList();
                if (vList.Count() > 0)
                {
                    vList.ForEach(w => w.isActive = 0);
                    adbContext.employee_contract.UpdateRange(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Delete(int id)
        {
            try
            {
                var vList = adbContext.employee_contract.Where(w => w.Emp_Contract_Id == id).FirstOrDefault();

                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.isActive = 0;
                adbContext.employee_contract.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_Contract>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            try
            {
                IEnumerable<Employee_Contract> vList;
                if (String.IsNullOrEmpty(searchValue))
                    vList = adbContext.employee_contract.Skip(pageIndex * pageSize).Take(pageSize).ToList();
                else
                    vList = adbContext.employee_contract.Where(w => new[] { Convert.ToString(w.Emp_Id), w.Emp_Contract_Code, w.Emp_Contract_Name, Convert.ToString(w.Emp_Contract_HoursDaily), Convert.ToString(w.Emp_Contract_HoursWeekly), w.Emp_Contract_Days, w.Emp_Contract_Type, Convert.ToString(w.Emp_Doc_Id), w.Notes, w.Version_Id }.Any(a => a.Contains(searchValue))).Skip(pageIndex * pageSize).Take(pageSize).ToList();

                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Data Not Available");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int RecordCount(string searchValue)
        {
            try
            {
                if (String.IsNullOrEmpty(searchValue))
                {
                    var vCount = (from emp in adbContext.employee_contract
                                  select emp.Emp_Contract_Id).Count();
                    return vCount;
                }
                else
                {
                    var vList = adbContext.employee_contract.
                        Where(w => new[] { Convert.ToString(w.Emp_Id), w.Emp_Contract_Code, w.Emp_Contract_Name, Convert.ToString(w.Emp_Contract_HoursDaily), Convert.ToString(w.Emp_Contract_HoursWeekly), w.Emp_Contract_Days, w.Emp_Contract_Type, Convert.ToString(w.Emp_Doc_Id), w.Notes, w.Version_Id }.Any(a => a.Contains(searchValue))).Count();

                    return vList;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Exists(Employee_Contract entity)
        {
            try
            {
                int intCount = 0;
                if (entity.Emp_Contract_Id > 0) //Update Validation
                    intCount = adbContext.employee_contract.Where(w => w.Emp_Contract_Id != entity.Emp_Contract_Id && w.Emp_Id == entity.Emp_Id && w.Emp_Contract_Code == entity.Emp_Contract_Code && w.Emp_Contract_Name == entity.Emp_Contract_Name).Count();
                else //Insert Validation
                    intCount = adbContext.employee_contract.Where(w => w.Emp_Id == entity.Emp_Id && w.Emp_Contract_Code == entity.Emp_Contract_Code && w.Emp_Contract_Name == entity.Emp_Contract_Name).Count();
                return (intCount > 0 ? true : false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ReturnBy<Employee_ContractView>> GetPaginated(PaginationBy search)
        {
            try
            {
                string strOrder = string.IsNullOrEmpty(search.OrderBy) ? "Emp_Contract_Id" : search.OrderBy;
                string strWhere = Common.Search.WhereString(search);

                IEnumerable<Employee_ContractView> vEmploye_Contract;
                if (!String.IsNullOrEmpty(search.CommonSearch))
                {
                    vEmploye_Contract = (from emp in adbContext.employee
                                         join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id
                                         join emp_Contract in adbContext.employee_contract on emp.Emp_Id equals emp_Contract.Emp_Id
                                         select new Employee_ContractView
                                         {
                                             Emp_Contract_Id = emp_Contract.Emp_Contract_Id,
                                             Emp_Id = emp_Contract.Emp_Id,
                                             Contract_Id = emp_Contract.Contract_Id,
                                             Emp_Contract_Code = emp_Contract.Emp_Contract_Code,
                                             Emp_Contract_Name = emp_Contract.Emp_Contract_Name,
                                             Emp_Contract_HoursDaily = emp_Contract.Emp_Contract_HoursDaily,
                                             Emp_Contract_HoursWeekly = emp_Contract.Emp_Contract_HoursWeekly,
                                             Emp_Contract_Days = emp_Contract.Emp_Contract_Days,
                                             Emp_Contract_Type = emp_Contract.Emp_Contract_Type,
                                             Emp_Contract_Start = emp_Contract.Emp_Contract_Start,
                                             Emp_Contract_End = emp_Contract.Emp_Contract_End,
                                             Emp_Doc_Id = emp_Contract.Emp_Doc_Id,
                                             isRequired = emp_Contract.isRequired,
                                             Notes = emp_Contract.Notes,
                                             Version_Id = emp_Contract.Version_Id,
                                             isActive = emp_Contract.isActive,
                                             AddedBy = emp_Contract.AddedBy,
                                             UpdatedBy = emp_Contract.UpdatedBy,
                                             Company_Id = emp.Company_Id
                                         }).Where(w => new[] { Convert.ToString(w.Emp_Contract_Id), w.Emp_Contract_Code.ToLower(), Convert.ToString(w.Emp_Id), w.Emp_Contract_Name.ToLower(),w.Emp_Contract_Days.ToLower() }.Any(a => a.Contains(search.CommonSearch.ToLower()))).OrderBy(strOrder).ToList();
                }
                else
                {
                    vEmploye_Contract = (from emp in adbContext.employee
                                         join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id
                                         join emp_Contract in adbContext.employee_contract on emp.Emp_Id equals emp_Contract.Emp_Id
                                         select new Employee_ContractView
                                         {
                                             Emp_Contract_Id = emp_Contract.Emp_Contract_Id,
                                             Emp_Id = emp_Contract.Emp_Id,
                                             Contract_Id = emp_Contract.Contract_Id,
                                             Emp_Contract_Code = emp_Contract.Emp_Contract_Code,
                                             Emp_Contract_Name = emp_Contract.Emp_Contract_Name,
                                             Emp_Contract_HoursDaily = emp_Contract.Emp_Contract_HoursDaily,
                                             Emp_Contract_HoursWeekly = emp_Contract.Emp_Contract_HoursWeekly,
                                             Emp_Contract_Days = emp_Contract.Emp_Contract_Days,
                                             Emp_Contract_Type = emp_Contract.Emp_Contract_Type,
                                             Emp_Contract_Start = emp_Contract.Emp_Contract_Start,
                                             Emp_Contract_End = emp_Contract.Emp_Contract_End,
                                             Emp_Doc_Id = emp_Contract.Emp_Doc_Id,
                                             isRequired = emp_Contract.isRequired,
                                             Notes = emp_Contract.Notes,
                                             Version_Id = emp_Contract.Version_Id,
                                             isActive = emp_Contract.isActive,
                                             AddedBy = emp_Contract.AddedBy,
                                             UpdatedBy = emp_Contract.UpdatedBy,
                                             Company_Id = emp.Company_Id
                                         }).Where(strWhere).OrderBy(strOrder).ToList();
                }

                if (vEmploye_Contract == null || vEmploye_Contract.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                ReturnBy<Employee_ContractView> vList = new ReturnBy<Employee_ContractView>()
                {
                    list = vEmploye_Contract.Skip(search.PageIndex * search.PageSize).Take(search.PageSize).ToList(),
                    RecordCount = vEmploye_Contract.Count()
                };
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
