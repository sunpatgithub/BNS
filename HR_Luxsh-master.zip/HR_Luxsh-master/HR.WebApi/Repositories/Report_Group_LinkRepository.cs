﻿using HR.WebApi.DAL;
using HR.WebApi.Exceptions;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using HR.WebApi.ModelView;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading.Tasks;

namespace HR.WebApi.Repositories
{
    public class Report_Group_LinkRepository<T> : IReportBuilder<Report_Group_LinkView>
    {
        private readonly ApplicationDbContext adbContext;

        public Report_Group_LinkRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }

        public async Task<IEnumerable<Report_Group_LinkView>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<Report_Group_LinkView> vList;
                if (RecordLimit > 0)
                    vList = (from rgl in adbContext.report_group_link
                             join rg in adbContext.report_group on rgl.Report_Group_Id equals rg.Id
                             select new Report_Group_LinkView
                             {
                                 Id = rgl.Id,
                                 Report_Group_Id = rgl.Report_Group_Id,

                                 ParentTableName = rg.TableName,

                                 TableName = rgl.TableName,
                                 DisplayName = rgl.DisplayName,
                                 Join_By = rgl.Join_By,
                                 Group_By = rgl.Group_By,
                                 Order_By = rgl.Order_By,
                                 AddedBy = rgl.AddedBy,
                                 AddedOn = rgl.AddedOn
                             }).Take(RecordLimit).ToList();
                else
                    vList = (from rgl in adbContext.report_group_link
                             join rg in adbContext.report_group on rgl.Report_Group_Id equals rg.Id
                             select new Report_Group_LinkView
                             {
                                 Id = rgl.Id,
                                 Report_Group_Id = rgl.Report_Group_Id,

                                 ParentTableName = rg.TableName,

                                 TableName = rgl.TableName,
                                 DisplayName = rgl.DisplayName,
                                 Join_By = rgl.Join_By,
                                 Group_By = rgl.Group_By,
                                 Order_By = rgl.Order_By,
                                 AddedBy = rgl.AddedBy,
                                 AddedOn = rgl.AddedOn
                             }).ToList();

                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Report_Group_LinkView>> Get(int id)
        {
            try
            {
                var vList = (from rgl in adbContext.report_group_link
                             join rg in adbContext.report_group on rgl.Report_Group_Id equals rg.Id
                             where rgl.Id == id
                             select new Report_Group_LinkView
                             {
                                 Id = rgl.Id,
                                 Report_Group_Id = rgl.Report_Group_Id,

                                 ParentTableName = rg.TableName,

                                 TableName = rgl.TableName,
                                 DisplayName = rgl.DisplayName,
                                 Join_By = rgl.Join_By,
                                 Group_By = rgl.Group_By,
                                 Order_By = rgl.Order_By,
                                 AddedBy = rgl.AddedBy,
                                 AddedOn = rgl.AddedOn
                             }).ToList();
                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ReturnBy<Report_Group_LinkView>> GetPaginated(PaginationBy search)
        {
            try
            {
                string strOrder = string.IsNullOrEmpty(search.OrderBy) ? "Id" : search.OrderBy;
                string strWhere = Common.Search.WhereString(search);

                IEnumerable<Report_Group_LinkView> vReport;
                if (!String.IsNullOrEmpty(search.CommonSearch))
                    vReport = (from rgl in adbContext.report_group_link
                               join rg in adbContext.report_group on rgl.Report_Group_Id equals rg.Id
                               select new Report_Group_LinkView
                               {
                                   Id = rgl.Id,
                                   Report_Group_Id = rgl.Report_Group_Id,

                                   ParentTableName = rg.TableName,

                                   TableName = rgl.TableName,
                                   DisplayName = rgl.DisplayName,
                                   Join_By = rgl.Join_By,
                                   Group_By = rgl.Group_By,
                                   Order_By = rgl.Order_By,
                                   AddedBy = rgl.AddedBy,
                                   AddedOn = rgl.AddedOn
                               }).Where(w => new[] { w.TableName, w.DisplayName, w.Join_By, w.Group_By, w.Order_By, Convert.ToString(w.Id), Convert.ToString(w.Report_Group_Id) }.Any(a => a.Contains(search.CommonSearch.ToLower()))).OrderBy(strOrder).ToList();

                else
                    vReport = (from rgl in adbContext.report_group_link
                               join rg in adbContext.report_group on rgl.Report_Group_Id equals rg.Id
                               select new Report_Group_LinkView
                               {
                                   Id = rgl.Id,
                                   Report_Group_Id = rgl.Report_Group_Id,

                                   ParentTableName = rg.TableName,

                                   TableName = rgl.TableName,
                                   DisplayName = rgl.DisplayName,
                                   Join_By = rgl.Join_By,
                                   Group_By = rgl.Group_By,
                                   Order_By = rgl.Order_By,
                                   AddedBy = rgl.AddedBy,
                                   AddedOn = rgl.AddedOn
                               }).Where(strWhere).OrderBy(strOrder).ToList();

                ReturnBy<Report_Group_LinkView> vList = new ReturnBy<Report_Group_LinkView>()
                {
                    list = vReport.Skip(search.PageIndex * search.PageSize).Take(search.PageSize).ToList(),
                    RecordCount = vReport.Count()
                };

                if (vList.list == null || vList.RecordCount == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert(Report_Group_LinkView entity)
        {
            try
            {
                var vList = new Report_Group_Link
                {
                    Report_Group_Id = entity.Report_Group_Id,
                    TableName = entity.TableName,
                    DisplayName = entity.DisplayName,
                    Join_By = entity.Join_By,
                    Group_By = entity.Group_By,
                    Order_By = entity.Order_By,
                    AddedBy = entity.AddedBy,
                    AddedOn = DateTime.Now
                };
                adbContext.report_group_link.Add(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Update(Report_Group_LinkView entity)
        {
            try
            {
                var vList = adbContext.report_group_link.Where(x => x.Id == entity.Id).FirstOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.Report_Group_Id = entity.Report_Group_Id;
                vList.TableName = entity.TableName;
                vList.DisplayName = entity.DisplayName;
                vList.Join_By = entity.Join_By;
                vList.Group_By = entity.Group_By;
                vList.Order_By = entity.Order_By;

                adbContext.report_group_link.Update(vList);

                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Delete(int id)
        {
            try
            {
                //Delete Report_Group_Link
                var vList = adbContext.report_group_link.Where(w => w.Id == id).ToList().SingleOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                adbContext.report_group_link.Remove(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public bool Exists(Report_Group_LinkView entity)
        {
            try
            {
                int intCount = 0;
                //if (entity.Id > 0)
                //    intCount = adbContext.report_group_link.Where(w => w.Id != entity.Id && (w.TableName == entity.TableName)).Count();
                //else
                intCount = adbContext.report_group_link.Where(w => w.Report_Group_Id == entity.Report_Group_Id && (w.TableName == entity.TableName)).Count();
                return (intCount > 0 ? true : false);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

    }
}
