﻿using HR.WebApi.DAL;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HR.WebApi.Repositories
{
    public class Emp_Yearly_LeaveRepository<T> : ICommonRepository<Emp_Yearly_Leave>, IEmp_Yearly_Leave<Emp_Yearly_Leave>
    {
        private readonly ApplicationDbContext adbContext;
        public Emp_Yearly_LeaveRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }

        public Task Delete(int id)
        {
            throw new NotImplementedException();
        }

        public bool Exists(Emp_Yearly_Leave entity)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<Emp_Yearly_Leave>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<Emp_Yearly_Leave>> Get(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<Emp_Yearly_Leave>> GetAll(int empid)
        {
            try
            {
                IList<Emp_Yearly_Leave> empyearleave = adbContext.emp_yearly_leave.AsEnumerable<Emp_Yearly_Leave>().Where(e=>e.emp_id==empid).ToList();

                return await Task.FromResult(empyearleave);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        public async Task Insert(Emp_Yearly_Leave entity)
        {
            try
            {
                entity.schedule_date = DateTime.Now;
                await adbContext.emp_yearly_leave.AddAsync(entity);

                adbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int RecordCount(string searchValue)
        {
            throw new NotImplementedException();
        }

        public Task ToogleStatus(int id, short isActive)
        {
            throw new NotImplementedException();
        }

        public Task Update(Emp_Yearly_Leave entity)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<Emp_Yearly_Leave>> Get_Employee_Anuual_Encashment(int CompanyId)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<Emp_Yearly_Leave>> Get_Employee_Leave_By_LeaveType_And_EmpId(int Empid, int Leave_type_id)
        {
            try
            {
                var findCurrentYear = adbContext.emp_yearly_leave.Where(e => e.emp_id == Empid).OrderByDescending(e => e.emp_yearly_leave_id).FirstOrDefault().leave_year;

                var findEmpLeave = adbContext.emp_yearly_leave.Where(e => e.emp_id == Empid && e.leave_type_id == Leave_type_id && e.leave_year == findCurrentYear).ToList();

                return findEmpLeave;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //public async Task<IEnumerable<Emp_Leave>> Update_Employee_TakenLeave(long Emp_Yearly_Leave_Id, double TakenLeave,string Leave_Status)
        //{
        //    try
        //    {
        //        var isExist = adbContext.emp_yearly_leave.Where(e => e.emp_yearly_leave_id == Emp_Yearly_Leave_Id).ToList();
        //        if (isExist.Count > 0)
        //        {
        //            if (Leave_Status.ToUpper() == "APPROVE")
        //            {
        //                double emptakenLeave = 0;
        //                double empremainingLeave = 0;
        //                foreach (var item in isExist)
        //                {
        //                    emptakenLeave = item.emp_takenleave;
        //                    empremainingLeave = item.emp_remaining_leave;
        //                }

        //                double updateNewTakenLeave = emptakenLeave + TakenLeave;
        //                double updateNewRemainingLeave = empremainingLeave - TakenLeave;

        //                var updateEmpTakenLeave = await adbContext.emp_yearly_leave.FindAsync(Emp_Yearly_Leave_Id);

        //                updateEmpTakenLeave.emp_takenleave = updateNewTakenLeave;
        //                updateEmpTakenLeave.emp_remaining_leave = updateNewRemainingLeave;
        //            }
        //            else if (Leave_Status.ToUpper() == "CANCEL")
        //            {
        //                double emptakenLeave = 0;
        //                double empremainingLeave = 0;
        //                foreach (var item in isExist)
        //                {
        //                    emptakenLeave = item.emp_takenleave;
        //                    empremainingLeave = item.emp_remaining_leave;
        //                }

        //                double updateNewTakenLeave = emptakenLeave - TakenLeave;
        //                double updateNewRemainingLeave = empremainingLeave + TakenLeave;

        //                var updateEmpTakenLeave = await adbContext.emp_yearly_leave.FindAsync(Emp_Yearly_Leave_Id);

        //                updateEmpTakenLeave.emp_takenleave = updateNewTakenLeave;
        //                updateEmpTakenLeave.emp_remaining_leave = updateNewRemainingLeave;
        //            }
        //            await adbContext.SaveChangesAsync();
        //        }
        //        else 
        //        {
        //            throw new Exception("Data Not Available");
        //        }
        //        return isExist;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        public async Task<IEnumerable<Emp_Yearly_Leave>> Update_Employee_Type(int EmpId, string Emp_Type)
        {
            try
            {
                var totalEmpYearLeave = adbContext.emp_yearly_leave.Where(x => x.emp_id == EmpId).ToList();

                if (totalEmpYearLeave.Count() > 0)
                {
                    foreach (var item in totalEmpYearLeave)
                    {
                        var lstEmpYearLeave = await adbContext.emp_yearly_leave.FindAsync(item.emp_yearly_leave_id);
                        lstEmpYearLeave.emp_type = Emp_Type;                        
                        await adbContext.SaveChangesAsync();
                    }
                    return totalEmpYearLeave;
                }
                else
                {
                    throw new Exception("Data Not Available");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
