﻿using HR.WebApi.DAL;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using HR.WebApi.Exceptions;
using HR.WebApi.ModelView;
using System.Text;
using System.Linq.Dynamic.Core;

namespace HR.WebApi.Repositories
{
    public class Employee_RightToWorkRepository<T> : ICommonRepository<Employee_RightToWork>, IPaginated<Employee_RightToWorkView>
    {
        private readonly ApplicationDbContext adbContext;

        public Employee_RightToWorkRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }

        public async Task<IEnumerable<Employee_RightToWork>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<Employee_RightToWork> vList;
                if (RecordLimit > 0)
                    vList = adbContext.employee_righttowork.Take(RecordLimit).ToList();
                else
                    vList = adbContext.employee_righttowork.ToList();

                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_RightToWork>> GetByEmp_Id(int emp_Id)
        {
            try
            {
                IEnumerable<Employee_RightToWork> vList = adbContext.employee_righttowork.Where(w => w.Emp_Id == emp_Id && w.isActive == 1).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_RightToWork>> Get(int id)
        {
            try
            {
                IEnumerable<Employee_RightToWork> vList = adbContext.employee_righttowork.Where(w => w.RightToWork_Id == id).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert(Employee_RightToWork entity)
        {
            try
            {
                if (entity.Emp_Id == 0)
                    throw new RecoredNotFoundException("Employee Not Available");
                entity.AddedOn = DateTime.Now;
                adbContext.employee_righttowork.Add(entity);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert_Multiple(IEnumerable<Employee_RightToWork> entity)
        {
            try
            {
                if (entity != null && entity.Count() > 0)
                {
                    foreach (var employee in entity)
                    {
                        if (employee.Emp_Id == 0)
                            throw new RecoredNotFoundException("Employee Not Available");
                    }
                    entity.ToList().ForEach(w => w.AddedOn = DateTime.Now);
                    adbContext.employee_righttowork.AddRange(entity);
                    await Task.FromResult(adbContext.SaveChangesAsync());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Update(Employee_RightToWork entity)
        {
            try
            {
                var vList = adbContext.employee_righttowork.Where(x => x.RightToWork_Id == entity.RightToWork_Id && x.Emp_Id == entity.Emp_Id).FirstOrDefault();

                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.Emp_Id = entity.Emp_Id;
                vList.RWC_Id = entity.RWC_Id;
                vList.IssueDate = entity.IssueDate;
                vList.IssueAuthority = entity.IssueAuthority;
                vList.IssueCountry = entity.IssueCountry;
                vList.ExpiryDate = entity.ExpiryDate;
                vList.Emp_Doc_Id = entity.Emp_Doc_Id;
                vList.Notes = entity.Notes;

                vList.isActive = entity.isActive;
                vList.UpdatedBy = entity.UpdatedBy;
                vList.UpdatedOn = DateTime.Now;

                adbContext.employee_righttowork.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Update_RightToWork(IList<Employee_RightToWork> entity)
        {
            try
            {
                if (entity != null && entity.Count() > 0)
                {
                    foreach (var employee in entity)
                    {
                        if (employee.Emp_Id == 0)
                            throw new RecoredNotFoundException("Employee Not Available");
                        await Update(employee);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ToogleStatusByEmp_Id(int emp_Id, short isActive)
        {
            try
            {
                //update flag isActive
                var vList = adbContext.employee_righttowork.Where(w => w.Emp_Id == emp_Id && w.isActive != isActive).ToList();
                if (vList.Count() > 0)
                {
                    vList.ForEach(a => a.isActive = isActive);
                    adbContext.employee_righttowork.UpdateRange(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ToogleStatus(int id, short isActive)
        {
            try
            {
                //update flag isActive
                var vList = adbContext.employee_righttowork.Where(w => w.RightToWork_Id == id && w.isActive != isActive).FirstOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");
                vList.isActive = isActive;
                adbContext.employee_righttowork.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task DeleteByEmp_Id(int emp_Id)
        {
            try
            {
                var vList = adbContext.employee_righttowork.Where(w => w.Emp_Id == emp_Id).ToList();
                if (vList.Count() > 0)
                {
                    vList.ForEach(w => w.isActive = 0);
                    adbContext.employee_righttowork.UpdateRange(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Delete(int id)
        {
            try
            {
                var vList = adbContext.employee_righttowork.Where(w => w.RightToWork_Id == id).FirstOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");
                vList.isActive = 0;
                adbContext.employee_righttowork.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_RightToWork>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            try
            {
                IEnumerable<Employee_RightToWork> vList;
                if (String.IsNullOrEmpty(searchValue))
                    vList = adbContext.employee_righttowork.Skip(pageIndex * pageSize).Take(pageSize).ToList();
                else
                    vList = adbContext.employee_righttowork.Where(w => new[] { Convert.ToString(w.Emp_Id), w.IssueAuthority, w.IssueCountry, w.Notes }.Any(a => a.Contains(searchValue))).Skip(pageIndex * pageSize).Take(pageSize).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Data Not Available");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int RecordCount(string searchValue)
        {
            try
            {
                if (String.IsNullOrEmpty(searchValue))
                {
                    var vCount = (from emp in adbContext.employee_righttowork
                                  select emp.RightToWork_Id).Count();
                    return vCount;
                }
                else
                {
                    var vList = adbContext.employee_righttowork.
                        Where(w => new[] { Convert.ToString(w.Emp_Id), w.IssueAuthority, w.IssueCountry, w.Notes }.Any(a => a.Contains(searchValue))).Count();

                    return vList;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Exists(Employee_RightToWork entity)
        {
            try
            {
                int intCount = 0;
                if (entity.RightToWork_Id > 0) //Update Validation
                    intCount = adbContext.employee_righttowork.Where(w => w.RightToWork_Id != entity.RightToWork_Id && w.IssueDate == entity.IssueDate && w.IssueAuthority == entity.IssueAuthority && w.IssueCountry == entity.IssueCountry && w.ExpiryDate == entity.ExpiryDate).Count();
                else //Insert Validation
                    intCount = adbContext.employee_righttowork.Where(w => w.IssueDate == entity.IssueDate && w.IssueAuthority == entity.IssueAuthority && w.IssueCountry == entity.IssueCountry && w.ExpiryDate == entity.ExpiryDate).Count();
                return (intCount > 0 ? true : false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ReturnBy<Employee_RightToWorkView>> GetPaginated(PaginationBy search)
        {
            try
            {
                string strOrder = string.IsNullOrEmpty(search.OrderBy) ? "RightToWork_Id" : search.OrderBy;
                string strWhere = Common.Search.WhereString(search);

                IEnumerable<Employee_RightToWorkView> vEmploye_rightToWork;
                if (!String.IsNullOrEmpty(search.CommonSearch))
                {
                    vEmploye_rightToWork = (from emp in adbContext.employee
                                            join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id
                                            join emp_righttowork in adbContext.employee_righttowork on emp.Emp_Id equals emp_righttowork.Emp_Id
                                            select new Employee_RightToWorkView
                                            {
                                                RightToWork_Id = emp_righttowork.RightToWork_Id,
                                                Emp_Id = emp_righttowork.Emp_Id,
                                                RWC_Id = emp_righttowork.RWC_Id,
                                                IssueDate = emp_righttowork.IssueDate,
                                                IssueAuthority = emp_righttowork.IssueAuthority,
                                                IssueCountry = emp_righttowork.IssueCountry,
                                                ExpiryDate = emp_righttowork.ExpiryDate,
                                                Emp_Doc_Id = emp_righttowork.Emp_Doc_Id,
                                                Notes = emp_righttowork.Notes,
                                                isActive = emp_righttowork.isActive,
                                                AddedBy = emp_righttowork.AddedBy,
                                                UpdatedBy = emp_righttowork.UpdatedBy,
                                                Company_Id = emp.Company_Id
                                            }).Where(w => new[] { Convert.ToString(w.RightToWork_Id), w.IssueAuthority.ToLower(), Convert.ToString(w.Emp_Id), w.IssueCountry.ToLower() }.Any(a => a.Contains(search.CommonSearch.ToLower()))).OrderBy(strOrder).ToList();
                }
                else
                {
                    vEmploye_rightToWork = (from emp in adbContext.employee
                                            join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id
                                            join emp_righttowork in adbContext.employee_righttowork on emp.Emp_Id equals emp_righttowork.Emp_Id
                                            select new Employee_RightToWorkView
                                            {
                                                RightToWork_Id = emp_righttowork.RightToWork_Id,
                                                Emp_Id = emp_righttowork.Emp_Id,
                                                RWC_Id = emp_righttowork.RWC_Id,
                                                IssueDate = emp_righttowork.IssueDate,
                                                IssueAuthority = emp_righttowork.IssueAuthority,
                                                IssueCountry = emp_righttowork.IssueCountry,
                                                ExpiryDate = emp_righttowork.ExpiryDate,
                                                Emp_Doc_Id = emp_righttowork.Emp_Doc_Id,
                                                Notes = emp_righttowork.Notes,
                                                isActive = emp_righttowork.isActive,
                                                AddedBy = emp_righttowork.AddedBy,
                                                UpdatedBy = emp_righttowork.UpdatedBy,
                                                Company_Id = emp.Company_Id
                                            }).Where(strWhere).OrderBy(strOrder).ToList();
                }                   

                if (vEmploye_rightToWork == null || vEmploye_rightToWork.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                ReturnBy<Employee_RightToWorkView> vList = new ReturnBy<Employee_RightToWorkView>()
                {
                    list = vEmploye_rightToWork.Skip(search.PageIndex * search.PageSize).Take(search.PageSize).ToList(),
                    RecordCount = vEmploye_rightToWork.Count()
                };
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
