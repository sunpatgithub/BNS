﻿using HR.WebApi.DAL;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using HR.WebApi.Exceptions;
using HR.WebApi.ModelView;
using System.IO;
using System.Text;
using System.Linq.Dynamic.Core;

namespace HR.WebApi.Repositories
{
    public class Employee_DocumentRepository<T> : ICommonRepository<Employee_DocumentView>, IPaginated<Employee_DocumentView>
    {
        private readonly ApplicationDbContext adbContext;
        private IDocuments document { get; set; }

        public Employee_DocumentRepository(ApplicationDbContext applicationDbContext, IDocuments empDocument)
        {
            adbContext = applicationDbContext;
            document = empDocument;
        }
        public async Task<IEnumerable<Employee_DocumentView>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<Employee_DocumentView> vList;
                if (RecordLimit > 0)
                {
                    vList = (from emp_doc in adbContext.employee_document
                             select new Employee_DocumentView
                             {
                                 Emp_Doc_Id = emp_doc.Emp_Doc_Id,
                                 Emp_Id = emp_doc.Emp_Id,
                                 Doc_Id = emp_doc.Doc_Id,
                                 Parent_Emp_Doc_Id = emp_doc.Parent_Emp_Doc_Id,
                                 Emp_Doc_Name = emp_doc.Emp_Doc_Name,
                                 Emp_Doc_Path = emp_doc.Emp_Doc_Path,
                                 Notes = emp_doc.Notes,
                                 isActive = emp_doc.isActive
                             }).Take(RecordLimit).ToList();
                }
                else
                {
                    vList = (from emp_doc in adbContext.employee_document
                             select new Employee_DocumentView
                             {
                                 Emp_Doc_Id = emp_doc.Emp_Doc_Id,
                                 Emp_Id = emp_doc.Emp_Id,
                                 Doc_Id = emp_doc.Doc_Id,
                                 Parent_Emp_Doc_Id = emp_doc.Parent_Emp_Doc_Id,
                                 Emp_Doc_Name = emp_doc.Emp_Doc_Name,
                                 Emp_Doc_Path = emp_doc.Emp_Doc_Path,
                                 Notes = emp_doc.Notes,
                                 isActive = emp_doc.isActive
                             }).ToList();
                }

                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_DocumentView>> GetByEmp_Id(int emp_Id)
        {
            try
            {
                IEnumerable<Employee_DocumentView> vList = (from emp_doc in adbContext.employee_document
                                                            where emp_doc.Emp_Id == emp_Id
                                                            select new Employee_DocumentView
                                                            {
                                                                Emp_Doc_Id = emp_doc.Emp_Doc_Id,
                                                                Emp_Id = emp_doc.Emp_Id,
                                                                Doc_Id = emp_doc.Doc_Id,
                                                                Parent_Emp_Doc_Id = emp_doc.Parent_Emp_Doc_Id,
                                                                Emp_Doc_Name = emp_doc.Emp_Doc_Name,
                                                                Emp_Doc_Path = emp_doc.Emp_Doc_Path,
                                                                Notes = emp_doc.Notes,
                                                                isActive = emp_doc.isActive
                                                            }).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_DocumentView>> Get(int id)
        {
            try
            {
                IEnumerable<Employee_DocumentView> vList = (from emp_doc in adbContext.employee_document
                                                            where emp_doc.Emp_Doc_Id == id
                                                            select new Employee_DocumentView
                                                            {
                                                                Emp_Doc_Id = emp_doc.Emp_Doc_Id,
                                                                Emp_Id = emp_doc.Emp_Id,
                                                                Doc_Id = emp_doc.Doc_Id,
                                                                Parent_Emp_Doc_Id = emp_doc.Parent_Emp_Doc_Id,
                                                                Emp_Doc_Name = emp_doc.Emp_Doc_Name,
                                                                Emp_Doc_Path = emp_doc.Emp_Doc_Path,
                                                                Notes = emp_doc.Notes,
                                                                isActive = emp_doc.isActive
                                                            }).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task Insert(Employee_DocumentView entity)
        {
            try
            {
                if (entity.Emp_Id == 0)
                    throw new RecoredNotFoundException("Employee Not Available");

                if (entity.files.Length > 0)
                {
                    string strFullPath = document.UploadFile(entity.files, entity.Emp_Id.ToString());
                    Employee_Document vList = new Employee_Document
                    {
                        Emp_Id = entity.Emp_Id,
                        Doc_Id = entity.Doc_Id,
                        Parent_Emp_Doc_Id = entity.Parent_Emp_Doc_Id,
                        Emp_Doc_Name = entity.files.FileName,
                        Emp_Doc_Path = strFullPath,
                        Notes = entity.Notes,
                        isActive = entity.isActive,
                        AddedBy = entity.AddedBy,
                        AddedOn = DateTime.Now
                    };
                    adbContext.employee_document.Add(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert_Multiple(IEnumerable<Employee_Document> entity)
        {
            try
            {
                if (entity != null && entity.Count() > 0)
                {
                    foreach (var employee in entity)
                    {
                        if (employee.Emp_Id == 0)
                            throw new RecoredNotFoundException("Employee Not Available");

                        #region Add File in Folder
                        string strpath = employee.Emp_Doc_Path;
                        string strfileName = Path.GetFileName(employee.Emp_Doc_Name);
                        var strfileSave = AppSettings.DocumentPath + employee.Emp_Id.ToString();

                        if (!Directory.Exists(strfileSave))
                            Directory.CreateDirectory(strfileSave);

                        string strfileSavePath = Path.Combine(strfileSave, strfileName);
                        File.Copy(strpath, strfileSavePath, true);
                        #endregion

                        employee.AddedOn = DateTime.Now;
                        adbContext.employee_document.Add(employee);
                    }
                    await Task.FromResult(adbContext.SaveChangesAsync());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task Update(Employee_DocumentView entity)
        {
            try
            {
                var lstEmp_document = adbContext.employee_document.Where(x => x.Emp_Doc_Id == entity.Emp_Doc_Id && x.Emp_Id == entity.Emp_Id).FirstOrDefault();

                if (lstEmp_document == null)
                    throw new RecoredNotFoundException("Data Not Available");

                if (entity.files.Length > 0)
                {
                    string strFullPath = document.UploadFile(entity.files, entity.Emp_Id.ToString());

                    lstEmp_document.Emp_Id = entity.Emp_Id;
                    lstEmp_document.Parent_Emp_Doc_Id = entity.Parent_Emp_Doc_Id;
                    lstEmp_document.Doc_Id = entity.Doc_Id;
                    lstEmp_document.Emp_Doc_Name = entity.files.FileName;
                    lstEmp_document.Emp_Doc_Path = strFullPath;
                    lstEmp_document.Notes = entity.Notes;

                    lstEmp_document.isActive = entity.isActive;
                    lstEmp_document.UpdatedBy = entity.UpdatedBy;
                    lstEmp_document.UpdatedOn = DateTime.Now;

                    adbContext.employee_document.Update(lstEmp_document);
                    await Task.FromResult(adbContext.SaveChanges());
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //public async Task Update_Document(IList<Employee_DocumentView> entity)
        //{
        //    try
        //    {
        //        if (entity != null && entity.Count() > 0)
        //        {
        //            foreach (var employee in entity)
        //            {
        //                if (employee.Emp_Id == 0)
        //                    throw new RecoredNotFoundException("Employee Not Available");

        //                await Update(employee);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //}

        public async Task ToogleStatusByEmp_Id(int emp_Id, short isActive)
        {
            try
            {
                //update flag isActive
                var vList = adbContext.employee_document.Where(w => w.Emp_Id == emp_Id && w.isActive != isActive).ToList();
                if (vList.Count() > 0)
                {
                    vList.ForEach(w => w.isActive = isActive);
                    adbContext.employee_document.UpdateRange(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ToogleStatus(int id, short isActive)
        {
            try
            {
                //update flag isActive
                var vList = adbContext.employee_document.Where(w => w.Emp_Doc_Id == id && w.isActive != isActive).FirstOrDefault();

                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.isActive = isActive;
                adbContext.employee_document.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task DeleteByEmp_Id(int emp_Id)
        {
            try
            {
                var vList = adbContext.employee_document.Where(w => w.Emp_Id == emp_Id).ToList();
                if (vList.Count() > 0)
                {
                    vList.ForEach(w => w.isActive = 0);
                    adbContext.employee_document.UpdateRange(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Delete(int id)
        {
            try
            {
                var vList = adbContext.employee_document.Where(w => w.Emp_Doc_Id == id).FirstOrDefault();

                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.isActive = 0;
                adbContext.employee_document.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_DocumentView>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            try
            {
                IEnumerable<Employee_DocumentView> vList;
                if (String.IsNullOrEmpty(searchValue))
                {
                    vList = (from emp_doc in adbContext.employee_document
                             select new Employee_DocumentView
                             {
                                 Emp_Doc_Id = emp_doc.Emp_Doc_Id,
                                 Emp_Id = emp_doc.Emp_Id,
                                 Doc_Id = emp_doc.Doc_Id,
                                 Parent_Emp_Doc_Id = emp_doc.Parent_Emp_Doc_Id,
                                 Emp_Doc_Name = emp_doc.Emp_Doc_Name,
                                 Emp_Doc_Path = emp_doc.Emp_Doc_Path,
                                 Notes = emp_doc.Notes,
                                 isActive = emp_doc.isActive
                             }).Skip(pageIndex * pageSize).Take(pageSize).ToList();
                }
                else
                {
                    vList = (from emp_doc in adbContext.employee_document
                             select new Employee_DocumentView
                             {
                                 Emp_Doc_Id = emp_doc.Emp_Doc_Id,
                                 Emp_Id = emp_doc.Emp_Id,
                                 Doc_Id = emp_doc.Doc_Id,
                                 Parent_Emp_Doc_Id = emp_doc.Parent_Emp_Doc_Id,
                                 Emp_Doc_Name = emp_doc.Emp_Doc_Name,
                                 Emp_Doc_Path = emp_doc.Emp_Doc_Path,
                                 Notes = emp_doc.Notes,
                                 isActive = emp_doc.isActive
                             }).Where(w => new[] { Convert.ToString(w.Emp_Id), w.Emp_Doc_Name, w.Notes }.Any(a => a.Contains(searchValue))).Skip(pageIndex * pageSize).Take(pageSize).ToList();
                }

                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Data Not Available");
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int RecordCount(string searchValue)
        {
            try
            {
                if (String.IsNullOrEmpty(searchValue))
                {
                    var vCount = (from emp in adbContext.employee_document
                                  select emp.Emp_Doc_Id).Count();
                    return vCount;
                }
                else
                {
                    var vList = adbContext.employee_document.
                        Where(w => new[] { Convert.ToString(w.Emp_Id), w.Emp_Doc_Name, w.Notes }.Any(a => a.Contains(searchValue))).Count();

                    return vList;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Exists(Employee_DocumentView entity)
        {
            try
            {
                int intCount = 0;
                if (entity.Emp_Doc_Id > 0) //Update Validation
                    intCount = adbContext.employee_document.Where(w => w.Emp_Doc_Id != entity.Emp_Doc_Id && w.Emp_Id == entity.Emp_Id && (w.Emp_Doc_Name == entity.files.FileName)).Count();
                else //Insert Validation
                    intCount = adbContext.employee_document.Where(w => w.Emp_Id == entity.Emp_Id && (w.Emp_Doc_Name == entity.files.FileName)).Count();
                return (intCount > 0 ? true : false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ReturnBy<Employee_DocumentView>> GetPaginated(PaginationBy search)
        {
            try
            {
                string strOrder = string.IsNullOrEmpty(search.OrderBy) ? "Emp_Doc_Id" : search.OrderBy;
                string strWhere = Common.Search.WhereString(search);

                IEnumerable<Employee_DocumentView> vEmploye_Contract;
                if (!String.IsNullOrEmpty(search.CommonSearch))
                {

                    vEmploye_Contract = (from emp in adbContext.employee
                                         join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id
                                         join emp_doc in adbContext.employee_document on emp.Emp_Id equals emp_doc.Emp_Id
                                         select new Employee_DocumentView
                                         {
                                             Emp_Doc_Id = emp_doc.Emp_Doc_Id,
                                             Emp_Id = emp_doc.Emp_Id,
                                             Doc_Id = emp_doc.Doc_Id,
                                             Parent_Emp_Doc_Id = emp_doc.Parent_Emp_Doc_Id,
                                             Emp_Doc_Name = emp_doc.Emp_Doc_Name,
                                             Emp_Doc_Path = emp_doc.Emp_Doc_Path,
                                             Notes = emp_doc.Notes,
                                             isActive = emp_doc.isActive,
                                             AddedBy = emp_doc.AddedBy,
                                             UpdatedBy = emp_doc.UpdatedBy,
                                             Company_Id = emp.Company_Id
                                         }).Where(w => new[] { Convert.ToString(w.Emp_Doc_Id), w.Emp_Doc_Name.ToLower(), Convert.ToString(w.Emp_Id), w.Emp_Doc_Path.ToLower() }.Any(a => a.Contains(search.CommonSearch.ToLower()))).OrderBy(strOrder).ToList();
                }
                else
                {

                    vEmploye_Contract = (from emp in adbContext.employee
                                         join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id
                                         join emp_doc in adbContext.employee_document on emp.Emp_Id equals emp_doc.Emp_Id
                                         select new Employee_DocumentView
                                         {
                                             Emp_Doc_Id = emp_doc.Emp_Doc_Id,
                                             Emp_Id = emp_doc.Emp_Id,
                                             Doc_Id = emp_doc.Doc_Id,
                                             Parent_Emp_Doc_Id = emp_doc.Parent_Emp_Doc_Id,
                                             Emp_Doc_Name = emp_doc.Emp_Doc_Name,
                                             Emp_Doc_Path = emp_doc.Emp_Doc_Path,
                                             Notes = emp_doc.Notes,
                                             isActive = emp_doc.isActive,
                                             AddedBy = emp_doc.AddedBy,
                                             UpdatedBy = emp_doc.UpdatedBy,
                                             Company_Id = emp.Company_Id
                                         }).Where(strWhere).OrderBy(strOrder).ToList();
                }

                if (vEmploye_Contract == null || vEmploye_Contract.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                ReturnBy<Employee_DocumentView> vList = new ReturnBy<Employee_DocumentView>()
                {
                    list = vEmploye_Contract.Skip(search.PageIndex * search.PageSize).Take(search.PageSize).ToList(),
                    RecordCount = vEmploye_Contract.Count()
                };
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
