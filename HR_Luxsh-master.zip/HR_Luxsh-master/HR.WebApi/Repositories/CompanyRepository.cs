﻿using HR.WebApi.DAL;
using HR.WebApi.Exceptions;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace HR.WebApi.Repositories
{
    public class CompanyRepository<T> : ICommonRepository<Company>
    {
        private readonly ApplicationDbContext adbContext;
        private Company_ContactRepository<Company_Contact> Comp_ContactRepo;

        public CompanyRepository(ApplicationDbContext applicationDbContext, Company_ContactRepository<Company_Contact> ContactRepository)
        {
            adbContext = applicationDbContext;
            Comp_ContactRepo = ContactRepository;
        }

        public async Task<IEnumerable<Company>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<Company> vList;
                if (RecordLimit > 0)
                {
                    vList = (from comp in adbContext.company
                             select new Company
                             {
                                 Company_Id = comp.Company_Id,
                                 Company_Name = comp.Company_Name,
                                 Company_Code = comp.Company_Code,
                                 Company_Parent_Id = comp.Company_Parent_Id,
                                 Registration_Date = comp.Registration_Date,
                                 Registration_No = comp.Registration_No,
                                 Logo = comp.Logo,
                                 Currency = comp.Currency,
                                 Language = comp.Language,
                                 isActive = comp.isActive,
                                 company_contact = adbContext.company_contact.Where(w => w.Company_Id == comp.Company_Id).ToList()
                             }
                           ).Take(RecordLimit).ToList();
                }
                else
                {
                    vList = (from comp in adbContext.company
                             select new Company
                             {
                                 Company_Id = comp.Company_Id,
                                 Company_Name = comp.Company_Name,
                                 Company_Code = comp.Company_Code,
                                 Company_Parent_Id = comp.Company_Parent_Id,
                                 Registration_Date = comp.Registration_Date,
                                 Registration_No = comp.Registration_No,
                                 Logo = comp.Logo,
                                 Currency = comp.Currency,
                                 Language = comp.Language,
                                 isActive = comp.isActive,
                                 company_contact = adbContext.company_contact.Where(w => w.Company_Id == comp.Company_Id).ToList()
                             }).ToList();
                }

                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Company>> Get(int id)
        {
            try
            {
                var vList = (from comp in adbContext.company
                             where comp.Company_Id == id
                             select new Company
                             {
                                 Company_Id = comp.Company_Id,
                                 Company_Name = comp.Company_Name,
                                 Company_Code = comp.Company_Code,
                                 Company_Parent_Id = comp.Company_Parent_Id,
                                 Registration_Date = comp.Registration_Date,
                                 Registration_No = comp.Registration_No,
                                 Logo = comp.Logo,
                                 Currency = comp.Currency,
                                 Language = comp.Language,
                                 isActive = comp.isActive,
                                 company_contact = adbContext.company_contact.Where(w => w.Company_Id == comp.Company_Id).ToList()
                             }).ToList();
                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Company>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            try
            {
                IEnumerable<Company> vList;
                if (String.IsNullOrEmpty(searchValue))
                {
                    //Find Company with Paging
                    vList = (from comp in adbContext.company
                             select new Company
                             {
                                 Company_Id = comp.Company_Id,
                                 Company_Name = comp.Company_Name,
                                 Company_Code = comp.Company_Code,
                                 Company_Parent_Id = comp.Company_Parent_Id,
                                 Registration_Date = comp.Registration_Date,
                                 Registration_No = comp.Registration_No,
                                 Logo = comp.Logo,
                                 Currency = comp.Currency,
                                 Language = comp.Language,
                                 isActive = comp.isActive,
                                 company_contact = adbContext.company_contact.Where(w => w.Company_Id == comp.Company_Id).ToList()
                             }
                           ).Skip(pageIndex * pageSize).Take(pageSize).ToList();
                }
                else
                {
                    //Find Company with Paging & Searching
                    vList = (from comp in adbContext.company.Where(w => new[] { w.Company_Name, w.Company_Code }.Any(a => a.Contains(searchValue)))
                             select new Company
                             {
                                 Company_Id = comp.Company_Id,
                                 Company_Name = comp.Company_Name,
                                 Company_Code = comp.Company_Code,
                                 Company_Parent_Id = comp.Company_Parent_Id,
                                 Registration_Date = comp.Registration_Date,
                                 Registration_No = comp.Registration_No,
                                 Logo = comp.Logo,
                                 Currency = comp.Currency,
                                 Language = comp.Language,
                                 isActive = comp.isActive,
                                 company_contact = adbContext.company_contact.Where(w => w.Company_Id == comp.Company_Id).ToList()
                             }
                           ).Skip(pageIndex * pageSize).Take(pageSize).ToList();
                }
                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task UpdateLogo(string strCompanyCode, string strLogopath)
        {
            try
            {
                var vList = adbContext.company.Where(x => x.Company_Code == strCompanyCode).FirstOrDefault();
                if (vList != null)
                {
                    //D:/BnsGroup/Company_code/logo.png
                    vList.Logo = strLogopath;
                    adbContext.company.Update(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert(Company entity)
        {
            adbContext.BeginTransaction();
            try
            {
                entity.AddedOn = DateTime.Now;

                adbContext.Entry(entity).State = Microsoft.EntityFrameworkCore.EntityState.Added;
                adbContext.SaveChanges();

                if (entity.company_contact.Count() > 0)
                {
                    await Comp_ContactRepo.Insert_Multiple(entity.company_contact).ConfigureAwait(false);
                }

                //Thread.Sleep(120000);

                adbContext.CommitTransaction();
            }
            catch (Exception ex)
            {
                adbContext.RollBackTransaction();
                throw ex;
            }
        }

        public async Task Update(Company entity)
        {
            adbContext.BeginTransaction();
            try
            {
                var vList = adbContext.company.Where(x => x.Company_Id == entity.Company_Id).FirstOrDefault();
                if (vList == null)
                {
                    throw new RecoredNotFoundException("Data Not Available");
                }
                else
                {
                    vList.Company_Code = entity.Company_Code;
                    vList.Company_Name = entity.Company_Name;
                    vList.Company_Parent_Id = entity.Company_Parent_Id;
                    vList.Registration_No = entity.Registration_No;
                    vList.Registration_Date = entity.Registration_Date;

                    vList.Currency = entity.Currency;
                    vList.Language = entity.Language;

                    vList.isActive = entity.isActive;
                    vList.UpdatedBy = entity.UpdatedBy;
                    vList.UpdatedOn = DateTime.Now;

                    adbContext.company.Update(vList);
                    adbContext.SaveChanges();

                    if (entity.company_contact.Count() > 0)
                    {
                        await Comp_ContactRepo.Update_Contact(entity.company_contact);
                    }

                }

                adbContext.CommitTransaction();
            }
            catch (Exception ex)
            {
                adbContext.RollBackTransaction();
                throw ex;
            }
        }

        public async Task ToogleStatus(int id, short isActive)
        {
            adbContext.BeginTransaction();
            try
            {
                var vList = adbContext.company.Where(w => w.Company_Id == id && w.isActive != isActive).SingleOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.isActive = isActive;
                adbContext.company.Update(vList);
                adbContext.SaveChanges();

                await Comp_ContactRepo.ToogleStatus(id, isActive);

                adbContext.CommitTransaction();

            }
            catch (Exception ex)
            {
                adbContext.RollBackTransaction();
                throw ex;
            }
        }

        public async Task Delete(int id)
        {
            adbContext.BeginTransaction();
            try
            {
                var vList = adbContext.company.Where(w => w.Company_Id == id).SingleOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.isActive = 0;
                adbContext.company.Update(vList);
                adbContext.SaveChanges();

                await Comp_ContactRepo.DeleteByCompany(id);

                adbContext.CommitTransaction();
            }
            catch (Exception ex)
            {
                adbContext.RollBackTransaction();
                throw ex;
            }
        }

        public int RecordCount(string searchValue)
        {
            try
            {
                if (String.IsNullOrEmpty(searchValue))
                {
                    //Find Company all no of rows
                    var vCount = (from con in adbContext.company
                                  join c in adbContext.company_contact on con.Company_Id equals c.Company_Id
                                  select con.Company_Id
                                 ).Count();
                    return vCount;
                }
                else
                {
                    //Find Company no of rows with Searching
                    var vCount = (from con in adbContext.company.Where(w => new[] { w.Company_Name, w.Company_Code }.Any(a => a.Contains(searchValue)))
                                  join c in adbContext.company_contact on con.Company_Id equals c.Company_Id
                                  select con.Company_Id
                                 ).Count();
                    return vCount;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Exists(Company entity)
        {
            int intCount = 0;
            if (entity.Company_Id > 0) //Update Validation
                intCount = adbContext.company.Where(w => w.Company_Id != entity.Company_Id && (w.Company_Code == entity.Company_Code && w.Company_Name == entity.Company_Name)).Count();
            else //Insert Validation
                intCount = adbContext.company.Where(w => w.Company_Code == entity.Company_Code && w.Company_Name == entity.Company_Name).Count();
            return (intCount > 0 ? true : false);
        }
    }
}
