﻿using HR.WebApi.DAL;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using HR.WebApi.Exceptions;
using HR.WebApi.ModelView;
using System.Text;
using System.Linq.Dynamic.Core;

namespace HR.WebApi.Repositories
{
    public class Employee_AddressRepository<T> : ICommonRepository<Employee_Address>, IPaginated<Employee_AddressView>
    {
        private readonly ApplicationDbContext adbContext;

        public Employee_AddressRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }

        public async Task<IEnumerable<Employee_Address>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<Employee_Address> vList;
                if (RecordLimit > 0)
                    vList = adbContext.employee_address.Take(RecordLimit).ToList();
                else
                    vList = adbContext.employee_address.ToList();

                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_Address>> Get(int id)
        {
            try
            {
                IEnumerable<Employee_Address> vList = adbContext.employee_address.Where(w => w.Emp_Address_Id == id).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert(Employee_Address entity)
        {
            try
            {
                if (entity.Emp_Id == 0)
                    throw new RecoredNotFoundException("Employee Not Available");

                entity.AddedOn = DateTime.Now;
                adbContext.employee_address.Add(entity);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert_Multiple(IEnumerable<Employee_Address> entity)
        {
            try
            {
                if (entity != null && entity.Count() > 0)
                {
                    foreach (var employee in entity)
                    {
                        if (employee.Emp_Id == 0)
                            throw new RecoredNotFoundException("Employee Not Available");

                        //employee.AddedOn = DateTime.Now;
                        //adbContext.employee_address.Add(employee);
                    }
                    entity.ToList().ForEach(w => w.AddedOn = DateTime.Now);
                    adbContext.employee_address.AddRange(entity);
                    await Task.FromResult(adbContext.SaveChangesAsync());
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ToogleStatusByEmp_Id(int emp_Id, short isActive)
        {
            try
            {
                //update flag isActive
                var vList = adbContext.employee_address.Where(w => w.Emp_Id == emp_Id && w.isActive != isActive).ToList();
                if (vList.Count() > 0)
                {
                    vList.ForEach(a => a.isActive = isActive);
                    adbContext.employee_address.UpdateRange(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ToogleStatus(int id, short isActive)
        {
            try
            {
                //update flag isActive
                var vList = adbContext.employee_address.Where(w => w.Emp_Address_Id == id && w.isActive != isActive).FirstOrDefault();

                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.isActive = isActive;
                adbContext.employee_address.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Update(Employee_Address entity)
        {
            try
            {
                //Update Old Department
                var vList = adbContext.employee_address.Where(w => w.Emp_Id == entity.Emp_Id && w.Emp_Address_Id == entity.Emp_Address_Id).FirstOrDefault();

                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.Emp_Id = entity.Emp_Id;
                vList.Address_Type = entity.Address_Type;
                vList.Address1 = entity.Address1;
                vList.Address2 = entity.Address2;
                vList.Address3 = entity.Address3;
                vList.Address4 = entity.Address4;
                vList.PostCode = entity.PostCode;
                vList.City = entity.City;
                vList.State = entity.State;
                vList.Country = entity.Country;
                vList.LandlineNo = entity.LandlineNo;
                vList.isDefault = entity.isDefault;
                vList.Emp_Doc_Id = entity.Emp_Doc_Id;
                vList.isActive = entity.isActive;
                vList.UpdatedBy = entity.UpdatedBy;
                vList.UpdatedOn = DateTime.Now;

                adbContext.employee_address.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //public async Task Update_Addresses(IList<Employee_Address> entity)
        //{
        //    try
        //    {
        //        if (entity != null && entity.Count() > 0)
        //        {
        //            foreach (var employee in entity)
        //            {
        //                await Update(employee);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        public async Task DeleteByEmp_Id(int emp_Id)
        {
            try
            {
                var vList = adbContext.employee_address.Where(w => w.Emp_Id == emp_Id).ToList();
                if (vList.Count() > 0)
                {
                    vList.ForEach(w => w.isActive = 0);
                    adbContext.employee_address.UpdateRange(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Delete(int id)
        {
            try
            {
                var vList = adbContext.employee_address.Where(w => w.Emp_Address_Id == id).FirstOrDefault();

                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.isActive = 0;
                adbContext.employee_address.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_Address>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            try
            {
                IEnumerable<Employee_Address> vList;
                if (String.IsNullOrEmpty(searchValue))
                    vList = adbContext.employee_address.Skip(pageIndex * pageSize).Take(pageSize).ToList();
                else
                    vList = adbContext.employee_address.Where(w => new[] { Convert.ToString(w.Emp_Id), Convert.ToString(w.Emp_Address_Id), w.City, w.State, w.Country, w.Address1, w.Address2, w.Address3, w.Address4, w.Address_Type, w.PostCode }.Any(a => a.Contains(searchValue))).Skip(pageIndex * pageSize).Take(pageSize).ToList();

                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Data Not Available");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int RecordCount(string searchValue)
        {
            try
            {
                if (String.IsNullOrEmpty(searchValue))
                {
                    var vCount = (from emp in adbContext.employee_address
                                  select emp.Emp_Address_Id).Count();
                    return vCount;
                }
                else
                {
                    var vList = adbContext.employee_address.
                        Where(w => new[] { Convert.ToString(w.Emp_Id), Convert.ToString(w.Emp_Address_Id),
                            w.City, w.State, w.Country, w.Address1, w.Address2,
                            w.Address3, w.Address4, w.Address_Type, w.PostCode }.Any(a => a.Contains(searchValue))).Count();

                    return vList;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Exists(Employee_Address entity)
        {
            try
            {
                int intCount = 0;
                if (entity.Emp_Address_Id > 0) //Update Validation
                    intCount = adbContext.employee_address.Where(w => w.Emp_Address_Id != entity.Emp_Address_Id && w.Emp_Id == entity.Emp_Id && w.Address1 == entity.Address1 && w.Address2 == entity.Address2 && w.Address3 == entity.Address3 && w.Address4 == entity.Address4).Count();
                else //Insert Validation
                    intCount = adbContext.employee_address.Where(w => w.Address1 == entity.Address1 && w.Address2 == entity.Address2 && w.Address3 == entity.Address3 && w.Address4 == entity.Address4).Count();
                return (intCount > 0 ? true : false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ReturnBy<Employee_AddressView>> GetPaginated(PaginationBy search)
        {
            try
            {
                string strOrder = string.IsNullOrEmpty(search.OrderBy) ? "Emp_Address_Id" : search.OrderBy;
                string strWhere = Common.Search.WhereString(search);

                IEnumerable<Employee_AddressView> vEmploye_Address;
                if (!String.IsNullOrEmpty(search.CommonSearch)) {

                    vEmploye_Address = (from emp in adbContext.employee
                                        join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id
                                        join emp_Add in adbContext.employee_address on emp.Emp_Id equals emp_Add.Emp_Id
                                        select new Employee_AddressView
                                        {
                                            Emp_Address_Id = emp_Add.Emp_Address_Id,
                                            Emp_Id = emp_Add.Emp_Id,
                                            Address_Type = emp_Add.Address_Type,
                                            Address1 = emp_Add.Address1,
                                            Address2 = emp_Add.Address2,
                                            Address3 = emp_Add.Address3,
                                            Address4 = emp_Add.Address4,
                                            PostCode = emp_Add.PostCode,
                                            City = emp_Add.City,
                                            State = emp_Add.State,
                                            Country = emp_Add.Country,
                                            LandlineNo = emp_Add.LandlineNo,
                                            isDefault = emp_Add.isDefault,
                                            Emp_Doc_Id = emp_Add.Emp_Doc_Id,
                                            isActive = emp_Add.isActive,
                                            AddedBy = emp_Add.AddedBy,
                                            UpdatedBy = emp_Add.UpdatedBy,
                                            Company_Id = emp.Company_Id
                                        }).Where(w => new[] { Convert.ToString(w.Emp_Address_Id), w.Address1.ToLower(), Convert.ToString(w.Emp_Id), w.City.ToLower(), w.State.ToLower(), w.Country.ToLower() }.Any(a => a.Contains(search.CommonSearch.ToLower()))).OrderBy(strOrder).ToList();
                }
                else
                {
                    vEmploye_Address = (from emp in adbContext.employee
                                        join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id
                                        join emp_Add in adbContext.employee_address on emp.Emp_Id equals emp_Add.Emp_Id
                                        select new Employee_AddressView
                                        {
                                            Emp_Address_Id = emp_Add.Emp_Address_Id,
                                            Emp_Id = emp_Add.Emp_Id,
                                            Address_Type = emp_Add.Address_Type,
                                            Address1 = emp_Add.Address1,
                                            Address2 = emp_Add.Address2,
                                            Address3 = emp_Add.Address3,
                                            Address4 = emp_Add.Address4,
                                            PostCode = emp_Add.PostCode,
                                            City = emp_Add.City,
                                            State = emp_Add.State,
                                            Country = emp_Add.Country,
                                            LandlineNo = emp_Add.LandlineNo,
                                            isDefault = emp_Add.isDefault,
                                            Emp_Doc_Id = emp_Add.Emp_Doc_Id,
                                            isActive = emp_Add.isActive,
                                            AddedBy = emp_Add.AddedBy,
                                            UpdatedBy = emp_Add.UpdatedBy,
                                            Company_Id = emp.Company_Id
                                        }).Where(strWhere).OrderBy(strOrder).ToList();
                }
                   

                if (vEmploye_Address == null || vEmploye_Address.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                ReturnBy<Employee_AddressView> vList = new ReturnBy<Employee_AddressView>()
                {
                    list = vEmploye_Address.Skip(search.PageIndex * search.PageSize).Take(search.PageSize).ToList(),
                    RecordCount = vEmploye_Address.Count()
                };
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
