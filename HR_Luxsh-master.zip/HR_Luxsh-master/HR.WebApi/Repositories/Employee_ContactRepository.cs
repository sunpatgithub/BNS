﻿using HR.WebApi.DAL;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using HR.WebApi.Exceptions;
using HR.WebApi.ModelView;
using System.Text;
using System.Linq.Dynamic.Core;

namespace HR.WebApi.Repositories
{
    public class Employee_ContactRepository<T> : ICommonRepository<Employee_Contact>, IPaginated<Employee_ContactView>
    {
        private readonly ApplicationDbContext adbContext;

        public Employee_ContactRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }

        public async Task<IEnumerable<Employee_Contact>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<Employee_Contact> vList;
                if (RecordLimit > 0)
                    vList = adbContext.employee_contact.Take(RecordLimit).ToList();
                else
                    vList = adbContext.employee_contact.ToList();

                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_Contact>> GetByEmp_Id(int emp_Id)
        {
            try
            {
                IEnumerable<Employee_Contact> vList = adbContext.employee_contact.Where(w => w.Emp_Id == emp_Id).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<IEnumerable<Employee_Contact>> Get(int id)
        {
            try
            {
                IEnumerable<Employee_Contact> vList = adbContext.employee_contact.Where(w => w.Emp_Contact_Id == id).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert(Employee_Contact entity)
        {
            try
            {
                if (entity == null || entity.Emp_Id == 0)
                    throw new RecoredNotFoundException("Employee Not Available");

                entity.AddedOn = DateTime.Now;
                adbContext.employee_contact.Add(entity);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task Insert_Multiple(IEnumerable<Employee_Contact> entity)
        {
            try
            {
                if (entity != null && entity.Count() > 0)
                {
                    foreach (var employee in entity)
                    {
                        if (employee.Emp_Id == 0)
                            throw new RecoredNotFoundException("Employee Not Available");
                    }
                    entity.ToList().ForEach(w => w.AddedOn = DateTime.Now);
                    adbContext.employee_contact.AddRange(entity);
                    await Task.FromResult(adbContext.SaveChangesAsync());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Update(Employee_Contact entity)
        {
            try
            {
                var lstEmp_contact = adbContext.employee_contact.Where(x => x.Emp_Contact_Id == entity.Emp_Contact_Id && x.Emp_Id == entity.Emp_Id).FirstOrDefault();

                if (lstEmp_contact == null)
                    throw new RecoredNotFoundException("Data Not Available");

                lstEmp_contact.Emp_Id = entity.Emp_Id;
                lstEmp_contact.Contact_Type = entity.Contact_Type;
                lstEmp_contact.Contact_Value = entity.Contact_Value;
                lstEmp_contact.isDefault = entity.isDefault;
                lstEmp_contact.Version_Id = entity.Version_Id;

                lstEmp_contact.isActive = entity.isActive;
                lstEmp_contact.UpdatedBy = entity.UpdatedBy;
                lstEmp_contact.UpdatedOn = DateTime.Now;

                adbContext.employee_contact.Update(lstEmp_contact);
                await Task.FromResult(adbContext.SaveChanges());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Update_Contact(IList<Employee_Contact> entity)
        {
            try
            {
                if (entity != null && entity.Count() > 0)
                {
                    foreach (var employee in entity)
                    {
                        if (employee.Emp_Id == 0)
                            throw new RecoredNotFoundException("Employee Not Available");
                        await Update(employee);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ToogleStatusByEmp_Id(int emp_Id, short isActive)
        {
            try
            {
                //update flag isActive
                var vList = adbContext.employee_contact.Where(w => w.Emp_Id == emp_Id && w.isActive != isActive).ToList();
                if (vList.Count() > 0)
                {
                    vList.ForEach(w => w.isActive = isActive);
                    adbContext.employee_contact.UpdateRange(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ToogleStatus(int id, short isActive)
        {
            try
            {
                //update flag isActive
                var vList = adbContext.employee_contact.Where(w => w.Emp_Contact_Id == id && w.isActive != isActive).FirstOrDefault();

                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.isActive = isActive;
                adbContext.employee_contact.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task DeleteByEmp_Id(int emp_Id)
        {
            try
            {
                var vList = adbContext.employee_contact.Where(w => w.Emp_Id == emp_Id).ToList();
                if (vList.Count() > 0)
                {
                    vList.ForEach(w => w.isActive = 0);
                    adbContext.employee_contact.UpdateRange(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Delete(int id)
        {
            try
            {
                var vList = adbContext.employee_contact.Where(w => w.Emp_Contact_Id == id).FirstOrDefault();

                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.isActive = 0;
                adbContext.employee_contact.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<IEnumerable<Employee_Contact>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            try
            {
                IEnumerable<Employee_Contact> vList;
                if (String.IsNullOrEmpty(searchValue))
                    vList = adbContext.employee_contact.Skip(pageIndex * pageSize).Take(pageSize).ToList();
                else
                    vList = adbContext.employee_contact.Where(w => new[] { Convert.ToString(w.Emp_Id), w.Contact_Type, w.Contact_Value, w.Version_Id }.Any(a => a.Contains(searchValue))).Skip(pageIndex * pageSize).Take(pageSize).ToList();

                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Data Not Available");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int RecordCount(string searchValue)
        {
            try
            {
                if (String.IsNullOrEmpty(searchValue))
                {
                    var vCount = (from emp in adbContext.employee_contact
                                  select emp.Emp_Contact_Id).Count();
                    return vCount;
                }
                else
                {
                    var vList = adbContext.employee_contact.
                        Where(w => new[] { Convert.ToString(w.Emp_Id), w.Contact_Type, w.Contact_Value, w.Version_Id }.Any(a => a.Contains(searchValue))).Count();

                    return vList;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Exists(Employee_Contact entity)
        {
            try
            {
                int intCount = 0;
                if (entity.Emp_Contact_Id > 0) //Update Validation
                    intCount = adbContext.employee_contact.Where(w => w.Emp_Contact_Id != entity.Emp_Contact_Id && w.Emp_Id == entity.Emp_Id && w.Contact_Type == entity.Contact_Type && w.Contact_Value == entity.Contact_Value).Count();
                else //Insert Validation
                    intCount = adbContext.employee_contact.Where(w => w.Emp_Id == entity.Emp_Id && w.Contact_Type == entity.Contact_Type && w.Contact_Value == entity.Contact_Value).Count();
                return (intCount > 0 ? true : false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ReturnBy<Employee_ContactView>> GetPaginated(PaginationBy search)
        {
            try
            {
                string strOrder = string.IsNullOrEmpty(search.OrderBy) ? "Emp_Contact_Id" : search.OrderBy;
                string strWhere = Common.Search.WhereString(search);

                IEnumerable<Employee_ContactView> vEmploye_Contact;
                if (!String.IsNullOrEmpty(search.CommonSearch))
                {
                    vEmploye_Contact = (from emp in adbContext.employee
                                        join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id
                                        join emp_Contact in adbContext.employee_contact on emp.Emp_Id equals emp_Contact.Emp_Id
                                        select new Employee_ContactView
                                        {
                                            Emp_Contact_Id = emp_Contact.Emp_Contact_Id,
                                            Emp_Id = emp_Contact.Emp_Id,
                                            Contact_Type = emp_Contact.Contact_Type,
                                            Contact_Value = emp_Contact.Contact_Value,
                                            isDefault = emp_Contact.isDefault,
                                            Version_Id = emp_Contact.Version_Id,
                                            isActive = emp_Contact.isActive,
                                            AddedBy = emp_Contact.AddedBy,
                                            UpdatedBy = emp_Contact.UpdatedBy,
                                            Company_Id = emp.Company_Id
                                        }).Where(w => new[] { Convert.ToString(w.Emp_Contact_Id), w.Contact_Type.ToLower(), Convert.ToString(w.Emp_Id), w.Contact_Value.ToLower() }.Any(a => a.Contains(search.CommonSearch.ToLower()))).OrderBy(strOrder).ToList();
                }
                else
                {
                    vEmploye_Contact = (from emp in adbContext.employee
                                        join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id
                                        join emp_Contact in adbContext.employee_contact on emp.Emp_Id equals emp_Contact.Emp_Id
                                        select new Employee_ContactView
                                        {
                                            Emp_Contact_Id = emp_Contact.Emp_Contact_Id,
                                            Emp_Id = emp_Contact.Emp_Id,
                                            Contact_Type = emp_Contact.Contact_Type,
                                            Contact_Value = emp_Contact.Contact_Value,
                                            isDefault = emp_Contact.isDefault,
                                            Version_Id = emp_Contact.Version_Id,
                                            isActive = emp_Contact.isActive,
                                            AddedBy = emp_Contact.AddedBy,
                                            UpdatedBy = emp_Contact.UpdatedBy,
                                            Company_Id = emp.Company_Id
                                        }).Where(strWhere).OrderBy(strOrder).ToList();
                }
                if (vEmploye_Contact == null || vEmploye_Contact.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                ReturnBy<Employee_ContactView> vList = new ReturnBy<Employee_ContactView>()
                {
                    list = vEmploye_Contact.Skip(search.PageIndex * search.PageSize).Take(search.PageSize).ToList(),
                    RecordCount = vEmploye_Contact.Count()
                };
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
