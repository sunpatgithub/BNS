﻿using HR.WebApi.DAL;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using HR.WebApi.Exceptions;
using HR.WebApi.ModelView;
using System.Text;
using System.Linq.Dynamic.Core;

namespace HR.WebApi.Repositories
{
    public class Employee_ReferenceRepository<T> : ICommonRepository<Employee_Reference>, IPaginated<Employee_ReferenceView>
    {
        private readonly ApplicationDbContext adbContext;

        public Employee_ReferenceRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }


        public async Task<IEnumerable<Employee_Reference>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<Employee_Reference> vList;
                if (RecordLimit > 0)
                    vList = adbContext.employee_reference.Take(RecordLimit).ToList();
                else
                    vList = adbContext.employee_reference.ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_Reference>> GetByEmp_Id(int emp_Id)
        {
            try
            {
                IEnumerable<Employee_Reference> vList = adbContext.employee_reference.Where(w => w.Emp_Id == emp_Id).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_Reference>> Get(int id)
        {
            try
            {
                IEnumerable<Employee_Reference> vList = adbContext.employee_reference.Where(w => w.Emp_Ref_Id == id).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert(Employee_Reference entity)
        {
            try
            {
                if (entity.Emp_Id == 0)
                    throw new RecoredNotFoundException("Employee Not Available");

                entity.AddedOn = DateTime.Now;
                adbContext.employee_reference.Add(entity);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert_Multiple(IEnumerable<Employee_Reference> entity)
        {
            try
            {
                if (entity != null && entity.Count() > 0)
                {
                    foreach (var employee in entity)
                    {
                        if (employee.Emp_Id == 0)
                            throw new RecoredNotFoundException("Employee Not Available");
                    }
                    entity.ToList().ForEach(w => w.AddedOn = DateTime.Now);
                    adbContext.employee_reference.AddRange(entity);
                    await Task.FromResult(adbContext.SaveChangesAsync());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Update(Employee_Reference entity)
        {
            try
            {
                var vList = adbContext.employee_reference.Where(x => x.Emp_Ref_Id == entity.Emp_Ref_Id && x.Emp_Id == entity.Emp_Id).FirstOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.Emp_Id = entity.Emp_Id;
                vList.Ref_Name = entity.Ref_Name;
                vList.Ref_ContactNo = entity.Ref_ContactNo;
                vList.Ref_Relationship = entity.Ref_Relationship;

                vList.isActive = entity.isActive;
                vList.UpdatedBy = entity.UpdatedBy;
                vList.UpdatedOn = DateTime.Now;

                adbContext.employee_reference.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Update_Reference(IList<Employee_Reference> entity)
        {
            try
            {
                if (entity != null && entity.Count() > 0)
                {
                    foreach (var employee in entity)
                    {
                        if (employee.Emp_Id == 0)
                            throw new RecoredNotFoundException("Employee Not Available");
                        await Update(employee);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task ToogleStatusByEmp_Id(int emp_Id, short isActive)
        {
            try
            {
                //update flag isActive
                var vList = adbContext.employee_reference.Where(w => w.Emp_Id == emp_Id && w.isActive != isActive).ToList();
                if (vList.Count() > 0)
                {
                    vList.ForEach(w => w.isActive = isActive);
                    adbContext.employee_reference.UpdateRange(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ToogleStatus(int id, short isActive)
        {
            try
            {
                //update flag isActive
                var vList = adbContext.employee_reference.Where(w => w.Emp_Ref_Id == id && w.isActive != isActive).FirstOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.isActive = isActive;
                adbContext.employee_reference.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task DeleteByEmp_Id(int emp_Id)
        {
            try
            {
                var vList = adbContext.employee_reference.Where(w => w.Emp_Id == emp_Id).ToList();
                if (vList.Count() > 0)
                {
                    vList.ForEach(w => w.isActive = 0);
                    adbContext.employee_reference.UpdateRange(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Delete(int id)
        {
            try
            {
                var vList = adbContext.employee_reference.Where(w => w.Emp_Ref_Id == id).FirstOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.isActive = 0;
                adbContext.employee_reference.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_Reference>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            try
            {
                IEnumerable<Employee_Reference> vList;
                if (String.IsNullOrEmpty(searchValue))
                    vList = adbContext.employee_reference.Skip(pageIndex * pageSize).Take(pageSize).ToList();
                else
                    vList = adbContext.employee_reference.Where(w => new[] { Convert.ToString(w.Emp_Id), w.Ref_Name, w.Ref_ContactNo, w.Ref_Relationship }.Any(a => a.Contains(searchValue))).Skip(pageIndex * pageSize).Take(pageSize).ToList();

                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Data Not Available");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int RecordCount(string searchValue)
        {
            try
            {
                if (String.IsNullOrEmpty(searchValue))
                {
                    var vCount = (from emp in adbContext.employee_reference
                                  select emp.Emp_Ref_Id).Count();
                    return vCount;
                }
                else
                {
                    var vList = adbContext.employee_reference.
                        Where(w => new[] { Convert.ToString(w.Emp_Id), w.Ref_Name, w.Ref_ContactNo, w.Ref_Relationship }.Any(a => a.Contains(searchValue))).Count();

                    return vList;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Exists(Employee_Reference entity)
        {
            try
            {
                int intCount = 0;
                if (entity.Emp_Ref_Id > 0) //Update Validation
                    intCount = adbContext.employee_reference.Where(w => w.Emp_Ref_Id != entity.Emp_Ref_Id && w.Emp_Id == entity.Emp_Id && w.Ref_Name == entity.Ref_Name && w.Ref_ContactNo == entity.Ref_ContactNo && w.Ref_Relationship == entity.Ref_Relationship).Count();
                else //Insert Validation
                    intCount = adbContext.employee_reference.Where(w => w.Emp_Id == entity.Emp_Id && w.Ref_Name == entity.Ref_Name && w.Ref_ContactNo == entity.Ref_ContactNo && w.Ref_Relationship == entity.Ref_Relationship).Count();
                return (intCount > 0 ? true : false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ReturnBy<Employee_ReferenceView>> GetPaginated(PaginationBy search)
        {
            try
            {
                string strOrder = string.IsNullOrEmpty(search.OrderBy) ? "Emp_Ref_Id" : search.OrderBy;
                string strWhere = Common.Search.WhereString(search);

                IEnumerable<Employee_ReferenceView> vEmploye_Reference;
                if (!String.IsNullOrEmpty(search.CommonSearch))
                {
                    vEmploye_Reference = (from emp in adbContext.employee
                                          join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id
                                          join emp_ref in adbContext.employee_reference on emp.Emp_Id equals emp_ref.Emp_Id
                                          select new Employee_ReferenceView
                                          {
                                              Emp_Ref_Id = emp_ref.Emp_Ref_Id,
                                              Emp_Id = emp_ref.Emp_Id,
                                              Ref_Name = emp_ref.Ref_Name,
                                              Ref_ContactNo = emp_ref.Ref_ContactNo,
                                              Ref_Relationship = emp_ref.Ref_Relationship,
                                              isActive = emp_ref.isActive,
                                              AddedBy = emp_ref.AddedBy,
                                              UpdatedBy = emp_ref.UpdatedBy,
                                              Company_Id = emp.Company_Id
                                          }).Where(w => new[] { Convert.ToString(w.Emp_Ref_Id), w.Ref_Name.ToLower(), Convert.ToString(w.Emp_Id),w.Ref_ContactNo.ToLower(),w.Ref_Relationship.ToLower() }.Any(a => a.Contains(search.CommonSearch.ToLower()))).OrderBy(strOrder).ToList();
                }
                else
                {
                    vEmploye_Reference = (from emp in adbContext.employee
                                          join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id
                                          join emp_ref in adbContext.employee_reference on emp.Emp_Id equals emp_ref.Emp_Id
                                          select new Employee_ReferenceView
                                          {
                                              Emp_Ref_Id = emp_ref.Emp_Ref_Id,
                                              Emp_Id = emp_ref.Emp_Id,
                                              Ref_Name = emp_ref.Ref_Name,
                                              Ref_ContactNo = emp_ref.Ref_ContactNo,
                                              Ref_Relationship = emp_ref.Ref_Relationship,
                                              isActive = emp_ref.isActive,
                                              AddedBy = emp_ref.AddedBy,
                                              UpdatedBy = emp_ref.UpdatedBy,
                                              Company_Id = emp.Company_Id
                                          }).Where(strWhere).OrderBy(strOrder).ToList();

                }

                if (vEmploye_Reference == null || vEmploye_Reference.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                ReturnBy<Employee_ReferenceView> vList = new ReturnBy<Employee_ReferenceView>()
                {
                    list = vEmploye_Reference.Skip(search.PageIndex * search.PageSize).Take(search.PageSize).ToList(),
                    RecordCount = vEmploye_Reference.Count()
                };
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
