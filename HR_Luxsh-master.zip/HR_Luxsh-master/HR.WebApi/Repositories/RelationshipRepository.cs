﻿using HR.WebApi.DAL;
using HR.WebApi.Exceptions;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HR.WebApi.Repositories
{
    public class RelationshipRepository<T> : ICommonRepository<Relationship>
    {
        private readonly ApplicationDbContext adbContext;

        public RelationshipRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }

        public async Task<IEnumerable<Relationship>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<Relationship> vList;
                if (RecordLimit > 0)
                    vList = adbContext.relationship.Take(RecordLimit).ToList();
                else
                    vList = adbContext.relationship.ToList();
                
                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<IEnumerable<Relationship>> Get(int id)
        {
            try
            {
                var vList = adbContext.relationship.Where(w => w.Id == id).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        public Task<IEnumerable<Relationship>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            throw new NotImplementedException();
        }
        
        public async Task Insert(Relationship entity)
        {
            try
            {
                entity.AddedOn = DateTime.Now;
                adbContext.relationship.Add(entity);

                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public Task Update(Relationship entity)
        {
            throw new NotImplementedException();
        }
        public async Task ToogleStatus(int id, short isActive)
        {
            try
            {
                //update flag isActive=0
                var vList = adbContext.relationship.Where(w => w.Id == id && w.isActive != isActive).SingleOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.isActive = isActive;
                adbContext.relationship.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task Delete(int id)
        {
            try
            {
                //Delete Relationship
                var vList = adbContext.relationship.Where(w => w.Id == id).SingleOrDefault();
                
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");
                
                adbContext.relationship.Remove(vList);
                await Task.FromResult(adbContext.SaveChanges());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool Exists(Relationship entity)
        {
            try
            {
                int intCount = 0;
                if (entity.Id > 0) //Update Validation
                    intCount = adbContext.relationship.Where(w => w.Id != entity.Id && (w.Name == entity.Name)).Count();
                else //Insert Validation
                    intCount = adbContext.relationship.Where(w => w.Name == entity.Name).Count();
                return (intCount > 0 ? true : false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int RecordCount(string searchValue)
        {
            throw new NotImplementedException();
        }
    }
}
