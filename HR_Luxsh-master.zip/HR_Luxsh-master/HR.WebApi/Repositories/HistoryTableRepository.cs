﻿using HR.WebApi.DAL;
using HR.WebApi.Exceptions;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using HR.WebApi.ModelView;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Text;
using System.Threading.Tasks;

//Data Will Only Added in this module from the Trigger

namespace HR.WebApi.Repositories
{
    public class HistoryTableRepository<T> : ICommonRepository<HistoryTable>,IPaginated<HistoryTable>
    {
        private readonly ApplicationDbContext adbContext;

        public HistoryTableRepository(ApplicationDbContext applicationDbContext)
        { 
            adbContext = applicationDbContext;
        }

        public async Task<IEnumerable<HistoryTable>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<HistoryTable> vList;
                if (RecordLimit > 0)
                    vList = adbContext.historytable.Take(RecordLimit).ToList();
                else
                    vList = adbContext.historytable.ToList();
                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<HistoryTable>> Get(int id)
        {
            try
            {
                var vList = adbContext.historytable.Where(w => w.Id == id).ToList();
                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ReturnBy<HistoryTable>> GetPaginated(PaginationBy search)
        {
            try
            {
                StringBuilder sbWhr = new StringBuilder();
                foreach (var vAry in search.searchBy)
                    sbWhr.AppendFormat("{0} {1} {2} {3} ", vAry.FieldName, vAry.Parameter, vAry.FieldValue, vAry.ConditionWith);

                var vHistory = adbContext.historytable.Where(sbWhr.ToString()).OrderBy(string.IsNullOrEmpty(search.OrderBy) ? "Id" : search.OrderBy).ToList();

                if (vHistory.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                ReturnBy<HistoryTable> vList = new ReturnBy<HistoryTable>()
                {
                    list = vHistory.Skip(search.PageIndex * search.PageSize).Take(search.PageSize).ToList(),
                    RecordCount = vHistory.Count()
                };
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<HistoryTable>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            try
            {
                IEnumerable<HistoryTable> vList;
                if (String.IsNullOrEmpty(searchValue))
                    vList = adbContext.historytable.Skip(pageIndex * pageSize).Take(pageSize).ToList();
                else
                    vList = adbContext.historytable.Where(w => new[] { w.TableName.ToLower(), w.OldValue.ToLower() }.Any(a => a.Contains(searchValue.ToLower()))).Skip(pageIndex * pageSize).Take(pageSize).ToList();

                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Task Insert(HistoryTable entity)
        {
            throw new NotImplementedException();
        }

        public Task Update(HistoryTable entity)
        {
            throw new NotImplementedException();
        }
        
        public Task ToogleStatus(int id, short isActive)
        {
            throw new NotImplementedException();
        }

        public Task Delete(int id)
        {
            throw new NotImplementedException();
        }

        public int RecordCount(string searchValue)
        {
            throw new NotImplementedException();
        }

        public bool Exists(HistoryTable entity)
        {
            throw new NotImplementedException();
        }
    }
}
