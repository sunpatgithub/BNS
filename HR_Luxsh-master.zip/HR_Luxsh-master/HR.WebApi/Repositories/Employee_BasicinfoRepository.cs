﻿using HR.WebApi.DAL;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using HR.WebApi.Exceptions;
using HR.WebApi.ModelView;
using System.Text;
using System.Linq.Dynamic.Core;

namespace HR.WebApi.Repositories
{
    public class Employee_BasicInfoRepository<T> : ICommonRepository<Employee_BasicInfo>, IPaginated<Employee_BasicInfoView>
    {
        private readonly ApplicationDbContext adbContext;

        public Employee_BasicInfoRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }

        public async Task<IEnumerable<Employee_BasicInfo>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<Employee_BasicInfo> vList;
                if (RecordLimit > 0)
                    vList = adbContext.employee_basicinfo.Take(RecordLimit).ToList();
                else
                    vList = adbContext.employee_basicinfo.ToList();

                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_BasicInfo>> GetByEmp_Id(int emp_Id)
        {
            try
            {
                IEnumerable<Employee_BasicInfo> vList = adbContext.employee_basicinfo.Where(w => w.Emp_Id == emp_Id).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<IEnumerable<Employee_BasicInfo>> Get(int id)
        {
            try
            {
                IEnumerable<Employee_BasicInfo> vList = adbContext.employee_basicinfo.Where(w => w.BasicInfo_Id == id).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert(Employee_BasicInfo entity)
        {
            try
            {
                if (entity == null)
                    throw new RecoredNotFoundException("BasicInfo Not Available");

                if (entity.Emp_Id == 0)
                    throw new RecoredNotFoundException("Employee Not Available");

                entity.AddedOn = DateTime.Now;
                adbContext.employee_basicinfo.Add(entity);
                await Task.FromResult(adbContext.SaveChangesAsync());

            }

            catch (Exception ex)
            {

                throw ex;
            }
        }
        public async Task Insert_Multiple(IList<Employee_BasicInfo> entity)
        {
            try
            {
                if (entity != null && entity.Count() > 0)
                {
                    foreach (var employee in entity)
                    {
                        if (employee.Emp_Id == 0)
                            throw new RecoredNotFoundException("Employee Not Available");

                        employee.AddedOn = DateTime.Now;
                        adbContext.employee_basicinfo.Add(employee);
                    }
                }

                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Update(Employee_BasicInfo entity)
        {
            try
            {
                var lstEmp_basicinfo = adbContext.employee_basicinfo.Where(x => x.BasicInfo_Id == entity.BasicInfo_Id && x.Emp_Id == entity.Emp_Id).FirstOrDefault();

                if (lstEmp_basicinfo == null)
                    throw new RecoredNotFoundException("Data Not Available");

                lstEmp_basicinfo.Emp_Id = entity.Emp_Id;
                lstEmp_basicinfo.FirstName = entity.FirstName;
                lstEmp_basicinfo.MiddleName = entity.MiddleName;
                lstEmp_basicinfo.LastName = entity.LastName;
                lstEmp_basicinfo.Title = entity.Title;
                lstEmp_basicinfo.DOB = entity.DOB;
                lstEmp_basicinfo.Gender = entity.Gender;
                lstEmp_basicinfo.BloodGroup = entity.BloodGroup;
                lstEmp_basicinfo.Nationality = entity.Nationality;
                lstEmp_basicinfo.Ethnicity_Code = entity.Ethnicity_Code;
                lstEmp_basicinfo.Version_Id = entity.Version_Id;


                lstEmp_basicinfo.isActive = entity.isActive;
                lstEmp_basicinfo.UpdatedBy = entity.UpdatedBy;
                lstEmp_basicinfo.UpdatedOn = DateTime.Now;

                adbContext.employee_basicinfo.Update(lstEmp_basicinfo);
                await Task.FromResult(adbContext.SaveChanges());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task ToogleStatusByEmp_Id(int emp_Id, short isActive)
        {
            try
            {
                //update flag isActive
                var vList = adbContext.employee_basicinfo.Where(w => w.Emp_Id == emp_Id && w.isActive != isActive).ToList();
                if (vList.Count() > 0)
                {
                    vList.ForEach(w => w.isActive = isActive);
                    adbContext.employee_basicinfo.UpdateRange(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ToogleStatus(int id, short isActive)
        {
            try
            {
                //update flag isActive
                var vList = adbContext.employee_basicinfo.Where(w => w.BasicInfo_Id == id && w.isActive != isActive).FirstOrDefault();

                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.isActive = isActive;
                adbContext.employee_basicinfo.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task DeleteByEmp_Id(int emp_Id)
        {
            try
            {
                var vList = adbContext.employee_basicinfo.Where(w => w.Emp_Id == emp_Id).ToList();
                if (vList.Count() > 0)
                {
                    vList.ForEach(w => w.isActive = 0);
                    adbContext.employee_basicinfo.UpdateRange(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Delete(int id)
        {
            try
            {
                var vList = adbContext.employee_basicinfo.Where(w => w.BasicInfo_Id == id).FirstOrDefault();

                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.isActive = 0;
                adbContext.employee_basicinfo.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_BasicInfo>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            try
            {
                IEnumerable<Employee_BasicInfo> vList;
                if (String.IsNullOrEmpty(searchValue))
                    vList = adbContext.employee_basicinfo.Skip(pageIndex * pageSize).Take(pageSize).ToList();
                else
                    vList = adbContext.employee_basicinfo.Where(w => new[] { Convert.ToString(w.Emp_Id), w.FirstName, w.MiddleName, w.LastName, w.Title, w.Gender, w.BloodGroup, w.Nationality, w.Ethnicity_Code, w.Version_Id }.Any(a => a.Contains(searchValue))).Skip(pageIndex * pageSize).Take(pageSize).ToList();

                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Data Not Available");
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int RecordCount(string searchValue)
        {
            try
            {
                if (String.IsNullOrEmpty(searchValue))
                {
                    var vCount = (from emp in adbContext.employee_basicinfo
                                  select emp.BasicInfo_Id).Count();
                    return vCount;
                }
                else
                {
                    var vList = adbContext.employee_basicinfo.
                        Where(w => new[] { Convert.ToString(w.Emp_Id), w.FirstName, w.MiddleName, w.LastName, w.Title, w.Gender, w.BloodGroup, w.Nationality, w.Ethnicity_Code, w.Version_Id }.Any(a => a.Contains(searchValue))).Count();

                    return vList;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Exists(Employee_BasicInfo entity)
        {
            try
            {
                int intCount = 0;
                if (entity.BasicInfo_Id > 0) //Update Validation
                    intCount = adbContext.employee_basicinfo.Where(w => w.BasicInfo_Id != entity.BasicInfo_Id && w.Emp_Id == entity.Emp_Id && w.FirstName == entity.FirstName && w.MiddleName == entity.MiddleName && w.LastName == entity.LastName).Count();
                else //Insert Validation
                    intCount = adbContext.employee_basicinfo.Where(w => w.Emp_Id == entity.Emp_Id && w.FirstName == entity.FirstName && w.MiddleName == entity.MiddleName && w.LastName == entity.LastName).Count();
                return (intCount > 0 ? true : false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ReturnBy<Employee_BasicInfoView>> GetPaginated(PaginationBy search)
        {
            try
            {
                string strOrder = string.IsNullOrEmpty(search.OrderBy) ? "BasicInfo_Id" : search.OrderBy;
                string strWhere = Common.Search.WhereString(search);

                IEnumerable<Employee_BasicInfoView> vEmploye_BasicInfo;
                if (!String.IsNullOrEmpty(search.CommonSearch))
                {
                    vEmploye_BasicInfo = (from emp in adbContext.employee
                                          join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id
                                          join emp_BasicInfo in adbContext.employee_basicinfo on emp.Emp_Id equals emp_BasicInfo.Emp_Id
                                          select new Employee_BasicInfoView
                                          {
                                              BasicInfo_Id = emp_BasicInfo.BasicInfo_Id,
                                              Emp_Id = emp_BasicInfo.Emp_Id,
                                              FirstName = emp_BasicInfo.FirstName,
                                              MiddleName = emp_BasicInfo.MiddleName,
                                              LastName = emp_BasicInfo.LastName,
                                              Title = emp_BasicInfo.Title,
                                              DOB = emp_BasicInfo.DOB,
                                              Gender = emp_BasicInfo.Gender,
                                              BloodGroup = emp_BasicInfo.BloodGroup,
                                              Nationality = emp_BasicInfo.Nationality,
                                              Ethnicity_Code = emp_BasicInfo.Ethnicity_Code,
                                              Version_Id = emp_BasicInfo.Version_Id,
                                              isActive = emp_BasicInfo.isActive,
                                              AddedBy = emp_BasicInfo.AddedBy,
                                              UpdatedBy = emp_BasicInfo.UpdatedBy,
                                              Company_Id = emp.Company_Id
                                          }).Where(w => new[] { Convert.ToString(w.BasicInfo_Id), w.FirstName.ToLower(), Convert.ToString(w.Emp_Id), w.MiddleName.ToLower(), w.Gender.ToLower(), w.LastName.ToLower(),w.Nationality.ToLower() }.Any(a => a.Contains(search.CommonSearch.ToLower()))).OrderBy(strOrder).ToList();
                }
                else
                {
                    vEmploye_BasicInfo = (from emp in adbContext.employee
                                          join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id
                                          join emp_BasicInfo in adbContext.employee_basicinfo on emp.Emp_Id equals emp_BasicInfo.Emp_Id
                                          select new Employee_BasicInfoView
                                          {
                                              BasicInfo_Id = emp_BasicInfo.BasicInfo_Id,
                                              Emp_Id = emp_BasicInfo.Emp_Id,
                                              FirstName = emp_BasicInfo.FirstName,
                                              MiddleName = emp_BasicInfo.MiddleName,
                                              LastName = emp_BasicInfo.LastName,
                                              Title = emp_BasicInfo.Title,
                                              DOB = emp_BasicInfo.DOB,
                                              Gender = emp_BasicInfo.Gender,
                                              BloodGroup = emp_BasicInfo.BloodGroup,
                                              Nationality = emp_BasicInfo.Nationality,
                                              Ethnicity_Code = emp_BasicInfo.Ethnicity_Code,
                                              Version_Id = emp_BasicInfo.Version_Id,
                                              isActive = emp_BasicInfo.isActive,
                                              AddedBy = emp_BasicInfo.AddedBy,
                                              UpdatedBy = emp_BasicInfo.UpdatedBy,
                                              Company_Id = emp.Company_Id
                                          }).Where(strWhere).OrderBy(strOrder).ToList();
                }

                   

                if (vEmploye_BasicInfo == null || vEmploye_BasicInfo.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                ReturnBy<Employee_BasicInfoView> vList = new ReturnBy<Employee_BasicInfoView>()
                {
                    list = vEmploye_BasicInfo.Skip(search.PageIndex * search.PageSize).Take(search.PageSize).ToList(),
                    RecordCount = vEmploye_BasicInfo.Count()
                };
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
