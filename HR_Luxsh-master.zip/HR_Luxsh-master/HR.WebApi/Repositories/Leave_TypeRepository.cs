﻿using HR.WebApi.DAL;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HR.WebApi.Repositories
{
    public class Leave_TypeRepository<T> : ICommonRepository<Leave_Type>
    {
        private readonly ApplicationDbContext adbContext;

        public Leave_TypeRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }
        public Task Delete(int id)
        {
            throw new NotImplementedException();
        }

        public bool Exists(Leave_Type entity)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Leave_Type> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<Leave_Type>> Get(int id)
        {
            try
            {
                IList<Leave_Type> lstLeaveType = adbContext.leave_type.AsEnumerable<Leave_Type>().Where(w => w.leave_type_id == id).ToList();

                return await Task.FromResult(lstLeaveType);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Leave_Type>> GetAll(int RecordLimit)
        {
            try
            {
                IList<Leave_Type> lstLeaveType = adbContext.leave_type.AsEnumerable<Leave_Type>().Take(RecordLimit).ToList();

                return await Task.FromResult(lstLeaveType);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert(Leave_Type entity)
        {
            try
            {
                await adbContext.leave_type.AddAsync(entity);

                adbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int RecordCount(string searchValue)
        {
            throw new NotImplementedException();
        }

        public Task ToogleStatus(int id, short isActive)
        {
            throw new NotImplementedException();
        }

        public async Task Update(Leave_Type entity)
        {
            try
            {
                var lstLeaveType = adbContext.leave_type.Where(x => x.leave_type_id == entity.leave_type_id).FirstOrDefault();

                if (lstLeaveType != null)
                {
                    lstLeaveType.leave_type = entity.leave_type;
                    lstLeaveType.is_active = entity.is_active;
                    lstLeaveType.is_carry_forward = entity.is_carry_forward;
                    lstLeaveType.is_encashment_percentage = entity.is_encashment_percentage;
                    lstLeaveType.no_of_leave = entity.no_of_leave;

                    adbContext.leave_type.Update(lstLeaveType);
                    await adbContext.SaveChangesAsync();

                }
                else
                {
                    throw new Exception("Data Not Available");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        Task<IEnumerable<Leave_Type>> ICommonRepository<Leave_Type>.FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            throw new NotImplementedException();
        }
    }
}
