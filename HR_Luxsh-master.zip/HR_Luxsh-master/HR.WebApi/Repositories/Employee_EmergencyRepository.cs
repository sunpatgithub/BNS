﻿using HR.WebApi.DAL;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using HR.WebApi.Exceptions;
using HR.WebApi.ModelView;
using System.Text;
using System.Linq.Dynamic.Core;

namespace HR.WebApi.Repositories
{
    public class Employee_EmergencyRepository<T> : ICommonRepository<Employee_Emergency>, IPaginated<Employee_EmergencyView>
    {
        private readonly ApplicationDbContext adbContext;

        public Employee_EmergencyRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }


        public async Task<IEnumerable<Employee_Emergency>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<Employee_Emergency> vList;
                if (RecordLimit > 0)
                    vList = adbContext.employee_emergency.Take(RecordLimit).ToList();
                else
                    vList = adbContext.employee_emergency.ToList();

                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_Emergency>> GetByEmp_Id(int emp_Id)
        {
            try
            {
                IEnumerable<Employee_Emergency> vList = adbContext.employee_emergency.Where(w => w.Emp_Id == emp_Id).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_Emergency>> Get(int id)
        {
            try
            {
                IEnumerable<Employee_Emergency> vList = adbContext.employee_emergency.Where(w => w.Emp_Emergency_Id == id).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert(Employee_Emergency entity)
        {
            try
            {
                if (entity.Emp_Id == 0)
                    throw new RecoredNotFoundException("Employee Not Available");

                entity.AddedOn = DateTime.Now;
                adbContext.employee_emergency.Add(entity);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert_Multiple(IEnumerable<Employee_Emergency> entity)
        {
            try
            {
                if (entity != null && entity.Count() > 0)
                {
                    foreach (var employee in entity)
                    {
                        if (employee.Emp_Id == 0)
                            throw new RecoredNotFoundException("Employee Not Available");
                    }
                    entity.ToList().ForEach(w => w.AddedOn = DateTime.Now);
                    adbContext.employee_emergency.AddRange(entity);
                    await Task.FromResult(adbContext.SaveChangesAsync());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Update(Employee_Emergency entity)
        {
            try
            {
                var lstEmp_EmergencyDetail = adbContext.employee_emergency.Where(x => x.Emp_Emergency_Id == entity.Emp_Emergency_Id && x.Emp_Id == entity.Emp_Id).FirstOrDefault();

                if (lstEmp_EmergencyDetail == null)
                    throw new RecoredNotFoundException("Data Not Available");

                lstEmp_EmergencyDetail.Emp_Id = entity.Emp_Id;
                lstEmp_EmergencyDetail.ContactName = entity.ContactName;
                lstEmp_EmergencyDetail.ContactNo = entity.ContactNo;
                lstEmp_EmergencyDetail.Relationship = entity.Relationship;
                lstEmp_EmergencyDetail.isDefault = entity.isDefault;

                lstEmp_EmergencyDetail.isActive = entity.isActive;
                lstEmp_EmergencyDetail.UpdatedBy = entity.UpdatedBy;
                lstEmp_EmergencyDetail.UpdatedOn = DateTime.Now;

                adbContext.employee_emergency.Update(lstEmp_EmergencyDetail);
                await Task.FromResult(adbContext.SaveChanges());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Update_EmergencyDetails(IList<Employee_Emergency> entity)
        {
            try
            {
                if (entity != null && entity.Count() > 0)
                {
                    foreach (var employee in entity)
                    {
                        if (employee.Emp_Id == 0)
                            throw new RecoredNotFoundException("Employee Not Available");

                        await Update(employee);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task ToogleStatusByEmp_Id(int emp_Id, short isActive)
        {
            try
            {
                //update flag isActive
                var vList = adbContext.employee_emergency.Where(w => w.Emp_Id == emp_Id && w.isActive != isActive).ToList();
                if (vList.Count() > 0)
                {
                    vList.ForEach(w => w.isActive = isActive);
                    adbContext.employee_emergency.UpdateRange(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ToogleStatus(int id, short isActive)
        {
            try
            {
                //update flag isActive
                var vList = adbContext.employee_emergency.Where(w => w.Emp_Emergency_Id == id && w.isActive != isActive).FirstOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.isActive = isActive;
                adbContext.employee_emergency.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task DeleteByEmp_Id(int emp_Id)
        {
            try
            {
                var vList = adbContext.employee_emergency.Where(w => w.Emp_Id == emp_Id).ToList();
                if (vList.Count() > 0)
                {
                    vList.ForEach(w => w.isActive = 0);
                    adbContext.employee_emergency.UpdateRange(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Delete(int id)
        {
            try
            {
                var vList = adbContext.employee_emergency.Where(w => w.Emp_Emergency_Id == id).FirstOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");
                vList.isActive = 0;
                adbContext.employee_emergency.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_Emergency>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            try
            {
                IEnumerable<Employee_Emergency> vList;
                if (String.IsNullOrEmpty(searchValue))
                    vList = adbContext.employee_emergency.Skip(pageIndex * pageSize).Take(pageSize).ToList();
                else
                    vList = adbContext.employee_emergency.Where(w => new[] { Convert.ToString(w.Emp_Id), w.ContactName, w.ContactNo, w.Relationship }.Any(a => a.Contains(searchValue))).Skip(pageIndex * pageSize).Take(pageSize).ToList();

                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Data Not Available");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int RecordCount(string searchValue)
        {
            try
            {
                if (String.IsNullOrEmpty(searchValue))
                {
                    var vCount = (from emp in adbContext.employee_emergency
                                  select emp.Emp_Emergency_Id).Count();
                    return vCount;
                }
                else
                {
                    var vList = adbContext.employee_emergency.
                        Where(w => new[] { Convert.ToString(w.Emp_Id), w.ContactName, w.ContactNo, w.Relationship }.Any(a => a.Contains(searchValue))).Count();

                    return vList;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Exists(Employee_Emergency entity)
        {
            try
            {
                int intCount = 0;
                if (entity.Emp_Emergency_Id > 0) //Update Validation
                    intCount = adbContext.employee_emergency.Where(w => w.Emp_Emergency_Id != entity.Emp_Emergency_Id && w.Emp_Id == entity.Emp_Id && w.ContactName == entity.ContactName && w.ContactNo == entity.ContactNo && w.Relationship == entity.Relationship).Count();
                else //Insert Validation
                    intCount = adbContext.employee_emergency.Where(w => w.ContactName == entity.ContactName && w.ContactNo == entity.ContactNo && w.Relationship == entity.Relationship).Count();
                return (intCount > 0 ? true : false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ReturnBy<Employee_EmergencyView>> GetPaginated(PaginationBy search)
        {
            try
            {
                string strOrder = string.IsNullOrEmpty(search.OrderBy) ? "Emp_Emergency_Id" : search.OrderBy;
                string strWhere = Common.Search.WhereString(search);

                IEnumerable<Employee_EmergencyView> vEmploye_Emergency;
                if (!String.IsNullOrEmpty(search.CommonSearch))
                {
                    vEmploye_Emergency = (from emp in adbContext.employee
                                          join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id
                                          join emp_emerg in adbContext.employee_emergency on emp.Emp_Id equals emp_emerg.Emp_Id
                                          select new Employee_EmergencyView
                                          {
                                              Emp_Emergency_Id = emp_emerg.Emp_Emergency_Id,
                                              Emp_Id = emp_emerg.Emp_Id,
                                              ContactName = emp_emerg.ContactName,
                                              ContactNo = emp_emerg.ContactNo,
                                              Relationship = emp_emerg.Relationship,
                                              isDefault = emp_emerg.isDefault,
                                              isActive = emp_emerg.isActive,
                                              AddedBy = emp_emerg.AddedBy,
                                              UpdatedBy = emp_emerg.UpdatedBy,
                                              Company_Id = emp.Company_Id
                                          }).Where(w => new[] { Convert.ToString(w.Emp_Emergency_Id), w.ContactName.ToLower(), Convert.ToString(w.Emp_Id), w.ContactNo.ToLower() }.Any(a => a.Contains(search.CommonSearch.ToLower()))).OrderBy(strOrder).ToList();
                }
                else
                {
                    vEmploye_Emergency = (from emp in adbContext.employee
                                          join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id
                                          join emp_emerg in adbContext.employee_emergency on emp.Emp_Id equals emp_emerg.Emp_Id
                                          select new Employee_EmergencyView
                                          {
                                              Emp_Emergency_Id = emp_emerg.Emp_Emergency_Id,
                                              Emp_Id = emp_emerg.Emp_Id,
                                              ContactName = emp_emerg.ContactName,
                                              ContactNo = emp_emerg.ContactNo,
                                              Relationship = emp_emerg.Relationship,
                                              isDefault = emp_emerg.isDefault,
                                              isActive = emp_emerg.isActive,
                                              AddedBy = emp_emerg.AddedBy,
                                              UpdatedBy = emp_emerg.UpdatedBy,
                                              Company_Id = emp.Company_Id
                                          }).Where(strWhere).OrderBy(strOrder).ToList();
                }

                if (vEmploye_Emergency == null || vEmploye_Emergency.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                ReturnBy<Employee_EmergencyView> vList = new ReturnBy<Employee_EmergencyView>()
                {
                    list = vEmploye_Emergency.Skip(search.PageIndex * search.PageSize).Take(search.PageSize).ToList(),
                    RecordCount = vEmploye_Emergency.Count()
                };
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
