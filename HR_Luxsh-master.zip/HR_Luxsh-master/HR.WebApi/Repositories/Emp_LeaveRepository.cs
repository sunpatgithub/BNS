﻿using HR.WebApi.DAL;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HR.WebApi.Repositories
{
    public class Emp_LeaveRepository<T> : ICommonRepository<Emp_Leave>
    {
        private readonly ApplicationDbContext adbContext;
        public Emp_Leave_Approve_HistoryRepository<T> _Emp_Leave_Approve_HistoryRepository;
        public Emp_LeaveRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
            _Emp_Leave_Approve_HistoryRepository = new Emp_Leave_Approve_HistoryRepository<T>(applicationDbContext);
        }
        public Task Delete(int id)
        {
            throw new NotImplementedException();
        }

        public bool Exists(Emp_Leave entity)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<Emp_Leave>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<Emp_Leave>> Get(int id)
        {
            try
            {
                IList<Emp_Yearly_Leave> lstEmpYearLeave = adbContext.emp_yearly_leave.AsEnumerable<Emp_Yearly_Leave>().Where(e=>e.emp_id == id).ToList();

                List<Emp_Leave> lstEmpLeave = new List<Emp_Leave>();
                if (lstEmpYearLeave.Count > 0)
                {
                    foreach (var item in lstEmpYearLeave)
                    {
                        List<Emp_Leave> empLeaveLst = adbContext.emp_leave.Where(e => e.emp_yearly_leave_id == item.emp_yearly_leave_id).ToList();
                        lstEmpLeave.AddRange(empLeaveLst);
                    }
                }

                return await Task.FromResult(lstEmpLeave.OrderByDescending(e=>e.emp_leave_id).ToList());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Task<IEnumerable<Emp_Leave>> GetAll(int RecordLimit)
        {
            throw new NotImplementedException();
        }

        public async Task Insert(Emp_Leave entity)
        {
            adbContext.BeginTransaction();
            try
            {
                entity.apply_date = DateTime.Now;
                entity.Emp_Leave_Approve_History.updated_on = DateTime.Now;
                await adbContext.emp_leave.AddAsync(entity);
                await adbContext.SaveChangesAsync();

                adbContext.CommitTransaction();
            }
            catch (Exception ex)
            {
                adbContext.RollBackTransaction();
                throw ex;
            }
        }

        public int RecordCount(string searchValue)
        {
            throw new NotImplementedException();
        }

        public Task ToogleStatus(int id, short isActive)
        {
            throw new NotImplementedException();
        }

        public async Task Update(Emp_Leave entity)
        {
            adbContext.BeginTransaction();
            try
            {
                var lstEmpLeave = adbContext.emp_leave.Where(x => x.emp_leave_id == entity.emp_leave_id).FirstOrDefault();
                lstEmpLeave.status = entity.status;
                await adbContext.SaveChangesAsync();

                entity.Emp_Leave_Approve_History.emp_leave_id = entity.emp_leave_id;
                entity.Emp_Leave_Approve_History.updated_on = DateTime.Now;
                if (entity.Emp_Leave_Approve_History != null)
                {
                    await _Emp_Leave_Approve_HistoryRepository.Insert(entity.Emp_Leave_Approve_History);
                    string result = await Update_Employee_TakenLeave(lstEmpLeave.emp_yearly_leave_id, lstEmpLeave.taken_leave, entity.status);
                    adbContext.CommitTransaction();
                }
                else
                {
                    throw new Exception("Data Not Available");
                }
            }
            catch (Exception ex)
            {
                adbContext.RollBackTransaction();
                throw ex;
            }
        }

        #region "Comman Private Methods"

        private async Task<string>  Update_Employee_TakenLeave(long Emp_Yearly_Leave_Id, double TakenLeave, string Leave_Status)
        {
            string Result = "";
            try
            {
                var isExist = adbContext.emp_yearly_leave.Where(e => e.emp_yearly_leave_id == Emp_Yearly_Leave_Id).ToList();
                if (isExist.Count > 0)
                {
                    if (Leave_Status.ToUpper() == "APPROVE")
                    {
                        double emptakenLeave = 0;
                        double empremainingLeave = 0;
                        foreach (var item in isExist)
                        {
                            emptakenLeave = item.emp_takenleave;
                            empremainingLeave = item.emp_remaining_leave;
                        }

                        double updateNewTakenLeave = emptakenLeave + TakenLeave;
                        double updateNewRemainingLeave = empremainingLeave - TakenLeave;

                        var updateEmpTakenLeave = await adbContext.emp_yearly_leave.FindAsync(Emp_Yearly_Leave_Id);

                        updateEmpTakenLeave.emp_takenleave = updateNewTakenLeave;
                        updateEmpTakenLeave.emp_remaining_leave = updateNewRemainingLeave;
                        await adbContext.SaveChangesAsync();
                    }
                    else if (Leave_Status.ToUpper() == "CANCEL")
                    {
                        double emptakenLeave = 0;
                        double empremainingLeave = 0;
                        foreach (var item in isExist)
                        {
                            emptakenLeave = item.emp_takenleave;
                            empremainingLeave = item.emp_remaining_leave;
                        }

                        double updateNewTakenLeave = emptakenLeave - TakenLeave;
                        double updateNewRemainingLeave = empremainingLeave + TakenLeave;

                        var updateEmpTakenLeave = await adbContext.emp_yearly_leave.FindAsync(Emp_Yearly_Leave_Id);

                        updateEmpTakenLeave.emp_takenleave = updateNewTakenLeave;
                        updateEmpTakenLeave.emp_remaining_leave = updateNewRemainingLeave;

                        await adbContext.SaveChangesAsync();
                    }                   
                }
                else
                {
                    throw new Exception("Data Not Available");
                }
                return Result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

    }
}
