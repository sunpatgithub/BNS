﻿using HR.WebApi.DAL;
using HR.WebApi.Model;
using HR.WebApi.ModelView;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Text;
using System.Threading.Tasks;
using HR.WebApi.Exceptions;
using HR.WebApi.Interfaces;


namespace HR.WebApi.Repositories
{
    public class Raf_ApprovalRepository<T> : ICommonRepository<Raf_ApprovalView>, IPaginated<Raf_ApprovalView>
    {
        private readonly ApplicationDbContext adbContext;

        public Raf_ApprovalRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }

        public async Task<IEnumerable<Raf_ApprovalView>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<Raf_ApprovalView> vList;
                if (RecordLimit > 0)
                {
                    vList = (from ra in adbContext.raf_approval
                             join r in adbContext.raf on ra.Raf_Id equals r.Id
                             join comp in adbContext.company on ra.Company_Id equals comp.Company_Id
                             join dept in adbContext.department on ra.Dept_Id equals dept.Dept_Id
                             join desig in adbContext.designation on ra.Desig_Id equals desig.Desig_Id
                             select new Raf_ApprovalView
                             {
                                 Id = ra.Id,

                                 Raf_Id = ra.Raf_Id,
                                 Raf_Name = r.Name,

                                 Company_Id = ra.Company_Id,
                                 Company_Name = comp.Company_Name,

                                 Dept_Id = ra.Dept_Id,
                                 Dept_Name = dept.Dept_Name,

                                 Desig_Id = ra.Desig_Id,
                                 Desig_Name = desig.Desig_Name,

                                 ApprovalSequence = ra.ApprovalSequence,
                                 Description = ra.Description,
                                 DueDate = ra.DueDate,
                                 ApprovalBy = ra.ApprovalBy,
                                 ApprovalOn = ra.ApprovalOn
                             }
                                ).Take(RecordLimit).ToList();
                }
                else
                {
                    vList = (from ra in adbContext.raf_approval
                             join r in adbContext.raf on ra.Raf_Id equals r.Id
                             join comp in adbContext.company on ra.Company_Id equals comp.Company_Id
                             join dept in adbContext.department on ra.Dept_Id equals dept.Dept_Id
                             join desig in adbContext.designation on ra.Desig_Id equals desig.Desig_Id
                             select new Raf_ApprovalView
                             {
                                 Id = ra.Id,

                                 Raf_Id = ra.Raf_Id,
                                 Raf_Name = r.Name,

                                 Company_Id = ra.Company_Id,
                                 Company_Name = comp.Company_Name,

                                 Dept_Id = ra.Dept_Id,
                                 Dept_Name = dept.Dept_Name,

                                 Desig_Id = ra.Desig_Id,
                                 Desig_Name = desig.Desig_Name,

                                 ApprovalSequence = ra.ApprovalSequence,
                                 Description = ra.Description,
                                 DueDate = ra.DueDate,
                                 ApprovalBy = ra.ApprovalBy,
                                 ApprovalOn = ra.ApprovalOn
                             }).ToList();
                }
                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Raf_ApprovalView>> Get(int id)
        {
            try
            {
                var vList = (from ra in adbContext.raf_approval
                             join r in adbContext.raf on ra.Raf_Id equals r.Id
                             join comp in adbContext.company on ra.Company_Id equals comp.Company_Id
                             join dept in adbContext.department on ra.Dept_Id equals dept.Dept_Id
                             join desig in adbContext.designation on ra.Desig_Id equals desig.Desig_Id
                             select new Raf_ApprovalView
                             {
                                 Id = ra.Id,

                                 Raf_Id = ra.Raf_Id,
                                 Raf_Name = r.Name,

                                 Company_Id = ra.Company_Id,
                                 Company_Name = comp.Company_Name,

                                 Dept_Id = ra.Dept_Id,
                                 Dept_Name = dept.Dept_Name,

                                 Desig_Id = ra.Desig_Id,
                                 Desig_Name = desig.Desig_Name,

                                 ApprovalSequence = ra.ApprovalSequence,
                                 Description = ra.Description,
                                 DueDate = ra.DueDate,
                                 ApprovalBy = ra.ApprovalBy,
                                 ApprovalOn = ra.ApprovalOn
                             }).ToList();
                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Raf_ApprovalView>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            try
            {
                IEnumerable<Raf_ApprovalView> vList;
                if (String.IsNullOrEmpty(searchValue))
                {
                    //Find with Paging
                    vList = (from ra in adbContext.raf_approval
                             join r in adbContext.raf on ra.Raf_Id equals r.Id
                             join comp in adbContext.company on ra.Company_Id equals comp.Company_Id
                             join dept in adbContext.department on ra.Dept_Id equals dept.Dept_Id
                             join desig in adbContext.designation on ra.Desig_Id equals desig.Desig_Id
                             select new Raf_ApprovalView
                             {
                                 Id = ra.Id,

                                 Raf_Id = ra.Raf_Id,
                                 Raf_Name = r.Name,

                                 Company_Id = ra.Company_Id,
                                 Company_Name = comp.Company_Name,

                                 Dept_Id = ra.Dept_Id,
                                 Dept_Name = dept.Dept_Name,

                                 Desig_Id = ra.Desig_Id,
                                 Desig_Name = desig.Desig_Name,

                                 ApprovalSequence = ra.ApprovalSequence,
                                 Description = ra.Description,
                                 DueDate = ra.DueDate,
                                 ApprovalBy = ra.ApprovalBy,
                                 ApprovalOn = ra.ApprovalOn
                             }
                                 ).Skip(pageIndex * pageSize).Take(pageSize).ToList();
                }
                else
                {
                    //Find with Paging & Searching
                    vList = (from ra in adbContext.raf_approval.Where(w => new[] { w.Description.ToLower() }.Any(a => a.Contains(searchValue.ToLower())))
                             join r in adbContext.raf on ra.Raf_Id equals r.Id
                             join comp in adbContext.company on ra.Company_Id equals comp.Company_Id
                             join dept in adbContext.department on ra.Dept_Id equals dept.Dept_Id
                             join desig in adbContext.designation on ra.Desig_Id equals desig.Desig_Id
                             select new Raf_ApprovalView
                             {
                                 Id = ra.Id,

                                 Raf_Id = ra.Raf_Id,
                                 Raf_Name = r.Name,

                                 Company_Id = ra.Company_Id,
                                 Company_Name = comp.Company_Name,

                                 Dept_Id = ra.Dept_Id,
                                 Dept_Name = dept.Dept_Name,

                                 Desig_Id = ra.Desig_Id,
                                 Desig_Name = desig.Desig_Name,

                                 ApprovalSequence = ra.ApprovalSequence,
                                 Description = ra.Description,
                                 DueDate = ra.DueDate,
                                 ApprovalBy = ra.ApprovalBy,
                                 ApprovalOn = ra.ApprovalOn
                             }
                                ).Skip(pageIndex * pageSize).Take(pageSize).ToList();
                }
                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert(Raf_ApprovalView entity)
        {
            try
            {
                //Insert New Raf_approval
                var vList = new Raf_Approval
                {
                    Raf_Id = entity.Raf_Id,
                    Company_Id = entity.Company_Id,
                    Dept_Id = entity.Dept_Id,
                    Desig_Id = entity.Desig_Id,
                    ApprovalSequence = entity.ApprovalSequence,
                    Description = entity.Description,
                    DueDate = entity.DueDate,
                    ApprovalBy = entity.ApprovalBy,
                    ApprovalOn = entity.ApprovalOn,
                    AddedBy = entity.AddedBy,
                    AddedOn = DateTime.Now
                };

                adbContext.raf_approval.Add(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Task Update(Raf_ApprovalView entity)
        {
            throw new NotImplementedException();
        }

        public Task ToogleStatus(int id, short isActive)
        {
            throw new NotImplementedException();
        }

        public async Task Delete(int id)
        {
            try
            {
                //Delete raf_approval
                var vList = adbContext.raf_approval.Where(w => w.Id == id).SingleOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");
                adbContext.raf_approval.Remove(vList);
                await Task.FromResult(adbContext.SaveChanges());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Exists(Raf_ApprovalView entity)
        {
            try
            {
                int intCount = 0; 
                //Insert Validation
                    intCount = adbContext.raf_approval.Where(w => w.Company_Id == entity.Company_Id && w.Dept_Id == entity.Dept_Id && w.Desig_Id == entity.Desig_Id && w.Raf_Id == entity.Raf_Id && w.ApprovalSequence == entity.ApprovalSequence).Count();
                return (intCount > 0 ? true : false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int RecordCount(string searchValue)
        {
            try
            {
                if (String.IsNullOrEmpty(searchValue))
                {
                    //Find all no of rows
                    var vCount = (from ra in adbContext.raf_approval
                                  join r in adbContext.raf on ra.Raf_Id equals r.Id
                                  join comp in adbContext.company on ra.Company_Id equals comp.Company_Id
                                  join dept in adbContext.department on ra.Dept_Id equals dept.Dept_Id
                                  join desig in adbContext.designation on ra.Desig_Id equals desig.Desig_Id
                                  select ra.Id
                                ).Count();
                    return vCount;
                }
                else
                {
                    //Find no of rows with Searching
                    var vCount = (from ra in adbContext.raf_approval.Where(w => new[] { w.Description.ToLower() }.Any(a => a.Contains(searchValue.ToLower())))
                                  join r in adbContext.raf on ra.Raf_Id equals r.Id
                                  join comp in adbContext.company on ra.Company_Id equals comp.Company_Id
                                  join dept in adbContext.department on ra.Dept_Id equals dept.Dept_Id
                                  join desig in adbContext.designation on ra.Desig_Id equals desig.Desig_Id
                                  select ra.Id
                                ).Count();
                    return vCount;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ReturnBy<Raf_ApprovalView>> GetPaginated(PaginationBy search)
        {
            try
            {
                string strOrder = string.IsNullOrEmpty(search.OrderBy) ? "Id" : search.OrderBy;
                string strWhere = Common.Search.WhereString(search);

                IEnumerable<Raf_ApprovalView> vList;

                if (!String.IsNullOrEmpty(search.CommonSearch))
                {

                     vList = (from ra in adbContext.raf_approval
                             join raf in adbContext.raf on ra.Raf_Id equals raf.Id into zraf
                             from raf in zraf.DefaultIfEmpty()
                             join cmp in adbContext.company on ra.Company_Id equals cmp.Company_Id into zcmp
                             from cmp in zcmp.DefaultIfEmpty()
                             join dept in adbContext.department on ra.Dept_Id equals dept.Dept_Id into zdept
                             from dept in zdept.DefaultIfEmpty()
                             join desg in adbContext.designation on ra.Desig_Id equals desg.Desig_Id into zd
                             from desg in zd.DefaultIfEmpty()
                             select new Raf_ApprovalView
                             {
                                 Id = ra.Id,

                                 Raf_Id = ra.Raf_Id,
                                 Raf_Name = raf.Name,

                                 Company_Id = ra.Company_Id,
                                 Company_Name = cmp.Company_Name,

                                 Dept_Id = ra.Dept_Id,
                                 Dept_Name = dept.Dept_Name,

                                 Desig_Id = ra.Desig_Id,
                                 Desig_Name = desg.Desig_Name,

                                 ApprovalSequence = ra.ApprovalSequence,
                                 Description = ra.Description,
                                 DueDate = ra.DueDate,
                                 ApprovalBy = ra.ApprovalBy,
                                 ApprovalOn = ra.ApprovalOn
                             }).Where(w => new[] { w.Description.ToLower() }.Any(a => a.Contains(search.CommonSearch.ToLower()))).OrderBy(strOrder).ToList();
                }
                else
                {
                    vList = (from ra in adbContext.raf_approval
                             join raf in adbContext.raf on ra.Raf_Id equals raf.Id into zraf
                             from raf in zraf.DefaultIfEmpty()
                             join cmp in adbContext.company on ra.Company_Id equals cmp.Company_Id into zcmp
                             from cmp in zcmp.DefaultIfEmpty()
                             join dept in adbContext.department on ra.Dept_Id equals dept.Dept_Id into zdept
                             from dept in zdept.DefaultIfEmpty()
                             join desg in adbContext.designation on ra.Desig_Id equals desg.Desig_Id into zdesg
                             from desg in zdesg.DefaultIfEmpty()

                             select new Raf_ApprovalView
                             {
                                 Id = ra.Id,

                                 Raf_Id = ra.Raf_Id,
                                 Raf_Name = raf.Name,

                                 Company_Id = ra.Company_Id,
                                 Company_Name = cmp.Company_Name,

                                 Dept_Id = ra.Dept_Id,
                                 Dept_Name = dept.Dept_Name,

                                 Desig_Id = ra.Desig_Id,
                                 Desig_Name = desg.Desig_Name,

                                 ApprovalSequence = ra.ApprovalSequence,
                                 Description = ra.Description,
                                 DueDate = ra.DueDate,
                                 ApprovalBy = ra.ApprovalBy,
                                 ApprovalOn = ra.ApprovalOn
                             }).Where(strWhere).OrderBy(strOrder).ToList();
                }

                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Empty Data");

                ReturnBy<Raf_ApprovalView> vListDetailt = new ReturnBy<Raf_ApprovalView>()
                {
                    list = vList.Skip(search.PageIndex * search.PageSize).Take(search.PageSize).ToList(),
                    RecordCount = vList.Count()
                };
                return await Task.FromResult(vListDetailt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
