﻿using HR.WebApi.DAL;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using HR.WebApi.Exceptions;
using HR.WebApi.ModelView;
using System.Text;
using System.Linq.Dynamic.Core;

namespace HR.WebApi.Repositories
{
    public class Employee_ProbationRepository<T> : ICommonRepository<Employee_Probation>, IPaginated<Employee_ProbationView>
    {
        private readonly ApplicationDbContext adbContext;

        public Employee_ProbationRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }

        public async Task<IEnumerable<Employee_Probation>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<Employee_Probation> vList;
                if (RecordLimit > 0)
                    vList = adbContext.employee_probation.Take(RecordLimit).ToList();
                else
                    vList = adbContext.employee_probation.ToList();

                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_Probation>> GetByEmp_Id(int emp_Id)
        {
            try
            {
                IEnumerable<Employee_Probation> vList = adbContext.employee_probation.Where(w => w.Emp_Id == emp_Id).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_Probation>> Get(int id)
        {
            try
            {
                IEnumerable<Employee_Probation> vList = adbContext.employee_probation.Where(w => w.Emp_Probation_Id == id).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert(Employee_Probation entity)
        {
            try
            {
                if (entity.Emp_Id == 0)
                    throw new RecoredNotFoundException("Employee Not Available");

                entity.AddedOn = DateTime.Now;
                adbContext.employee_probation.Add(entity);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert_Multiple(IEnumerable<Employee_Probation> entity)
        {
            try
            {
                if (entity != null && entity.Count() > 0)
                {
                    foreach (var employee in entity)
                    {
                        if (employee.Emp_Id == 0)
                            throw new RecoredNotFoundException("Employee Not Available");
                    }
                    entity.ToList().ForEach(w => w.AddedOn = DateTime.Now);
                    adbContext.employee_probation.AddRange(entity);
                    await Task.FromResult(adbContext.SaveChangesAsync());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Update(Employee_Probation entity)
        {
            try
            {
                var vList = adbContext.employee_probation.Where(x => x.Emp_Probation_Id == entity.Emp_Probation_Id && x.Emp_Id == entity.Emp_Id).FirstOrDefault();

                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.Emp_Id = entity.Emp_Id;
                vList.ProbationEndDate = entity.ProbationEndDate;
                vList.ProbationPeriod = entity.ProbationPeriod;
                vList.NextReviewDate = entity.NextReviewDate;
                vList.Status = entity.Status;
                vList.Notes = entity.Notes;
                vList.isActive = entity.isActive;
                vList.UpdatedBy = entity.UpdatedBy;
                vList.UpdatedOn = DateTime.Now;

                adbContext.employee_probation.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Update_Probation(IList<Employee_Probation> entity)
        {
            try
            {
                if (entity != null && entity.Count() > 0)
                {
                    foreach (var employee in entity)
                    {
                        if (employee.Emp_Id == 0)
                            throw new RecoredNotFoundException("Employee Not Available");

                        await Update(employee);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ToogleStatusByEmp_Id(int emp_Id, short isActive)
        {
            try
            {
                //update flag isActive
                var vList = adbContext.employee_probation.Where(w => w.Emp_Id == emp_Id && w.isActive != isActive).ToList();
                if (vList.Count() > 0)
                {
                    vList.ForEach(w => w.isActive = isActive);
                    adbContext.employee_probation.UpdateRange(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ToogleStatus(int id, short isActive)
        {
            try
            {
                //update flag isActive
                var vList = adbContext.employee_probation.Where(w => w.Emp_Probation_Id == id && w.isActive != isActive).FirstOrDefault();

                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.isActive = isActive;
                adbContext.employee_probation.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task DeleteByEmp_Id(int emp_Id)
        {
            try
            {
                var vList = adbContext.employee_probation.Where(w => w.Emp_Id == emp_Id).ToList();
                if (vList.Count() > 0)
                {
                    vList.ForEach(w => w.isActive = 0);
                    adbContext.employee_probation.UpdateRange(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Delete(int id)
        {
            try
            {
                var vList = adbContext.employee_probation.Where(w => w.Emp_Probation_Id == id).FirstOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.isActive = 0;
                adbContext.employee_probation.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_Probation>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            try
            {
                IEnumerable<Employee_Probation> vList;
                if (String.IsNullOrEmpty(searchValue))
                    vList = adbContext.employee_probation.Skip(pageIndex * pageSize).Take(pageSize).ToList();
                else
                    vList = adbContext.employee_probation.Where(w => new[] { Convert.ToString(w.Emp_Id), w.ProbationPeriod, w.Status, w.Notes }.Any(a => a.Contains(searchValue))).Skip(pageIndex * pageSize).Take(pageSize).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Data Not Available");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int RecordCount(string searchValue)
        {
            try
            {
                if (String.IsNullOrEmpty(searchValue))
                {
                    var vCount = (from emp in adbContext.employee_probation
                                  select emp.Emp_Probation_Id).Count();
                    return vCount;
                }
                else
                {
                    var vList = adbContext.employee_probation.
                        Where(w => new[] { Convert.ToString(w.Emp_Id), w.ProbationPeriod, w.Status, w.Notes }.Any(a => a.Contains(searchValue))).Count();

                    return vList;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Exists(Employee_Probation entity)
        {
            try
            {
                int intCount = 0;
                if (entity.Emp_Probation_Id > 0) //Update Validation
                    intCount = adbContext.employee_probation.Where(w => w.Emp_Probation_Id != entity.Emp_Probation_Id && w.Emp_Id == entity.Emp_Id && w.ProbationPeriod == entity.ProbationPeriod).Count();
                else //Insert Validation
                    intCount = adbContext.employee_probation.Where(w => w.Emp_Id == entity.Emp_Id && w.ProbationPeriod == entity.ProbationPeriod).Count();
                return (intCount > 0 ? true : false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ReturnBy<Employee_ProbationView>> GetPaginated(PaginationBy search)
        {
            try
            {
                string strOrder = string.IsNullOrEmpty(search.OrderBy) ? "Emp_Probation_Id" : search.OrderBy;
                string strWhere = Common.Search.WhereString(search);

                IEnumerable<Employee_ProbationView> vEmploye_Probation;
                if (!String.IsNullOrEmpty(search.CommonSearch))
                {
                    vEmploye_Probation = (from emp in adbContext.employee
                                          join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id
                                          join emp_probation in adbContext.employee_probation on emp.Emp_Id equals emp_probation.Emp_Id
                                          select new Employee_ProbationView
                                          {
                                              Emp_Probation_Id = emp_probation.Emp_Probation_Id,
                                              Emp_Id = emp_probation.Emp_Id,
                                              ProbationEndDate = emp_probation.ProbationEndDate,
                                              ProbationPeriod = emp_probation.ProbationPeriod,
                                              NextReviewDate = emp_probation.NextReviewDate,
                                              Status = emp_probation.Status,
                                              Notes = emp_probation.Notes,
                                              isActive = emp_probation.isActive,
                                              AddedBy = emp_probation.AddedBy,
                                              UpdatedBy = emp_probation.UpdatedBy,
                                              Company_Id = emp.Company_Id
                                          }).Where(w => new[] { Convert.ToString(w.Emp_Probation_Id), w.ProbationPeriod.ToLower(), Convert.ToString(w.Emp_Id) }.Any(a => a.Contains(search.CommonSearch.ToLower()))).OrderBy(strOrder).ToList();
                }
                else
                {
                    vEmploye_Probation = (from emp in adbContext.employee
                                          join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id
                                          join emp_probation in adbContext.employee_probation on emp.Emp_Id equals emp_probation.Emp_Id
                                          select new Employee_ProbationView
                                          {
                                              Emp_Probation_Id = emp_probation.Emp_Probation_Id,
                                              Emp_Id = emp_probation.Emp_Id,
                                              ProbationEndDate = emp_probation.ProbationEndDate,
                                              ProbationPeriod = emp_probation.ProbationPeriod,
                                              NextReviewDate = emp_probation.NextReviewDate,
                                              Status = emp_probation.Status,
                                              Notes = emp_probation.Notes,
                                              isActive = emp_probation.isActive,
                                              AddedBy = emp_probation.AddedBy,
                                              UpdatedBy = emp_probation.UpdatedBy,
                                              Company_Id = emp.Company_Id
                                          }).Where(strWhere).OrderBy(strOrder).ToList();

                }

                if (vEmploye_Probation == null || vEmploye_Probation.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                ReturnBy<Employee_ProbationView> vList = new ReturnBy<Employee_ProbationView>()
                {
                    list = vEmploye_Probation.Skip(search.PageIndex * search.PageSize).Take(search.PageSize).ToList(),
                    RecordCount = vEmploye_Probation.Count()
                };
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
