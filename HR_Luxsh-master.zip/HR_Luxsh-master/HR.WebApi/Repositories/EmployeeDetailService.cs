﻿using HR.WebApi.DAL;
using HR.WebApi.Model;
using HR.WebApi.ModelView;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Text;
using System.Threading.Tasks;
using HR.WebApi.Exceptions;
using HR.WebApi.Interfaces;

namespace HR.WebApi.Repositories
{
    public class EmployeeDetailService : IPaginated<EmployeeDetailView>
    {
        private readonly ApplicationDbContext adbContext;
        public EmployeeRepository<Employee> employeeRepo;
        public Employee_AddressRepository<Employee_Address> empAddressRepo;
        public Employee_BankRepository<Employee_Bank> empBankRepo;
        public Employee_BasicInfoRepository<Employee_BasicInfo> empBasicInfoRepo;
        public Employee_ContactRepository<Employee_Contact> empContactRepo;
        public Employee_ContractRepository<Employee_Contract> empContractRepo;
        public Employee_DocumentRepository<Employee_Document> empDocumentRepo;
        public Employee_EmergencyRepository<Employee_Emergency> empEmergencyRepo;
        public Employee_ProbationRepository<Employee_Probation> empProbationRepo;
        public Employee_ReferenceRepository<Employee_Reference> empReferenceRepo;
        public Employee_ResignationRepository<Employee_Resignation> empResignationRepo;
        public Employee_RightToWorkRepository<Employee_RightToWork> empRightToWorkRepo;
        public Employee_SalaryRepository<Employee_Salary> empSalaryRepo;

        public EmployeeDetailService(ApplicationDbContext applicationDbContext, EmployeeRepository<Employee> empRepository, Employee_AddressRepository<Employee_Address> emp_AddressRepository,
            Employee_BankRepository<Employee_Bank> emp_BankRepository, Employee_BasicInfoRepository<Employee_BasicInfo> emp_BasicinfoRepository,
            Employee_ContactRepository<Employee_Contact> emp_ContactRepository, Employee_ContractRepository<Employee_Contract> emp_ContractRepository,
            Employee_DocumentRepository<Employee_Document> emp_DocumentRepository, Employee_EmergencyRepository<Employee_Emergency> emp_EmergencyRepository,
            Employee_ProbationRepository<Employee_Probation> emp_ProbationRepository, Employee_ReferenceRepository<Employee_Reference> emp_ReferenceRepository,
            Employee_ResignationRepository<Employee_Resignation> emp_ResignationRepository, Employee_RightToWorkRepository<Employee_RightToWork> emp_RighttoworkRepository,
            Employee_SalaryRepository<Employee_Salary> emp_SalaryRepository)
        {
            adbContext = applicationDbContext;
            employeeRepo = empRepository;
            empAddressRepo = emp_AddressRepository;
            empBankRepo = emp_BankRepository;
            empBasicInfoRepo = emp_BasicinfoRepository;
            empContactRepo = emp_ContactRepository;
            empContractRepo = emp_ContractRepository;
            empDocumentRepo = emp_DocumentRepository;
            empEmergencyRepo = emp_EmergencyRepository;
            empProbationRepo = emp_ProbationRepository;
            empReferenceRepo = emp_ReferenceRepository;
            empResignationRepo = emp_ResignationRepository;
            empRightToWorkRepo = emp_RighttoworkRepository;
            empSalaryRepo = emp_SalaryRepository;
        }

        //public async Task<IEnumerable<Employee>> GetAll(int RecordLimit)
        //{
        //    var vlist = await employeeRepo.GetAll(RecordLimit);
        //    await empAddressRepo.GetAll(RecordLimit);
        //    await empBankRepo.GetAll(RecordLimit);
        //    await empBasicInfoRepo.GetAll(RecordLimit);
        //    await empContactRepo.GetAll(RecordLimit);
        //    await empContractRepo.GetAll(RecordLimit);
        //    await empDocumentRepo.GetAll(RecordLimit);
        //    await empEmergencyRepo.GetAll(RecordLimit);
        //    await empProbationRepo.GetAll(RecordLimit);
        //    await empReferenceRepo.GetAll(RecordLimit);
        //    await empResignationRepo.GetAll(RecordLimit);
        //    await empRightToWorkRepo.GetAll(RecordLimit);
        //    await empSalaryRepo.GetAll(RecordLimit);
        //    return vlist;
        //}

        public async Task<IEnumerable<EmployeeDetailView>> GetEmployee(PaginationBy search)
        {
            try
            {
                IEnumerable<EmployeeDetailView> vList;
                string strOrderby = search.OrderBy == null ? "Emp_Id" : search.OrderBy;
                StringBuilder sbWhr = new StringBuilder();
                if (search.searchBy != null && search.searchBy.Count() > 0)
                {
                    foreach (var vAry in search.searchBy)
                        sbWhr.AppendFormat("{0} {1} {2} {3} ", vAry.FieldName, vAry.Parameter, vAry.FieldValue, vAry.ConditionWith);

                    vList = (from emp in adbContext.employee
                             join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id into zcmp
                             from cmp in zcmp.DefaultIfEmpty()
                             join dept in adbContext.department on emp.Dept_Id equals dept.Dept_Id into zdept
                             from dept in zdept.DefaultIfEmpty()
                             join desg in adbContext.designation on emp.Desig_Id equals desg.Desig_Id into zdesg
                             from desg in zdesg.DefaultIfEmpty()
                             join jd in adbContext.job_description on emp.JD_Id equals jd.JD_Id into zjd
                             from jd in zjd.DefaultIfEmpty()
                             join shft in adbContext.shift on emp.Shift_Id equals shft.Shift_Id into zshft
                             from shft in zshft.DefaultIfEmpty()
                             join zon in adbContext.zone on emp.Zone_Id equals zon.Zone_Id into zzon
                             from zon in zzon.DefaultIfEmpty()
                             join sit in adbContext.site on emp.Site_Id equals sit.Site_Id into ssit
                             from sit in ssit.DefaultIfEmpty()

                             join i in adbContext.employee_basicinfo on emp.Emp_Id equals i.Emp_Id into zi
                             from i in zi.DefaultIfEmpty()
                                 //join a in adbContext.employee_address on emp.Emp_Id equals a.Emp_Id into za from a in za.DefaultIfEmpty()
                                 //join b in adbContext.employee_bank on emp.Emp_Id equals b.Emp_Id into za from a in za.DefaultIfEmpty()
                                 //join c in adbContext.employee_contact on emp.Emp_Id equals c.Emp_Id into za from a in za.DefaultIfEmpty()
                                 //join t in adbContext.employee_contract on emp.Emp_Id equals t.Emp_Id into za from a in za.DefaultIfEmpty()
                                 //join p in adbContext.employee_probation on emp.Emp_Id equals p.Emp_Id into za from a in za.DefaultIfEmpty()
                                 //join r in adbContext.employee_reference on emp.Emp_Id equals r.Emp_Id into za from a in za.DefaultIfEmpty()
                                 //join w in adbContext.employee_righttowork on emp.Emp_Id equals w.Emp_Id into za from a in za.DefaultIfEmpty()
                                 //join s in adbContext.employee_salary on emp.Emp_Id equals s.Emp_Id into za from a in za.DefaultIfEmpty()
                             select new EmployeeDetailView
                             {
                                 Emp_Id = emp.Emp_Id,
                                 Company_Id = emp.Company_Id,
                                 Site_Id = emp.Site_Id,
                                 JD_Id = emp.JD_Id,
                                 Dept_Id = emp.Dept_Id,
                                 Desig_Id = emp.Desig_Id,
                                 Zone_Id = emp.Zone_Id,
                                 Shift_Id = emp.Shift_Id,
                                 Emp_Code = emp.Emp_Code,
                                 JoiningDate = emp.JoiningDate,
                                 Reporting_Id = emp.Reporting_Id,
                                 isActive = emp.isActive,
                                 AddedBy = emp.AddedBy,
                                 AddedOn = emp.AddedOn,
                                 UpdatedBy = emp.UpdatedBy,
                                 UpdatedOn = emp.UpdatedOn,
                                 NiNo = emp.NiNo,
                                 Tupe = emp.Tupe,

                                 FirstName = i.FirstName,
                                 MiddleName = i.MiddleName,
                                 LastName = i.LastName,

                                 Company_Name = cmp.Company_Name,
                                 Dept_Name = dept.Dept_Name,
                                 Desig_Name = desg.Desig_Name,
                                 JD_Name = jd.JD_Name,
                                 Shift_Name = shft.Shift_Name,
                                 Zone_Name = zon.Zone_Name,
                                 Site_Name = sit.Site_Name
                             }).Where(sbWhr.ToString()).OrderBy(strOrderby).ToList();
                }
                else
                {
                    vList = (from emp in adbContext.employee
                             join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id into zcmp
                             from cmp in zcmp.DefaultIfEmpty()
                             join dept in adbContext.department on emp.Dept_Id equals dept.Dept_Id into zdept
                             from dept in zdept.DefaultIfEmpty()
                             join desg in adbContext.designation on emp.Desig_Id equals desg.Desig_Id into zdesg
                             from desg in zdesg.DefaultIfEmpty()
                             join jd in adbContext.job_description on emp.JD_Id equals jd.JD_Id into zjd
                             from jd in zjd.DefaultIfEmpty()
                             join shft in adbContext.shift on emp.Shift_Id equals shft.Shift_Id into zshft
                             from shft in zshft.DefaultIfEmpty()
                             join zon in adbContext.zone on emp.Zone_Id equals zon.Zone_Id into zzon
                             from zon in zzon.DefaultIfEmpty()
                             join sit in adbContext.site on emp.Site_Id equals sit.Site_Id into ssit
                             from sit in ssit.DefaultIfEmpty()

                             join i in adbContext.employee_basicinfo on emp.Emp_Id equals i.Emp_Id into zi
                             from i in zi.DefaultIfEmpty()
                                 //join a in adbContext.employee_address on emp.Emp_Id equals a.Emp_Id into za from a in za.DefaultIfEmpty()
                                 //join b in adbContext.employee_bank on emp.Emp_Id equals b.Emp_Id into za from a in za.DefaultIfEmpty()
                                 //join c in adbContext.employee_contact on emp.Emp_Id equals c.Emp_Id into za from a in za.DefaultIfEmpty()
                                 //join t in adbContext.employee_contract on emp.Emp_Id equals t.Emp_Id into za from a in za.DefaultIfEmpty()
                                 //join p in adbContext.employee_probation on emp.Emp_Id equals p.Emp_Id into za from a in za.DefaultIfEmpty()
                                 //join r in adbContext.employee_reference on emp.Emp_Id equals r.Emp_Id into za from a in za.DefaultIfEmpty()
                                 //join w in adbContext.employee_righttowork on emp.Emp_Id equals w.Emp_Id into za from a in za.DefaultIfEmpty()
                                 //join s in adbContext.employee_salary on emp.Emp_Id equals s.Emp_Id into za from a in za.DefaultIfEmpty()
                             select new EmployeeDetailView
                             {
                                 Emp_Id = emp.Emp_Id,
                                 Company_Id = emp.Company_Id,
                                 Site_Id = emp.Site_Id,
                                 JD_Id = emp.JD_Id,
                                 Dept_Id = emp.Dept_Id,
                                 Desig_Id = emp.Desig_Id,
                                 Zone_Id = emp.Zone_Id,
                                 Shift_Id = emp.Shift_Id,
                                 Emp_Code = emp.Emp_Code,
                                 JoiningDate = emp.JoiningDate,
                                 Reporting_Id = emp.Reporting_Id,
                                 isActive = emp.isActive,
                                 AddedBy = emp.AddedBy,
                                 AddedOn = emp.AddedOn,
                                 UpdatedBy = emp.UpdatedBy,
                                 UpdatedOn = emp.UpdatedOn,
                                 NiNo = emp.NiNo,
                                 Tupe = emp.Tupe,

                                 FirstName = i.FirstName,
                                 MiddleName = i.MiddleName,
                                 LastName = i.LastName,

                                 Company_Name = cmp.Company_Name,
                                 Dept_Name = dept.Dept_Name,
                                 Desig_Name = desg.Desig_Name,
                                 JD_Name = jd.JD_Name,
                                 Shift_Name = shft.Shift_Name,
                                 Zone_Name = zon.Zone_Name,
                                 Site_Name = sit.Site_Name
                             }).ToList();
                }



                if (vList == null)
                    throw new RecoredNotFoundException("Get Empty Data");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert(EmployeeView entity)
        {
            adbContext.BeginTransaction();
            try
            {

                Employee vList = new Employee
                {
                    Company_Id = entity.Company_Id,
                    Site_Id = entity.Site_Id,
                    JD_Id = entity.JD_Id,
                    Dept_Id = entity.Dept_Id,
                    Desig_Id = entity.Desig_Id,
                    Zone_Id = entity.Zone_Id,
                    Shift_Id = entity.Shift_Id,
                    Emp_Code = entity.Emp_Code,
                    JoiningDate = entity.JoiningDate,
                    Reporting_Id = entity.Reporting_Id,
                    isSponsored = entity.isSponsored,
                    Tupe = entity.Tupe,
                    NiNo = entity.NiCategory,
                    PreviousEmp_Id = entity.PreviousEmp_Id,
                    isActive = entity.isActive,
                    AddedBy = entity.AddedBy,
                    AddedOn = DateTime.Now
                };

                var employee = employeeRepo.Insert(vList);
                
                if (employee.Exception == null)
                {
                    if (vList.Emp_Id == 0)
                        throw new RecoredNotFoundException("Employee Not Available");
                    entity.Emp_Id = vList.Emp_Id;
                    if (entity.emp_address != null)
                    {
                        entity.emp_address.ToList().ForEach(w => w.Emp_Id = vList.Emp_Id);
                        await empAddressRepo.Insert_Multiple(entity.emp_address);
                    }
                    if(entity.emp_bank != null)
                    {
                        entity.emp_bank.ToList().ForEach(w => w.Emp_Id = vList.Emp_Id);
                        await empBankRepo.Insert_Multiple(entity.emp_bank);
                    }
                    if(entity.emp_basicinfo != null)
                    {
                        entity.emp_basicinfo.Emp_Id = vList.Emp_Id;
                        await empBasicInfoRepo.Insert(entity.emp_basicinfo);
                    }
                    if(entity.emp_contact != null)
                    {
                        entity.emp_contact.ToList().ForEach(w => w.Emp_Id = vList.Emp_Id);
                        await empContactRepo.Insert_Multiple(entity.emp_contact);
                    }
                    if(entity.emp_contract != null)
                    {
                        entity.emp_contract.ToList().ForEach(w => w.Emp_Id = vList.Emp_Id);
                        await empContractRepo.Insert_Multiple(entity.emp_contract);
                    }
                    if(entity.emp_document != null)
                    {
                        entity.emp_document.ToList().ForEach(w => w.Emp_Id = vList.Emp_Id);
                        await empDocumentRepo.Insert_Multiple(entity.emp_document);
                    }
                    if(entity.emp_emergency != null)
                    {
                        entity.emp_emergency.ToList().ForEach(w => w.Emp_Id = vList.Emp_Id);
                        await empEmergencyRepo.Insert_Multiple(entity.emp_emergency);
                    }
                    if(entity.emp_probation != null)
                    {
                        entity.emp_probation.ToList().ForEach(w => w.Emp_Id = vList.Emp_Id);
                        await empProbationRepo.Insert_Multiple(entity.emp_probation);
                    }
                    if(entity.emp_reference != null)
                    {
                        entity.emp_reference.ToList().ForEach(w => w.Emp_Id = vList.Emp_Id);
                        await empReferenceRepo.Insert_Multiple(entity.emp_reference);
                    }
                    if(entity.emp_resignation != null)
                    {
                        entity.emp_resignation.ToList().ForEach(w => w.Emp_Id = vList.Emp_Id);
                        await empResignationRepo.Insert_Multiple(entity.emp_resignation);
                    }
                    if(entity.emp_righttowork != null)
                    {
                        entity.emp_righttowork.ToList().ForEach(w => w.Emp_Id = vList.Emp_Id);
                        await empRightToWorkRepo.Insert_Multiple(entity.emp_righttowork);
                    }
                    if(entity.emp_salary != null)
                    {
                        entity.emp_salary.ToList().ForEach(w => w.Emp_Id = vList.Emp_Id);
                        await empSalaryRepo.Insert_Multiple(entity.emp_salary);
                    }                   
                    
                }
                else
                {
                    if (employee.Exception.Message != null)
                        throw new Exception(employee.Exception.Message);
                }
                adbContext.CommitTransaction();
            }
            catch (Exception ex)
            {
                adbContext.RollBackTransaction();
                throw ex;
            }
        }

        //public async Task Update(Employee entity)
        //{
        //    adbContext.BeginTransaction();
        //    try
        //    {
        //        await employeeRepo.Update(entity);
        //        await empAddressRepo.Update_Addresses(entity.emp_address);
        //        await empBankRepo.Update_BankDetails(entity.emp_bank);
        //        await empBasicInfoRepo.Update(entity.emp_basicinfo);
        //        await empContactRepo.Update_Contact(entity.emp_contact);
        //        await empContractRepo.Update_Contract(entity.emp_contract);
        //        await empDocumentRepo.Update_Document(entity.emp_document);
        //        await empEmergencyRepo.Update_EmergencyDetails(entity.emp_emergency);
        //        await empProbationRepo.Update_Probation(entity.emp_probation);
        //        await empReferenceRepo.Update_Reference(entity.emp_reference);
        //        await empResignationRepo.Update_Resignation(entity.emp_resignation);
        //        await empRightToWorkRepo.Update_RightToWork(entity.emp_righttowork);
        //        await empSalaryRepo.Update_Salary(entity.emp_salary);
        //        adbContext.CommitTransaction();
        //    }
        //    catch (Exception ex)
        //    {
        //        adbContext.RollBackTransaction();
        //        throw ex;
        //    }
        //}

        public async Task Delete(int id)
        {
            adbContext.BeginTransaction();
            try
            {
                await empAddressRepo.DeleteByEmp_Id(id);
                await empBankRepo.DeleteByEmp_Id(id);
                await empBasicInfoRepo.DeleteByEmp_Id(id);
                await empContactRepo.DeleteByEmp_Id(id);
                await empContractRepo.DeleteByEmp_Id(id);
                await empDocumentRepo.DeleteByEmp_Id(id);
                await empEmergencyRepo.DeleteByEmp_Id(id);
                await empProbationRepo.DeleteByEmp_Id(id);
                await empReferenceRepo.DeleteByEmp_Id(id);
                await empResignationRepo.DeleteByEmp_Id(id);
                await empRightToWorkRepo.DeleteByEmp_Id(id);
                await empSalaryRepo.DeleteByEmp_Id(id);
                await employeeRepo.Delete(id);
                adbContext.CommitTransaction();
            }
            catch (Exception ex)
            {
                adbContext.RollBackTransaction();
                throw ex;
            }
        }

        public async Task ToogleStatus(int id, short isActive)
        {
            adbContext.BeginTransaction();
            try
            {
                await employeeRepo.ToogleStatus(id, isActive);
                await empAddressRepo.ToogleStatusByEmp_Id(id, isActive);
                await empBankRepo.ToogleStatusByEmp_Id(id, isActive);
                await empBasicInfoRepo.ToogleStatusByEmp_Id(id, isActive);
                await empContactRepo.ToogleStatusByEmp_Id(id, isActive);
                await empContractRepo.ToogleStatusByEmp_Id(id, isActive);
                await empDocumentRepo.ToogleStatusByEmp_Id(id, isActive);
                await empEmergencyRepo.ToogleStatusByEmp_Id(id, isActive);
                await empProbationRepo.ToogleStatusByEmp_Id(id, isActive);
                await empReferenceRepo.ToogleStatusByEmp_Id(id, isActive);
                await empResignationRepo.ToogleStatusByEmp_Id(id, isActive);
                await empRightToWorkRepo.ToogleStatusByEmp_Id(id, isActive);
                await empSalaryRepo.ToogleStatusByEmp_Id(id, isActive);
                adbContext.CommitTransaction();
            }
            catch (Exception ex)
            {
                adbContext.RollBackTransaction();
                throw ex;
            }
        }

        public async Task<IEnumerable<EmployeeDetailView>> RepotingWiseEmployee(int reportingId)
        {
            IEnumerable<EmployeeDetailView> vList;
            vList = (from emp in adbContext.employee
                     join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id into zcmp
                     from cmp in zcmp.DefaultIfEmpty()
                     join dept in adbContext.department on emp.Dept_Id equals dept.Dept_Id into zdept
                     from dept in zdept.DefaultIfEmpty()
                     join desg in adbContext.designation on emp.Desig_Id equals desg.Desig_Id into zdesg
                     from desg in zdesg.DefaultIfEmpty()
                     join jd in adbContext.job_description on emp.JD_Id equals jd.JD_Id into zjd
                     from jd in zjd.DefaultIfEmpty()
                     join shft in adbContext.shift on emp.Shift_Id equals shft.Shift_Id into zshft
                     from shft in zshft.DefaultIfEmpty()
                     join zon in adbContext.zone on emp.Zone_Id equals zon.Zone_Id into zzon
                     from zon in zzon.DefaultIfEmpty()

                     join i in adbContext.employee_basicinfo on emp.Emp_Id equals i.Emp_Id into zi
                     from i in zi.DefaultIfEmpty()

                     select new EmployeeDetailView
                     {
                         Emp_Id = emp.Emp_Id,
                         Company_Id = emp.Company_Id,
                         Site_Id = emp.Site_Id,
                         JD_Id = emp.JD_Id,
                         Dept_Id = emp.Dept_Id,
                         Desig_Id = emp.Desig_Id,
                         Zone_Id = emp.Zone_Id,
                         Shift_Id = emp.Shift_Id,
                         Emp_Code = emp.Emp_Code,
                         JoiningDate = emp.JoiningDate,
                         Reporting_Id = emp.Reporting_Id,
                         isActive = emp.isActive,
                         AddedBy = emp.AddedBy,
                         AddedOn = emp.AddedOn,
                         UpdatedBy = emp.UpdatedBy,
                         UpdatedOn = emp.UpdatedOn,

                         FirstName = i.FirstName,
                         MiddleName = i.MiddleName,
                         LastName = i.LastName,

                         Company_Name = cmp.Company_Name,
                         Dept_Name = dept.Dept_Name,
                         Desig_Name = desg.Desig_Name,
                         JD_Name = jd.JD_Name,
                         Shift_Name = shft.Shift_Name,
                         Zone_Name = zon.Zone_Name
                     }).Where(w => w.Reporting_Id == reportingId).ToList();

            if (vList == null || vList.Count() == 0)
                throw new RecoredNotFoundException("Get Data Empty");

            return await Task.FromResult(vList);
        }

        public async Task<ReturnBy<EmployeeDetailView>> GetPaginated(PaginationBy search)
        {
            try
            {
                string strOrder = string.IsNullOrEmpty(search.OrderBy) ? "Emp_Id" : search.OrderBy;
                string strWhere = Common.Search.WhereString(search);

                IEnumerable<EmployeeDetailView> vList;
                if (!String.IsNullOrEmpty(search.CommonSearch))
                {
                    vList = (from emp in adbContext.employee
                             join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id into zcmp
                             from cmp in zcmp.DefaultIfEmpty()
                             join dept in adbContext.department on emp.Dept_Id equals dept.Dept_Id into zdept
                             from dept in zdept.DefaultIfEmpty()
                             join desg in adbContext.designation on emp.Desig_Id equals desg.Desig_Id into zdesg
                             from desg in zdesg.DefaultIfEmpty()
                             join jd in adbContext.job_description on emp.JD_Id equals jd.JD_Id into zjd
                             from jd in zjd.DefaultIfEmpty()
                             join shft in adbContext.shift on emp.Shift_Id equals shft.Shift_Id into zshft
                             from shft in zshft.DefaultIfEmpty()
                             join zon in adbContext.zone on emp.Zone_Id equals zon.Zone_Id into zzon
                             from zon in zzon.DefaultIfEmpty()
                             join sit in adbContext.site on emp.Site_Id equals sit.Site_Id into ssit
                             from sit in ssit.DefaultIfEmpty()

                             join i in adbContext.employee_basicinfo on emp.Emp_Id equals i.Emp_Id into zi
                             from i in zi.DefaultIfEmpty()
                             select new EmployeeDetailView
                             {
                                 Emp_Id = emp.Emp_Id,
                                 Company_Id = emp.Company_Id,
                                 Site_Id = emp.Site_Id,
                                 JD_Id = emp.JD_Id,
                                 Dept_Id = emp.Dept_Id,
                                 Desig_Id = emp.Desig_Id,
                                 Zone_Id = emp.Zone_Id,
                                 Shift_Id = emp.Shift_Id,
                                 Emp_Code = emp.Emp_Code,
                                 JoiningDate = emp.JoiningDate,
                                 Reporting_Id = emp.Reporting_Id,
                                 isActive = emp.isActive,
                                 AddedBy = emp.AddedBy,
                                 AddedOn = emp.AddedOn,
                                 UpdatedBy = emp.UpdatedBy,
                                 UpdatedOn = emp.UpdatedOn,

                                 FirstName = i.FirstName,
                                 MiddleName = i.MiddleName,
                                 LastName = i.LastName,

                                 Company_Name = cmp.Company_Name,
                                 Dept_Name = dept.Dept_Name,
                                 Desig_Name = desg.Desig_Name,
                                 JD_Name = jd.JD_Name,
                                 Shift_Name = shft.Shift_Name,
                                 Zone_Name = zon.Zone_Name,
                                 Site_Name = sit.Site_Name

                             }).Where(w => new[] { w.Emp_Code, Convert.ToString(w.Emp_Id), Convert.ToString(w.Company_Id), Convert.ToString(w.Site_Id), Convert.ToString(w.JD_Id), Convert.ToString(w.Dept_Id), Convert.ToString(w.Desig_Id), Convert.ToString(w.Zone_Id), Convert.ToString(w.Shift_Id) }.Any(a => a.Contains(search.CommonSearch.ToLower()))).OrderBy(strOrder).ToList();
                }
                else
                {
                    vList = (from emp in adbContext.employee
                             join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id into zcmp
                             from cmp in zcmp.DefaultIfEmpty()
                             join dept in adbContext.department on emp.Dept_Id equals dept.Dept_Id into zdept
                             from dept in zdept.DefaultIfEmpty()
                             join desg in adbContext.designation on emp.Desig_Id equals desg.Desig_Id into zdesg
                             from desg in zdesg.DefaultIfEmpty()
                             join jd in adbContext.job_description on emp.JD_Id equals jd.JD_Id into zjd
                             from jd in zjd.DefaultIfEmpty()
                             join shft in adbContext.shift on emp.Shift_Id equals shft.Shift_Id into zshft
                             from shft in zshft.DefaultIfEmpty()
                             join zon in adbContext.zone on emp.Zone_Id equals zon.Zone_Id into zzon
                             from zon in zzon.DefaultIfEmpty()
                             join sit in adbContext.site on emp.Site_Id equals sit.Site_Id into ssit
                             from sit in ssit.DefaultIfEmpty()

                             join i in adbContext.employee_basicinfo on emp.Emp_Id equals i.Emp_Id into zi
                             from i in zi.DefaultIfEmpty()
                             select new EmployeeDetailView
                             {
                                 Emp_Id = emp.Emp_Id,
                                 Company_Id = emp.Company_Id,
                                 Site_Id = emp.Site_Id,
                                 JD_Id = emp.JD_Id,
                                 Dept_Id = emp.Dept_Id,
                                 Desig_Id = emp.Desig_Id,
                                 Zone_Id = emp.Zone_Id,
                                 Shift_Id = emp.Shift_Id,
                                 Emp_Code = emp.Emp_Code,
                                 JoiningDate = emp.JoiningDate,
                                 Reporting_Id = emp.Reporting_Id,
                                 isActive = emp.isActive,
                                 AddedBy = emp.AddedBy,
                                 AddedOn = emp.AddedOn,
                                 UpdatedBy = emp.UpdatedBy,
                                 UpdatedOn = emp.UpdatedOn,
                                 NiNo = emp.NiNo,
                                 Tupe = emp.Tupe,

                                 FirstName = i.FirstName,
                                 MiddleName = i.MiddleName,
                                 LastName = i.LastName,

                                 Company_Name = cmp.Company_Name,
                                 Dept_Name = dept.Dept_Name,
                                 Desig_Name = desg.Desig_Name,
                                 JD_Name = jd.JD_Name,
                                 Shift_Name = shft.Shift_Name,
                                 Zone_Name = zon.Zone_Name,
                                 Site_Name = sit.Site_Name

                             }).Where(strWhere).OrderBy(strOrder).ToList();
                }

                if (vList == null)
                    throw new RecoredNotFoundException("Get Empty Data");

                ReturnBy<EmployeeDetailView> vListDetailt = new ReturnBy<EmployeeDetailView>()
                {
                    list = vList.Skip(search.PageIndex * search.PageSize).Take(search.PageSize).ToList(),
                    RecordCount = vList.Count()
                };
                return await Task.FromResult(vListDetailt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
