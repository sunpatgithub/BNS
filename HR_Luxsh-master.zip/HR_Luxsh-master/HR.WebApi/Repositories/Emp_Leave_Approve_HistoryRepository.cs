﻿using HR.WebApi.DAL;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HR.WebApi.Repositories
{
    public class Emp_Leave_Approve_HistoryRepository<T> : ICommonRepository<Emp_Leave_Approve_History>
    {
        private readonly ApplicationDbContext adbContext;
        public Emp_Leave_Approve_HistoryRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }
        public Task Delete(int id)
        {
            throw new NotImplementedException();
        }

        public bool Exists(Emp_Leave_Approve_History entity)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<Emp_Leave_Approve_History>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<Emp_Leave_Approve_History>> Get(int id)
        {
            try
            {
                IList<Emp_Leave_Approve_History> lstEmpLeaveApprove = adbContext.emp_leave_approve_history.AsEnumerable<Emp_Leave_Approve_History>().Where(e => e.emp_leave_id == id).ToList();

                return await Task.FromResult(lstEmpLeaveApprove);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Task<IEnumerable<Emp_Leave_Approve_History>> GetAll(int RecordLimit)
        {
            throw new NotImplementedException();
        }

        public async Task Insert(Emp_Leave_Approve_History entity)
        {
            try
            {
                await adbContext.emp_leave_approve_history.AddAsync(entity);
                await adbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int RecordCount(string searchValue)
        {
            throw new NotImplementedException();
        }

        public Task ToogleStatus(int id, short isActive)
        {
            throw new NotImplementedException();
        }

        public Task Update(Emp_Leave_Approve_History entity)
        {
            throw new NotImplementedException();
        }
    }
}
