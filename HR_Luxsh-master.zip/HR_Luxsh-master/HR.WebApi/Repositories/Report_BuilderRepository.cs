﻿using HR.CommonUtility;
using HR.WebApi.DAL;
using HR.WebApi.Exceptions;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using HR.WebApi.ModelView;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace HR.WebApi.Repositories
{
    public class Report_BuilderRepository<T> : IReportBuilder<Report_Builder>
    {
        private readonly ApplicationDbContext adbContext;

        public Report_BuilderRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }

        public async Task<IEnumerable<Report_Builder>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<Report_Builder> vList;
                if (RecordLimit > 0)
                    vList = adbContext.report_builder.Take(RecordLimit).ToList();
                else
                    vList = adbContext.report_builder.ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }       

        public async Task<IEnumerable<Report_Builder>> Get(int id)
        {
            try
            {
                var vList = adbContext.report_builder.Where(w => w.Id == id).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }       

        public async Task<ReturnBy<Report_Builder>> GetPaginated(PaginationBy paginationBy)
        {
            try
            {
                string strOrder = string.IsNullOrEmpty(paginationBy.OrderBy) ? "Id" : paginationBy.OrderBy;
                string strWhere = Common.Search.WhereString(paginationBy);

                IEnumerable<Report_Builder> vReport_Builder;
                if (!String.IsNullOrEmpty(paginationBy.CommonSearch))
                    vReport_Builder = adbContext.report_builder.Where(w => new[] { Convert.ToString(w.Report_Group_Id), Convert.ToString(w.Id), w.Name }.Any(a => a.Contains(paginationBy.CommonSearch.ToLower()))).OrderBy(strOrder).ToList();

                else
                    vReport_Builder = adbContext.report_builder.Where(strWhere).OrderBy(strOrder).ToList();

                ReturnBy<Report_Builder> vList = new ReturnBy<Report_Builder>()
                {
                    list = vReport_Builder.Skip(paginationBy.PageIndex * paginationBy.PageSize).Take(paginationBy.PageSize).ToList(),
                    RecordCount = vReport_Builder.Count()
                };

                if (vList.list == null || vList.RecordCount == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert(Report_Builder entity)
        {
            try
            {
                entity.AddedOn = DateTime.Now;
               entity.QueryParam = JsonSerializer.SerializeObject(entity.QueryParam);
                adbContext.report_builder.Add(entity);

                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Task Update(Report_Builder entity)
        {
            throw new NotImplementedException();
        }
        public Task Delete(int id)
        {
            throw new NotImplementedException();
        }

        public bool Exists(Report_Builder entity)
        {
            try
            {
                int intCount = 0;
                if (entity.Id > 0)
                    intCount = adbContext.report_builder.Where(w => w.Id != entity.Id && (w.Name == entity.Name)).Count();
                else
                    intCount = adbContext.report_builder.Where(w => w.Name == entity.Name).Count();
                return (intCount > 0 ? true : false);                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
