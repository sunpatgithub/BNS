﻿using HR.WebApi.DAL;
using HR.WebApi.Exceptions;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using HR.WebApi.ModelView;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading.Tasks;

namespace HR.WebApi.Repositories
{
    public class Raf_ApprovedRepository<T> : ICommonRepository<Raf_ApprovedView>, IPaginated<Raf_ApprovedView>
    {
        private readonly ApplicationDbContext adbContext;

        public Raf_ApprovedRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }
        public async Task<IEnumerable<Raf_ApprovedView>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<Raf_ApprovedView> vList;
                if (RecordLimit > 0)
                {
                    vList = (from ra in adbContext.raf_approved
                                 join r_a in adbContext.raf_approval on ra.Raf_Approval_Id equals r_a.Id
                                 join r in adbContext.raf on ra.Raf_Id equals r.Id
                                 join comp in adbContext.company on ra.Company_Id equals comp.Company_Id
                                 join dept in adbContext.department on ra.Dept_Id equals dept.Dept_Id
                                 join desig in adbContext.designation on ra.Desig_Id equals desig.Desig_Id
                                 select new Raf_ApprovedView
                                 {
                                     Id = ra.Id,

                                     Raf_Id = ra.Raf_Id,
                                     Raf_Name = r.Name,

                                     Raf_Approval_Id = ra.Raf_Approval_Id,
                                     raf_approval_Description = r_a.Description,

                                     Company_Id = ra.Company_Id,
                                     Company_Name = comp.Company_Name,

                                     Dept_Id = ra.Dept_Id,
                                     Dept_Name = dept.Dept_Name,

                                     Desig_Id = ra.Desig_Id,
                                     Desig_Name = desig.Desig_Name,

                                     ApprovedBy = ra.ApprovedBy,
                                     ApprovedOn = ra.ApprovedOn,

                                     Description = ra.Description
                                 }
                                ).Take(RecordLimit).ToList();
                }
                else
                {
                    vList = (from ra in adbContext.raf_approved
                                 join r_a in adbContext.raf_approval on ra.Raf_Approval_Id equals r_a.Id
                                 join r in adbContext.raf on ra.Raf_Id equals r.Id
                                 join comp in adbContext.company on ra.Company_Id equals comp.Company_Id
                                 join dept in adbContext.department on ra.Dept_Id equals dept.Dept_Id
                                 join desig in adbContext.designation on ra.Desig_Id equals desig.Desig_Id
                                 select new Raf_ApprovedView
                                 {
                                     Id = ra.Id,

                                     Raf_Id = ra.Raf_Id,
                                     Raf_Name = r.Name,

                                     Raf_Approval_Id = ra.Raf_Approval_Id,
                                     raf_approval_Description = r_a.Description,

                                     Company_Id = ra.Company_Id,
                                     Company_Name = comp.Company_Name,

                                     Dept_Id = ra.Dept_Id,
                                     Dept_Name = dept.Dept_Name,

                                     Desig_Id = ra.Desig_Id,
                                     Desig_Name = desig.Desig_Name,

                                     Description = ra.Description,

                                     ApprovedBy = ra.ApprovedBy,
                                     ApprovedOn = ra.ApprovedOn,
                                 }).ToList();
                }
                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Raf_ApprovedView>> Get(int id)
        {
            try
            {
                var vList = (from ra in adbContext.raf_approved
                             join r_a in adbContext.raf_approval on ra.Raf_Approval_Id equals r_a.Id
                             join r in adbContext.raf on ra.Raf_Id equals r.Id
                             join comp in adbContext.company on ra.Company_Id equals comp.Company_Id
                             join dept in adbContext.department on ra.Dept_Id equals dept.Dept_Id
                             join desig in adbContext.designation on ra.Desig_Id equals desig.Desig_Id
                             select new Raf_ApprovedView
                             {
                                 Id = ra.Id,

                                 Raf_Id = ra.Raf_Id,
                                 Raf_Name = r.Name,

                                 Raf_Approval_Id = ra.Raf_Approval_Id,
                                 raf_approval_Description = r_a.Description,

                                 Company_Id = ra.Company_Id,
                                 Company_Name = comp.Company_Name,

                                 Dept_Id = ra.Dept_Id,
                                 Dept_Name = dept.Dept_Name,

                                 Desig_Id = ra.Desig_Id,
                                 Desig_Name = desig.Desig_Name,

                                 Description = ra.Description,

                                 ApprovedBy = ra.ApprovedBy,
                                 ApprovedOn = ra.ApprovedOn,
                                 
                             }).ToList();
                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Raf_ApprovedView>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            try
            {
                IEnumerable<Raf_ApprovedView> vList;
                if (String.IsNullOrEmpty(searchValue))
                {
                    //Find with Paging
                    vList = (from ra in adbContext.raf_approved
                                 join r_a in adbContext.raf_approval on ra.Raf_Approval_Id equals r_a.Id
                                 join r in adbContext.raf on ra.Raf_Id equals r.Id
                                 join comp in adbContext.company on ra.Company_Id equals comp.Company_Id
                                 join dept in adbContext.department on ra.Dept_Id equals dept.Dept_Id
                                 join desig in adbContext.designation on ra.Desig_Id equals desig.Desig_Id
                                 select new Raf_ApprovedView
                                 {
                                     Id = ra.Id,

                                     Raf_Id = ra.Raf_Id,
                                     Raf_Name = r.Name,

                                     Raf_Approval_Id = ra.Raf_Approval_Id,
                                     raf_approval_Description = r_a.Description,

                                     Company_Id = ra.Company_Id,
                                     Company_Name = comp.Company_Name,

                                     Dept_Id = ra.Dept_Id,
                                     Dept_Name = dept.Dept_Name,

                                     Desig_Id = ra.Desig_Id,
                                     Desig_Name = desig.Desig_Name,

                                     Description = ra.Description,

                                     ApprovedBy = ra.ApprovedBy,
                                     ApprovedOn = ra.ApprovedOn,
                                 }).Skip(pageIndex * pageSize).Take(pageSize).ToList();
                   
                }
                else
                {
                    //Find with Paging & Searching
                    vList = (from ra in adbContext.raf_approved.Where(w => new[] { w.Description.ToLower() }.Any(a => a.Contains(searchValue.ToLower())))
                                 join r_a in adbContext.raf_approval on ra.Raf_Approval_Id equals r_a.Id
                                 join r in adbContext.raf on ra.Raf_Id equals r.Id
                                 join comp in adbContext.company on ra.Company_Id equals comp.Company_Id
                                 join dept in adbContext.department on ra.Dept_Id equals dept.Dept_Id
                                 join desig in adbContext.designation on ra.Desig_Id equals desig.Desig_Id
                                 select new Raf_ApprovedView
                                 {
                                     Id = ra.Id,

                                     Raf_Id = ra.Raf_Id,
                                     Raf_Name = r.Name,

                                     Raf_Approval_Id = ra.Raf_Approval_Id,
                                     raf_approval_Description = r_a.Description,

                                     Company_Id = ra.Company_Id,
                                     Company_Name = comp.Company_Name,

                                     Dept_Id = ra.Dept_Id,
                                     Dept_Name = dept.Dept_Name,

                                     Desig_Id = ra.Desig_Id,
                                     Desig_Name = desig.Desig_Name,

                                     Description = ra.Description,

                                     ApprovedBy = ra.ApprovedBy,
                                     ApprovedOn = ra.ApprovedOn,

                                 }).Skip(pageIndex * pageSize).Take(pageSize).ToList();
                    
                }
                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert(Raf_ApprovedView entity)
        {
            try
            {
                Raf_Approval ra = new Raf_Approval();
                //Insert New Raf_approved
                var vList = new Raf_Approved
                {
                    Raf_Id = entity.Raf_Id,
                    Raf_Approval_Id = entity.Raf_Approval_Id,
                    Company_Id = entity.Company_Id,
                    Dept_Id = entity.Dept_Id,
                    Desig_Id = entity.Desig_Id,
                    Description = entity.Description,

                    ApprovedBy = entity.ApprovedBy,
                    ApprovedOn = entity.ApprovedOn,

                    AddedBy = entity.AddedBy,
                    AddedOn = DateTime.Now
                };

                adbContext.raf_approved.Add(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Task Update(Raf_ApprovedView entity)
        {
            throw new NotImplementedException();
        }

        public Task ToogleStatus(int id, short isActive)
        {
            throw new NotImplementedException();
        }

        public async Task Delete(int id)
        {
            try
            {
                //Delete raf_approved
                var vList = adbContext.raf_approved.Where(w => w.Id == id).SingleOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");
                adbContext.raf_approved.Remove(vList);
                    await Task.FromResult(adbContext.SaveChanges());
               
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Exists(Raf_ApprovedView entity)
        {
            try
            {
                int intCount = 0;
                //Insert Validation
                intCount = adbContext.raf_approved.Where(w => w.Company_Id == entity.Company_Id && w.Dept_Id == entity.Dept_Id && w.Desig_Id == entity.Desig_Id && w.Raf_Id == entity.Raf_Id && w.Raf_Approval_Id == entity.Raf_Approval_Id).Count();
                return (intCount > 0 ? true : false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int RecordCount(string searchValue)
        {
            try
            {
                if (String.IsNullOrEmpty(searchValue))
                {
                    //Find all no of rows
                    var vCount = ( from ra in adbContext.raf_approved
                                   join r_a in adbContext.raf_approval on ra.Raf_Approval_Id equals r_a.Id
                                   join r in adbContext.raf on ra.Raf_Id equals r.Id
                                   join comp in adbContext.company on ra.Company_Id equals comp.Company_Id
                                   join dept in adbContext.department on ra.Dept_Id equals dept.Dept_Id
                                   join desig in adbContext.designation on ra.Desig_Id equals desig.Desig_Id
                                   select ra.Id
                                ).Count();
                    return vCount;
                }
                else
                {
                    //Find no of rows with Searching
                    var vCount = (from ra in adbContext.raf_approved.Where(w => new[] { w.Description.ToLower() }.Any(a => a.Contains(searchValue.ToLower())))
                                  join r_a in adbContext.raf_approval on ra.Raf_Approval_Id equals r_a.Id
                                   join r in adbContext.raf on ra.Raf_Id equals r.Id
                                   join comp in adbContext.company on ra.Company_Id equals comp.Company_Id
                                   join dept in adbContext.department on ra.Dept_Id equals dept.Dept_Id
                                   join desig in adbContext.designation on ra.Desig_Id equals desig.Desig_Id
                                   select ra.Id
                                ).Count();
                    return vCount;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ReturnBy<Raf_ApprovedView>> GetPaginated(PaginationBy search)
        {
            try
            {
                string strOrder = string.IsNullOrEmpty(search.OrderBy) ? "Id" : search.OrderBy;
                string strWhere = Common.Search.WhereString(search);

                IEnumerable<Raf_ApprovedView> vList;

                if (!String.IsNullOrEmpty(search.CommonSearch))
                {

                    vList = (from ra in adbContext.raf_approved
                             join r in adbContext.raf_approval on ra.Raf_Approval_Id equals r.Id into zr
                             from r in zr.DefaultIfEmpty()
                             join raf in adbContext.raf on ra.Raf_Id equals raf.Id into zraf
                             from raf in zraf.DefaultIfEmpty()
                             join cmp in adbContext.company on ra.Company_Id equals cmp.Company_Id into zcmp
                             from cmp in zcmp.DefaultIfEmpty()
                             join dept in adbContext.department on ra.Dept_Id equals dept.Dept_Id into zdept
                             from dept in zdept.DefaultIfEmpty()
                             join desg in adbContext.designation on ra.Desig_Id equals desg.Desig_Id into zd
                             from desg in zd.DefaultIfEmpty()
                             select new Raf_ApprovedView
                             {
                                 Id = ra.Id,

                                 Raf_Id = ra.Raf_Id,
                                 Raf_Name = raf.Name,

                                 Raf_Approval_Id = ra.Raf_Approval_Id,
                                 raf_approval_Description = r.Description,

                                 Company_Id = ra.Company_Id,
                                 Company_Name = cmp.Company_Name,

                                 Dept_Id = ra.Dept_Id,
                                 Dept_Name = dept.Dept_Name,

                                 Desig_Id = ra.Desig_Id,
                                 Desig_Name = desg.Desig_Name,

                                 Description = ra.Description,
                                 ApprovedBy = ra.ApprovedBy,
                                 ApprovedOn = ra.ApprovedOn
                             }).Where(w => new[] { w.Description.ToLower() }.Any(a => a.Contains(search.CommonSearch.ToLower()))).OrderBy(strOrder).ToList();
                }
                else
                {
                    vList = (from ra in adbContext.raf_approved
                             join r in adbContext.raf_approval on ra.Raf_Approval_Id equals r.Id into zr
                             from r in zr.DefaultIfEmpty()
                             join raf in adbContext.raf on ra.Raf_Id equals raf.Id into zraf
                             from raf in zraf.DefaultIfEmpty()
                             join cmp in adbContext.company on ra.Company_Id equals cmp.Company_Id into zcmp
                             from cmp in zcmp.DefaultIfEmpty()
                             join dept in adbContext.department on ra.Dept_Id equals dept.Dept_Id into zdept
                             from dept in zdept.DefaultIfEmpty()
                             join desg in adbContext.designation on ra.Desig_Id equals desg.Desig_Id into zd
                             from desg in zd.DefaultIfEmpty()
                             select new Raf_ApprovedView
                             {
                                 Id = ra.Id,

                                 Raf_Id = ra.Raf_Id,
                                 Raf_Name = raf.Name,

                                 Raf_Approval_Id = ra.Raf_Approval_Id,
                                 raf_approval_Description = r.Description,

                                 Company_Id = ra.Company_Id,
                                 Company_Name = cmp.Company_Name,

                                 Dept_Id = ra.Dept_Id,
                                 Dept_Name = dept.Dept_Name,

                                 Desig_Id = ra.Desig_Id,
                                 Desig_Name = desg.Desig_Name,

                                 Description = ra.Description,
                                 ApprovedBy = ra.ApprovedBy,
                                 ApprovedOn = ra.ApprovedOn
                             }).Where(strWhere).OrderBy(strOrder).ToList();
                }

                if (vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Empty Data");

                ReturnBy<Raf_ApprovedView> vListDetailt = new ReturnBy<Raf_ApprovedView>()
                {
                    list = vList.Skip(search.PageIndex * search.PageSize).Take(search.PageSize).ToList(),
                    RecordCount = vList.Count()
                };
                return await Task.FromResult(vListDetailt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
