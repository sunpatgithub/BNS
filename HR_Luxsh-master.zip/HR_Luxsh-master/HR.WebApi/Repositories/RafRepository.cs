﻿using HR.WebApi.DAL;
using HR.WebApi.Exceptions;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HR.WebApi.Repositories
{
    public class RafRepository<T> : ICommonRepository<Raf>
    {
        private readonly ApplicationDbContext adbContext;

        public RafRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }
        public async Task<IEnumerable<Raf>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<Raf> vList;
                if (RecordLimit > 0)
                    vList = adbContext.raf.Take(RecordLimit).ToList();
                else
                    vList = adbContext.raf.ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Raf>> Get(int id)
        {
            try
            {
               var vList = adbContext.raf.Where(w => w.Id == id).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Raf>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            try
            {
                IEnumerable<Raf> vList;
                if (String.IsNullOrEmpty(searchValue))
                    vList = adbContext.raf.Skip(pageIndex * pageSize).Take(pageSize).ToList();
                else
                    vList = adbContext.raf.Where(w => new[] { w.Name.ToLower(), w.Description.ToLower()}.Any(a => a.Contains(searchValue.ToLower()))).Skip(pageIndex * pageSize).Take(pageSize).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert(Raf entity)
        {
            try
            {
                entity.AddedOn = DateTime.Now;
                adbContext.raf.Add(entity);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        public async Task Update(Raf entity)
        {
            try
            {
                var vList = adbContext.raf.Where(x => x.Id == entity.Id).FirstOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.Id = entity.Id;
                    vList.Name = entity.Name;
                    vList.Description = entity.Description;
                    vList.isActive = entity.isActive;
                    vList.UpdatedBy = entity.UpdatedBy;
                    vList.UpdatedOn = DateTime.Now;

                    adbContext.raf.Update(vList);

                    await Task.FromResult(adbContext.SaveChanges());
               
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ToogleStatus(int id, short isActive)
        {
            try
            {
                var vList = adbContext.raf.Where(w => w.Id == id && w.isActive != isActive).SingleOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");
                vList.isActive = isActive;
                adbContext.raf.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Delete(int id)
        {
            try
            {
                var vList = adbContext.raf.Where(w => w.Id == id).SingleOrDefault();
                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");
                adbContext.raf.Remove(vList);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Exists(Raf entity)
        {
            try
            {
                int intCount = 0;
                if (entity.Id > 0)
                    intCount = adbContext.raf.Where(w => w.Id != entity.Id && (w.Name == entity.Name)).Count();
                else
                    intCount = adbContext.raf.Where(w => w.Id != entity.Id && (w.Name == entity.Name)).Count();
                return (intCount > 0 ? true : false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int RecordCount(string searchValue)
        {
            try
            {
                if (String.IsNullOrEmpty(searchValue))
                {
                    //Find all no of rows
                    var vCount = adbContext.raf.Count();
                    return vCount;
                }
                else
                {
                    //Find no of rows with Searching
                    var vCount = adbContext.raf.Where(w => new[] { w.Name.ToLower(), w.Description.ToLower() }.Any(a => a.Contains(searchValue.ToLower()))).Count();
                    return vCount;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
