﻿using HR.WebApi.Controllers;
using HR.WebApi.DAL;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using HR.WebApi.Exceptions;
using HR.WebApi.ModelView;
using System.Text;
using System.Linq.Dynamic.Core;
using HR.CommonUtility;

namespace HR.WebApi.Repositories
{
    public class AuditLogRepository<T> : IReportBuilder<AuditLog>
    {
        private readonly ApplicationDbContext adbContext;

        public AuditLogRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }

        public Task Delete(int id)
        {
            throw new NotImplementedException();
        }

        public bool Exists(AuditLog entity)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<AuditLog>> Get(int id)
        {
            try
            {
                var vList = adbContext.auditlog.Where(w => w.Audit_Id == id).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<AuditLog>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<AuditLog> vList;
                if (RecordLimit > 0)
                    vList = adbContext.auditlog.Take(RecordLimit).ToList();
                else
                    vList = adbContext.auditlog.ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ReturnBy<AuditLog>> GetPaginated(PaginationBy paginationBy)
        {
            try
            {
                string strOrder = string.IsNullOrEmpty(paginationBy.OrderBy) ? "Audit_Id" : paginationBy.OrderBy;
                string strWhere = Common.Search.WhereString(paginationBy);

                IEnumerable<AuditLog> vAuditLog;
                if (!String.IsNullOrEmpty(paginationBy.CommonSearch))
                    vAuditLog = adbContext.auditlog.Where(w => new[] { Convert.ToString(w.Audit_Id), w.Description,w.Type,w.HostName,w.IpAddress }.Any(a => a.Contains(paginationBy.CommonSearch.ToLower()))).OrderBy(strOrder).ToList();

                else
                    vAuditLog = adbContext.auditlog.Where(strWhere).OrderBy(strOrder).ToList();

                ReturnBy<AuditLog> vList = new ReturnBy<AuditLog>()
                {
                    list = vAuditLog.Skip(paginationBy.PageIndex * paginationBy.PageSize).Take(paginationBy.PageSize).ToList(),
                    RecordCount = vAuditLog.Count()
                };

                if (vList.list == null || vList.RecordCount == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Task Insert(AuditLog entity)
        {
            throw new NotImplementedException();
        }

        public Task Update(AuditLog entity)
        {
            throw new NotImplementedException();
        }
    }
}
