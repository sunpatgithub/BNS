﻿using HR.WebApi.DAL;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using HR.WebApi.Exceptions;
using HR.WebApi.ModelView;
using System.Text;
using System.Linq.Dynamic.Core;

namespace HR.WebApi.Repositories
{
    public class Employee_BankRepository<T> : ICommonRepository<Employee_Bank>, IPaginated<Employee_BankView>
    {
        private readonly ApplicationDbContext adbContext;

        public Employee_BankRepository(ApplicationDbContext applicationDbContext)
        {
            adbContext = applicationDbContext;
        }

        public async Task<IEnumerable<Employee_Bank>> GetAll(int RecordLimit)
        {
            try
            {
                IEnumerable<Employee_Bank> vList;
                if (RecordLimit > 0)
                    vList = adbContext.employee_bank.Take(RecordLimit).ToList();
                else
                    vList = adbContext.employee_bank.ToList();

                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_Bank>> GetByEmp_Id(int emp_Id)
        {
            try
            {
                IEnumerable<Employee_Bank> vList = adbContext.employee_bank.Where(w => w.Emp_Id == emp_Id).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_Bank>> Get(int id)
        {
            try
            {
                IEnumerable<Employee_Bank> vList = adbContext.employee_bank.Where(w => w.Emp_Bank_Id == id).ToList();
                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Insert(Employee_Bank entity)
        {
            try
            {
                if (entity.Emp_Id == 0)
                    throw new RecoredNotFoundException("Employee Not Available");

                entity.AddedOn = DateTime.Now;
                adbContext.employee_bank.Add(entity);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task Insert_Multiple(IEnumerable<Employee_Bank> entity)
        {
            try
            {
                if (entity != null && entity.Count() > 0)
                {
                    foreach (var employee in entity)
                    {
                        if (employee.Emp_Id == 0)
                            throw new RecoredNotFoundException("Employee Not Available");                       
                    }
                    entity.ToList().ForEach(w => w.AddedOn = DateTime.Now);
                    adbContext.employee_bank.AddRange(entity);
                    await Task.FromResult(adbContext.SaveChangesAsync());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Update(Employee_Bank entity)
        {
            try
            {
                var lstEmp_bank = adbContext.employee_bank.Where(x => x.Emp_Bank_Id == entity.Emp_Bank_Id && x.Emp_Id == entity.Emp_Id).FirstOrDefault();

                if (lstEmp_bank == null)
                    throw new RecoredNotFoundException("Data Not Available");

                lstEmp_bank.Emp_Id = entity.Emp_Id;
                lstEmp_bank.Bank_Code = entity.Bank_Code;
                lstEmp_bank.Bank_Name = entity.Bank_Name;
                lstEmp_bank.Account_Title = entity.Account_Title;
                lstEmp_bank.Account_No = entity.Account_No;
                lstEmp_bank.Account_Holder = entity.Account_Holder;
                lstEmp_bank.Account_Type = entity.Account_Type;
                lstEmp_bank.Account_Code = entity.Account_Code;
                lstEmp_bank.isPayed = entity.isPayed;
                lstEmp_bank.Emp_Doc_Id = entity.Emp_Doc_Id;
                lstEmp_bank.isRequired = entity.isRequired;
                lstEmp_bank.Notes = entity.Notes;
                lstEmp_bank.Version_Id = entity.Version_Id;


                lstEmp_bank.isActive = entity.isActive;
                lstEmp_bank.UpdatedBy = entity.UpdatedBy;
                lstEmp_bank.UpdatedOn = DateTime.Now;

                adbContext.employee_bank.Update(lstEmp_bank);
                await Task.FromResult(adbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task Update_BankDetails(IList<Employee_Bank> entity)
        {
            try
            {
                if (entity != null && entity.Count() > 0)
                {
                    foreach (var employee in entity)
                    {
                        if (employee.Emp_Id == 0)
                            throw new RecoredNotFoundException("Employee Not Available");

                        await Update(employee);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ToogleStatusByEmp_Id(int emp_Id, short isActive)
        {
            try
            {
                //update flag isActive
                var vList = adbContext.employee_bank.Where(w => w.Emp_Id == emp_Id && w.isActive != isActive).ToList();
                if (vList.Count() > 0)
                {
                    vList.ForEach(w => w.isActive = isActive);
                    adbContext.employee_bank.UpdateRange(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ToogleStatus(int id, short isActive)
        {
            try
            {
                //update flag isActive
                var vList = adbContext.employee_bank.Where(w => w.Emp_Bank_Id == id && w.isActive != isActive).FirstOrDefault();

                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.isActive = isActive;
                adbContext.employee_bank.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task DeleteByEmp_Id(int emp_Id)
        {
            try
            {
                var vList = adbContext.employee_bank.Where(w => w.Emp_Id == emp_Id).ToList();
                if (vList.Count() > 0)
                {
                    vList.ForEach(w => w.isActive = 0);
                    adbContext.employee_bank.UpdateRange(vList);
                    await Task.FromResult(adbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Delete(int id)
        {
            try
            {
                var vList = adbContext.employee_bank.Where(w => w.Emp_Bank_Id == id).FirstOrDefault();

                if (vList == null)
                    throw new RecoredNotFoundException("Data Not Available");

                vList.isActive = 0;
                adbContext.employee_bank.Update(vList);
                await Task.FromResult(adbContext.SaveChanges());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Employee_Bank>> FindPaginated(int pageIndex, int pageSize, string searchValue)
        {
            try
            {
                IEnumerable<Employee_Bank> vList;
                if (String.IsNullOrEmpty(searchValue))
                    vList = adbContext.employee_bank.Skip(pageIndex * pageSize).Take(pageSize).ToList();
                else
                    vList = adbContext.employee_bank.Where(w => new[] { Convert.ToString(w.Emp_Id), w.Bank_Name, w.Bank_Code, w.Account_Code, Convert.ToString(w.Account_No), w.Account_Holder, w.Account_Type, w.Notes, w.Version_Id }.Any(a => a.Contains(searchValue))).Skip(pageIndex * pageSize).Take(pageSize).ToList();

                if (vList == null || vList.Count() == 0)
                    throw new RecoredNotFoundException("Data Not Available");

                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int RecordCount(string searchValue)
        {
            try
            {
                if (String.IsNullOrEmpty(searchValue))
                {
                    var vCount = (from emp in adbContext.employee_bank
                                  select emp.Emp_Bank_Id).Count();
                    return vCount;
                }
                else
                {
                    var vList = adbContext.employee_bank.
                        Where(w => new[] { Convert.ToString(w.Emp_Id), w.Bank_Name, w.Bank_Code, w.Account_Code, Convert.ToString(w.Account_Title), Convert.ToString(w.Account_No), w.Account_Holder, w.Account_Type, w.Notes, w.Version_Id }.Any(a => a.Contains(searchValue))).Count();

                    return vList;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Exists(Employee_Bank entity)
        {
            try
            {
                int intCount = 0;
                if (entity.Emp_Bank_Id > 0) //Update Validation
                    intCount = adbContext.employee_bank.Where(w => w.Emp_Bank_Id != entity.Emp_Bank_Id && w.Emp_Id == entity.Emp_Id && w.Bank_Name == entity.Bank_Name && w.Bank_Code == entity.Bank_Code && w.Account_Code == entity.Account_Code && w.Account_No == entity.Account_No).Count();
                else //Insert Validation
                    intCount = adbContext.employee_bank.Where(w => w.Bank_Name == entity.Bank_Name && w.Bank_Code == entity.Bank_Code && w.Account_Code == entity.Account_Code && w.Account_No == entity.Account_No).Count();
                return (intCount > 0 ? true : false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ReturnBy<Employee_BankView>> GetPaginated(PaginationBy search)
        {
            try
            {
                string strOrder = string.IsNullOrEmpty(search.OrderBy) ? "Emp_Bank_Id" : search.OrderBy;
                string strWhere = Common.Search.WhereString(search);

                IEnumerable<Employee_BankView> vEmploye_Bank;
                if (!String.IsNullOrEmpty(search.CommonSearch))
                {
                    vEmploye_Bank = (from emp in adbContext.employee
                                     join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id
                                     join emp_Bank in adbContext.employee_bank on emp.Emp_Id equals emp_Bank.Emp_Id
                                     select new Employee_BankView
                                     {
                                         Emp_Bank_Id = emp_Bank.Emp_Bank_Id,
                                         Emp_Id = emp_Bank.Emp_Id,
                                         Bank_Code = emp_Bank.Bank_Code,
                                         Bank_Name = emp_Bank.Bank_Name,
                                         Account_Title = emp_Bank.Account_Title,
                                         Account_No = emp_Bank.Account_No,
                                         Account_Holder = emp_Bank.Account_Holder,
                                         Account_Type = emp_Bank.Account_Type,
                                         Account_Code = emp_Bank.Account_Code,
                                         isPayed = emp_Bank.isPayed,
                                         Emp_Doc_Id = emp_Bank.Emp_Doc_Id,
                                         isRequired = emp_Bank.isRequired,
                                         Notes = emp_Bank.Notes,
                                         Version_Id = emp_Bank.Version_Id,
                                         isActive = emp_Bank.isActive,
                                         AddedBy = emp_Bank.AddedBy,
                                         UpdatedBy = emp_Bank.UpdatedBy,
                                         Company_Id = emp.Company_Id
                                     }).Where(w => new[] { Convert.ToString(w.Emp_Bank_Id), w.Bank_Code.ToLower(), Convert.ToString(w.Emp_Id), w.Bank_Name.ToLower(), Convert.ToString(w.Account_No), w.Account_Type.ToLower() }.Any(a => a.Contains(search.CommonSearch.ToLower()))).OrderBy(strOrder).ToList();
                }
                else
                {
                    vEmploye_Bank = (from emp in adbContext.employee
                                     join cmp in adbContext.company on emp.Company_Id equals cmp.Company_Id
                                     join emp_Bank in adbContext.employee_bank on emp.Emp_Id equals emp_Bank.Emp_Id
                                     select new Employee_BankView
                                     {
                                         Emp_Bank_Id = emp_Bank.Emp_Bank_Id,
                                         Emp_Id = emp_Bank.Emp_Id,
                                         Bank_Code = emp_Bank.Bank_Code,
                                         Bank_Name = emp_Bank.Bank_Name,
                                         Account_Title = emp_Bank.Account_Title,
                                         Account_No = emp_Bank.Account_No,
                                         Account_Holder = emp_Bank.Account_Holder,
                                         Account_Type = emp_Bank.Account_Type,
                                         Account_Code = emp_Bank.Account_Code,
                                         isPayed = emp_Bank.isPayed,
                                         Emp_Doc_Id = emp_Bank.Emp_Doc_Id,
                                         isRequired = emp_Bank.isRequired,
                                         Notes = emp_Bank.Notes,
                                         Version_Id = emp_Bank.Version_Id,
                                         isActive = emp_Bank.isActive,
                                         AddedBy = emp_Bank.AddedBy,
                                         UpdatedBy = emp_Bank.UpdatedBy,
                                         Company_Id = emp.Company_Id
                                     }).Where(strWhere).OrderBy(strOrder).ToList();
                }

                   

                if (vEmploye_Bank == null || vEmploye_Bank.Count() == 0)
                    throw new RecoredNotFoundException("Get Data Empty");

                ReturnBy<Employee_BankView> vList = new ReturnBy<Employee_BankView>()
                {
                    list = vEmploye_Bank.Skip(search.PageIndex * search.PageSize).Take(search.PageSize).ToList(),
                    RecordCount = vEmploye_Bank.Count()
                };
                return await Task.FromResult(vList);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
