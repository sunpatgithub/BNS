﻿using System;
using System.Linq;
using System.Threading.Tasks;
using HR.CommonUtility;
using HR.WebApi.Common;
using HR.WebApi.Interfaces;
using HR.WebApi.ModelView;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HR.WebApi.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    [ActionFilters.Log]
    [ServiceFilter(typeof(ActionFilters.TokenVerify))]
    public class Raf_RejectedController : ControllerBase
    {
        private ICommonRepository<Raf_RejectedView> raf_rejectedRepository { get; set; }
        private IPaginated<Raf_RejectedView> commonQueryRepo { get; set; }
        public Raf_RejectedController(ICommonRepository<Raf_RejectedView> commonRepository, IPaginated<Raf_RejectedView> commonQueryRepo)
        {
            raf_rejectedRepository = commonRepository;
            this.commonQueryRepo = commonQueryRepo;
        }

        // GET: api/Raf_Rejected/GetAll/1000
        // GET: api/Raf_Rejected/GetAll
        [HttpGet]
        [HttpGet("{RecordLimit}")]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Rejected", EnumPermission.ViewAll })]
        public async Task<IActionResult> GetAll(int RecordLimit)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                var vList = await raf_rejectedRepository.GetAll(RecordLimit);

                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Get Successfully";
                objHelper.Data = vList;

                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        // GET: api/Raf_Rejected/GetAll
        [HttpGet("{id}")]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Rejected", EnumPermission.View })]
        public async Task<IActionResult> Get(int id)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                var vList = await raf_rejectedRepository.Get(id);

                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Get Successfully";
                objHelper.Data = vList;

                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        // GET: api/Raf_Rejected/FindPagination
        //[HttpGet] old
        [HttpPost]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Rejected", EnumPermission.View })]
        public async Task<IActionResult> FindPagination(Pagination pagination)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                ReturnBy<Raf_RejectedView> vList = new ReturnBy<Raf_RejectedView>();
                vList.list = await raf_rejectedRepository.FindPaginated(pagination.PageIndex, pagination.PageSize, pagination.CommonSearch);
                if (vList.list.Count() == 0)
                {
                    objHelper.Status = StatusCodes.Status200OK;
                    objHelper.Message = "Get Empty Data";
                }
                else
                {
                    vList.RecordCount = raf_rejectedRepository.RecordCount(pagination.CommonSearch);
                    objHelper.Status = StatusCodes.Status200OK;
                    objHelper.Message = "Get Successfully";
                    objHelper.Data = vList;
                }
                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        // GET Raf_Rejected search by
        // GET: api/Raf_Rejected/GetBy/
        //[HttpGet] old
        [HttpPost]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Rejected", EnumPermission.View })]
        public async Task<IActionResult> GetBy(PaginationBy searchBy)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                var vList = await commonQueryRepo.GetPaginated(searchBy);

                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Get Successfully";
                objHelper.Data = vList;

                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        // POST: api/Raf_Rejected/Add
        [HttpPost]
        [ServiceFilter(typeof(ActionFilters.AuditLog))]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Rejected", EnumPermission.Add })]
        public async Task<IActionResult> Add(Raf_RejectedView raf_approved)
        {
            ResponseHelper objHelper = new ResponseHelper();
            if (!ModelState.IsValid)
            {
                objHelper.Status = StatusCodes.Status424FailedDependency;
                objHelper.Message = ModelException.Errors(ModelState);
                return BadRequest(objHelper);
            }

            try
            {
                if (raf_rejectedRepository.Exists(raf_approved))
                {
                    objHelper.Status = StatusCodes.Status200OK;
                    objHelper.Message = "Data already available";
                    return Ok(objHelper);
                }
                await raf_rejectedRepository.Insert(raf_approved);
                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Saved Successfully";
                objHelper.Data = raf_approved;
                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        // PUT: api/Raf_Rejected/Edit
        //[HttpPut]
        //[ServiceFilter(typeof(ActionFilters.AuditLog))]
        //[TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Rejected", EnumPermission.Edit })]
        //public async Task<IActionResult> Edit(Raf_RejectedView raf_approved)
        //{
        //    ResponseHelper objHelper = new ResponseHelper();
        //    if (!ModelState.IsValid)
        //    {
        //        objHelper.Status = StatusCodes.Status424FailedDependency;
        //        objHelper.Message = ModelException.Errors(ModelState);
        //        return BadRequest(objHelper);
        //    }

        //    try
        //    {
        //        if (raf_rejectedRepository.Exists(raf_approved))
        //        {
        //            objHelper.Status = StatusCodes.Status200OK;
        //            objHelper.Message = "Data already available";
        //            return Ok(objHelper);
        //        }
        //        await raf_rejectedRepository.Update(raf_approved);
        //        objHelper.Status = StatusCodes.Status200OK;
        //        objHelper.Message = "Saved Successfully";
        //        return Ok(objHelper);
        //    }
        //    catch (Exception ex)
        //    {
        //        objHelper.Status = StatusCodes.Status500InternalServerError;
        //        objHelper.Message = ex.Message;
        //        return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
        //    }

        //}

        // PUT: api/Raf_Rejected/UpdateStatus/34,1
        // PUT: api/Raf_Rejected/UpdateStatus/34,0
        //[HttpPut("{id},{isActive}")]
        //[ServiceFilter(typeof(ActionFilters.AuditLog))]
        //[TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Rejected", EnumPermission.Edit })]
        //public async Task<IActionResult> UpdateStatus(int id, short isActive)
        //{
        //    ResponseHelper objHelper = new ResponseHelper();
        //    try
        //    {
        //        await raf_rejectedRepository.ToogleStatus(id, isActive);
        //        objHelper.Status = StatusCodes.Status200OK;
        //        objHelper.Message = "Saved Successfully";
        //        objHelper.Data = await raf_rejectedRepository.Get(id);
        //        return Ok(objHelper);
        //    }
        //    catch (Exception ex)
        //    {
        //        objHelper.Status = StatusCodes.Status500InternalServerError;
        //        objHelper.Message = ex.Message;
        //        return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
        //    }
        //}

        // DELETE: api/Raf_Rejected/Delete/5

        [HttpDelete("{id}")]
        [ServiceFilter(typeof(ActionFilters.AuditLog))]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Rejected", EnumPermission.Delete })]
        public async Task<IActionResult> Delete(int id)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                await raf_rejectedRepository.Delete(id);
                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Saved Successfully";
                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }
    }
}