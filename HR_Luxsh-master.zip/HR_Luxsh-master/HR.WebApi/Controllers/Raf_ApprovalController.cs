﻿using System;
using System.Linq;
using System.Threading.Tasks;
using HR.CommonUtility;
using HR.WebApi.Common;
using HR.WebApi.Interfaces;
using HR.WebApi.ModelView;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HR.WebApi.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    [ActionFilters.Log]
    [ServiceFilter(typeof(ActionFilters.TokenVerify))]
    public class Raf_ApprovalController : ControllerBase
    {
        private ICommonRepository<Raf_ApprovalView> raf_approvalRepository { get; set; }
        private IPaginated<Raf_ApprovalView> commonQueryRepo { get; set; }
        public Raf_ApprovalController(ICommonRepository<Raf_ApprovalView> commonRepository, IPaginated<Raf_ApprovalView> commonQueryRepo)
        {
            raf_approvalRepository = commonRepository;
            this.commonQueryRepo = commonQueryRepo;
        }

        // GET: api/Raf_Approval/GetAll/1000
        // GET: api/Raf_Approval/GetAll
        [HttpGet]
        [HttpGet("{RecordLimit}")]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Approval", EnumPermission.ViewAll })]
        public async Task<IActionResult> GetAll(int RecordLimit)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                var vList = await raf_approvalRepository.GetAll(RecordLimit);

                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Get Successfully";
                objHelper.Data = vList;

                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        // GET: api/Raf_Approval/GetAll
        [HttpGet("{id}")]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Approval", EnumPermission.View })]
        public async Task<IActionResult> Get(int id)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                var vList = await raf_approvalRepository.Get(id);

                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Get Successfully";
                objHelper.Data = vList;

                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        // GET: api/Raf_Approval/FindPagination
        //[HttpGet] old
        [HttpPost]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Approval", EnumPermission.View })]
        public async Task<IActionResult> FindPagination(Pagination pagination)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                ReturnBy<Raf_ApprovalView> vList = new ReturnBy<Raf_ApprovalView>();
                vList.list = await raf_approvalRepository.FindPaginated(pagination.PageIndex, pagination.PageSize, pagination.CommonSearch);
                if (vList.list.Count() == 0)
                {
                    objHelper.Status = StatusCodes.Status200OK;
                    objHelper.Message = "Get Empty Data";
                }
                else
                {
                    vList.RecordCount = raf_approvalRepository.RecordCount(pagination.CommonSearch);
                    objHelper.Status = StatusCodes.Status200OK;
                    objHelper.Message = "Get Successfully";
                    objHelper.Data = vList;
                }
                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        // GET Raf_Approval search by
        // GET: api/Raf_Approval/GetBy/
        //[HttpGet] old
        [HttpPost]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Approval", EnumPermission.View })]
        public async Task<IActionResult> GetBy(PaginationBy searchBy)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                var vList = await commonQueryRepo.GetPaginated(searchBy);

                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Get Successfully";
                objHelper.Data = vList;

                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        // POST: api/Raf_Approval/Add
        [HttpPost]
        [ServiceFilter(typeof(ActionFilters.AuditLog))]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Approval", EnumPermission.Add })]
        public async Task<IActionResult> Add(Raf_ApprovalView raf_approval)
        {
            ResponseHelper objHelper = new ResponseHelper();
            if (!ModelState.IsValid)
            {
                objHelper.Status = StatusCodes.Status424FailedDependency;
                objHelper.Message = ModelException.Errors(ModelState);
                return BadRequest(objHelper);
            }

            try
            {
                if (raf_approvalRepository.Exists(raf_approval))
                {
                    objHelper.Status = StatusCodes.Status200OK;
                    objHelper.Message = "Data already available";
                    return Ok(objHelper);
                }
                await raf_approvalRepository.Insert(raf_approval);
                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Saved Successfully";
                objHelper.Data = raf_approval;
                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        // PUT: api/Raf_Approval/Edit
        //[HttpPut]
        //[ServiceFilter(typeof(ActionFilters.AuditLog))]
        //[TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Approval", EnumPermission.Edit })]
        //public async Task<IActionResult> Edit(Raf_ApprovalView raf_approval)
        //{
        //    ResponseHelper objHelper = new ResponseHelper();
        //    if (!ModelState.IsValid)
        //    {
        //        objHelper.Status = StatusCodes.Status424FailedDependency;
        //        objHelper.Message = ModelException.Errors(ModelState);
        //        return BadRequest(objHelper);
        //    }

        //    try
        //    {
        //        if (raf_approvalRepository.Exists(raf_approval))
        //        {
        //            objHelper.Status = StatusCodes.Status200OK;
        //            objHelper.Message = "Data already available";
        //            return Ok(objHelper);
        //        }
        //        await raf_approvalRepository.Update(raf_approval);
        //        objHelper.Status = StatusCodes.Status200OK;
        //        objHelper.Message = "Saved Successfully";
        //        return Ok(objHelper);
        //    }
        //    catch (Exception ex)
        //    {
        //        objHelper.Status = StatusCodes.Status500InternalServerError;
        //        objHelper.Message = ex.Message;
        //        return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
        //    }
        //}

        // PUT: api/Raf_Approval/UpdateStatus/34,1
        // PUT: api/Raf_Approval/UpdateStatus/34,0
        //[HttpPut("{id},{isActive}")]
        //[ServiceFilter(typeof(ActionFilters.AuditLog))]
        //[TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Approval", EnumPermission.Edit })]
        //public async Task<IActionResult> UpdateStatus(int id, short isActive)
        //{
        //    ResponseHelper objHelper = new ResponseHelper();
        //    try
        //    {
        //        await raf_approvalRepository.ToogleStatus(id, isActive);
        //        objHelper.Status = StatusCodes.Status200OK;
        //        objHelper.Message = "Saved Successfully";
        //        objHelper.Data = await raf_approvalRepository.Get(id);
        //        return Ok(objHelper);
        //    }
        //    catch (Exception ex)
        //    {
        //        objHelper.Status = StatusCodes.Status500InternalServerError;
        //        objHelper.Message = ex.Message;
        //        return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
        //    }
        //}

        // DELETE: api/Raf_Approval/Delete/5

        [HttpDelete("{id}")]
        [ServiceFilter(typeof(ActionFilters.AuditLog))]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Approval", EnumPermission.Delete })]
        public async Task<IActionResult> Delete(int id)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                await raf_approvalRepository.Delete(id);
                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Saved Successfully";
                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }
    }
}