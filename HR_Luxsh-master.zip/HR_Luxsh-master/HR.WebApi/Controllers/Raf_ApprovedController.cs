﻿using System;
using System.Linq;
using System.Threading.Tasks;
using HR.CommonUtility;
using HR.WebApi.Common;
using HR.WebApi.Interfaces;
using HR.WebApi.ModelView;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HR.WebApi.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    [ActionFilters.Log]
    [ServiceFilter(typeof(ActionFilters.TokenVerify))]
    public class Raf_ApprovedController : ControllerBase
    {
        private ICommonRepository<Raf_ApprovedView> raf_approvedRepository { get; set; }
        private IPaginated<Raf_ApprovedView> commonQueryRepo { get; set; }
        public Raf_ApprovedController(ICommonRepository<Raf_ApprovedView> commonRepository, IPaginated<Raf_ApprovedView> commonQueryRepo)
        {
            raf_approvedRepository = commonRepository;
            this.commonQueryRepo = commonQueryRepo;
        }

        // GET: api/Raf_Approved/GetAll/1000
        // GET: api/Raf_Approved/GetAll
        [HttpGet]
        [HttpGet("{RecordLimit}")]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Approved", EnumPermission.ViewAll })]
        public async Task<IActionResult> GetAll(int RecordLimit)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                var vList = await raf_approvedRepository.GetAll(RecordLimit);

                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Get Successfully";
                objHelper.Data = vList;

                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        // GET: api/Raf_Approved/GetAll
        [HttpGet("{id}")]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Approved", EnumPermission.View })]
        public async Task<IActionResult> Get(int id)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                var vList = await raf_approvedRepository.Get(id);

                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Get Successfully";
                objHelper.Data = vList;

                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        // GET: api/Raf_Approved/FindPagination
        //[HttpGet] old
        [HttpPost]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Approved", EnumPermission.View })]
        public async Task<IActionResult> FindPagination(Pagination pagination)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                ReturnBy<Raf_ApprovedView> vList = new ReturnBy<Raf_ApprovedView>();
                vList.list = await raf_approvedRepository.FindPaginated(pagination.PageIndex, pagination.PageSize, pagination.CommonSearch);
                if (vList.list.Count() == 0)
                {
                    objHelper.Status = StatusCodes.Status200OK;
                    objHelper.Message = "Get Empty Data";
                }
                else
                {
                    vList.RecordCount = raf_approvedRepository.RecordCount(pagination.CommonSearch);
                    objHelper.Status = StatusCodes.Status200OK;
                    objHelper.Message = "Get Successfully";
                    objHelper.Data = vList;
                }
                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        // GET Raf_Approved search by
        // GET: api/Raf_Approved/GetBy/
        //[HttpGet] old
        [HttpPost]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Approved", EnumPermission.View })]
        public async Task<IActionResult> GetBy(PaginationBy searchBy)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                var vList = await commonQueryRepo.GetPaginated(searchBy);

                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Get Successfully";
                objHelper.Data = vList;

                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        // POST: api/Raf_Approved/Add
        [HttpPost]
        [ServiceFilter(typeof(ActionFilters.AuditLog))]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Approved", EnumPermission.Add })]
        public async Task<IActionResult> Add(Raf_ApprovedView raf_approved)
        {
            ResponseHelper objHelper = new ResponseHelper();
            if (!ModelState.IsValid)
            {
                objHelper.Status = StatusCodes.Status424FailedDependency;
                objHelper.Message = ModelException.Errors(ModelState);
                return BadRequest(objHelper);
            }

            try
            {
                if (raf_approvedRepository.Exists(raf_approved))
                {
                    objHelper.Status = StatusCodes.Status200OK;
                    objHelper.Message = "Data already available";
                    return Ok(objHelper);
                }
                await raf_approvedRepository.Insert(raf_approved);
                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Saved Successfully";
                objHelper.Data = raf_approved;
                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        // PUT: api/Raf_Approved/Edit
        //[HttpPut]
        //[ServiceFilter(typeof(ActionFilters.AuditLog))]
        //[TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Approved", EnumPermission.Edit })]
        //public async Task<IActionResult> Edit(Raf_ApprovedView raf_approved)
        //{
        //    ResponseHelper objHelper = new ResponseHelper();
        //    if (!ModelState.IsValid)
        //    {
        //        objHelper.Status = StatusCodes.Status424FailedDependency;
        //        objHelper.Message = ModelException.Errors(ModelState);
        //        return BadRequest(objHelper);
        //    }

        //    try
        //    {
        //        if (raf_approvedRepository.Exists(raf_approved))
        //        {
        //            objHelper.Status = StatusCodes.Status200OK;
        //            objHelper.Message = "Data already available";
        //            return Ok(objHelper);
        //        }
        //        await raf_approvedRepository.Update(raf_approved);
        //        objHelper.Status = StatusCodes.Status200OK;
        //        objHelper.Message = "Saved Successfully";
        //        return Ok(objHelper);
        //    }
        //    catch (Exception ex)
        //    {
        //        objHelper.Status = StatusCodes.Status500InternalServerError;
        //        objHelper.Message = ex.Message;
        //        return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
        //    }

        //}

        // PUT: api/Raf_Approved/UpdateStatus/34,1
        // PUT: api/Raf_Approved/UpdateStatus/34,0
        //[HttpPut("{id},{isActive}")]
        //[ServiceFilter(typeof(ActionFilters.AuditLog))]
        //[TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Approved", EnumPermission.Edit })]
        //public async Task<IActionResult> UpdateStatus(int id, short isActive)
        //{
        //    ResponseHelper objHelper = new ResponseHelper();
        //    try
        //    {
        //        await raf_approvedRepository.ToogleStatus(id, isActive);
        //        objHelper.Status = StatusCodes.Status200OK;
        //        objHelper.Message = "Saved Successfully";
        //        objHelper.Data = await raf_approvedRepository.Get(id);
        //        return Ok(objHelper);
        //    }
        //    catch (Exception ex)
        //    {
        //        objHelper.Status = StatusCodes.Status500InternalServerError;
        //        objHelper.Message = ex.Message;
        //        return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
        //    }
        //}

        // DELETE: api/Raf_Approved/Delete/5

        [HttpDelete("{id}")]
        [ServiceFilter(typeof(ActionFilters.AuditLog))]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Raf_Approved", EnumPermission.Delete })]
        public async Task<IActionResult> Delete(int id)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                await raf_approvedRepository.Delete(id);
                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Saved Successfully";
                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }
    }
}