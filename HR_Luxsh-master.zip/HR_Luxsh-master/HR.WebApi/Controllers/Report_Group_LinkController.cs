﻿using System;
using System.Threading.Tasks;
using HR.CommonUtility;
using HR.WebApi.Common;
using HR.WebApi.Interfaces;
using HR.WebApi.ModelView;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HR.WebApi.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    [ActionFilters.Log]
    [ServiceFilter(typeof(ActionFilters.TokenVerify))]
    public class Report_Group_LinkController : ControllerBase
    {
        private IReportBuilder<Report_Group_LinkView> report_group_linkRepository { get; set; }
        public Report_Group_LinkController(IReportBuilder<Report_Group_LinkView> commonRepository)
        {
            report_group_linkRepository = commonRepository;
        }

        // GET: api/Report_Group_Link/GetAll/
        // GET: api/Report_Group_Link/GetAll/1000
        [HttpGet]
        [HttpGet("{recordLimit}")]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Report_Group_Link", EnumPermission.ViewAll })]
        public async Task<IActionResult> GetAll(int recordLimit)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                var vList = await report_group_linkRepository.GetAll(recordLimit);

                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Get Successfully";
                objHelper.Data = vList;

                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        // GET: api/Report_Group_Link/Get/10
        [HttpGet("{id}")]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Report_Group_Link", EnumPermission.View })]
        public async Task<IActionResult> Get(int id)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                var vList = await report_group_linkRepository.Get(id);

                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Get Successfully";
                objHelper.Data = vList;

                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        [HttpPost]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Report_Group_Link", EnumPermission.View })]
        public async Task<IActionResult> GetBy(PaginationBy searchBy)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                var vList = await report_group_linkRepository.GetPaginated(searchBy);

                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Get Successfully";
                objHelper.Data = vList;

                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        //Add Data
        // POST: api/Report_Group_Link/Add - body data 
        [HttpPost]
        [ServiceFilter(typeof(ActionFilters.AuditLog))]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Report_Group_Link", EnumPermission.Add })]
        public async Task<IActionResult> Add(Report_Group_LinkView report_group_link)
        {
            ResponseHelper objHelper = new ResponseHelper();
            if (!ModelState.IsValid)
            {
                objHelper.Status = StatusCodes.Status424FailedDependency;
                objHelper.Message = ModelException.Errors(ModelState);
                return BadRequest(objHelper);
            }

            try
            {
                if (report_group_linkRepository.Exists(report_group_link))
                {
                    objHelper.Status = StatusCodes.Status200OK;
                    objHelper.Message = "Data already available";
                    return Ok(objHelper);
                }

                await report_group_linkRepository.Insert(report_group_link);
                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Saved Successfully";
                objHelper.Data = report_group_link;
                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        ////Edit Data
        //// PUT: api/Report_Group_Link/Edit - body data 
        //[HttpPut]
        //[ServiceFilter(typeof(ActionFilters.AuditLog))]
        //[TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Report_Group_Link", EnumPermission.Edit })]
        //public async Task<IActionResult> Edit(Report_Group_LinkView report_group_link)
        //{
        //    ResponseHelper objHelper = new ResponseHelper();
        //    if (!ModelState.IsValid)
        //    {
        //        objHelper.Status = StatusCodes.Status424FailedDependency;
        //        objHelper.Message = ModelException.Errors(ModelState);
        //        return BadRequest(objHelper);
        //    }

        //    try
        //    {
        //        //if (report_group_linkRepository.Exists(report_group_link))
        //        //{
        //        //    objHelper.Status = StatusCodes.Status200OK;
        //        //    objHelper.Message = "Data already available";
        //        //    return Ok(objHelper);
        //        //}

        //        await report_group_linkRepository.Update(report_group_link);
        //        objHelper.Status = StatusCodes.Status200OK;
        //        objHelper.Message = "Saved Successfully";
        //        return Ok(objHelper);
        //    }
        //    catch (Exception ex)
        //    {
        //        objHelper.Status = StatusCodes.Status500InternalServerError;
        //        objHelper.Message = ex.Message;
        //        return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
        //    }
        //}

        ////Delete Data
        //// DELETE: api/Report_Group_Link/Delete/1
        //[HttpDelete("{id}")]
        //[ServiceFilter(typeof(ActionFilters.AuditLog))]
        //[TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Report_Group_Link", EnumPermission.Delete })]
        //public async Task<IActionResult> Delete(int id)
        //{
        //    ResponseHelper objHelper = new ResponseHelper();
        //    try
        //    {
        //        await report_group_linkRepository.Delete(id);
        //        objHelper.Status = StatusCodes.Status200OK;
        //        objHelper.Message = "Saved Successfully";
        //        return Ok(objHelper);
        //    }
        //    catch (Exception ex)
        //    {
        //        objHelper.Status = StatusCodes.Status500InternalServerError;
        //        objHelper.Message = ex.Message;
        //        return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
        //    }
        //}
    }
}