﻿using HR.CommonUtility;
using HR.WebApi.Activities;
using HR.WebApi.Common;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using HR.WebApi.ModelView;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using LINQtoCSV;

namespace HR.WebApi.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    [ActionFilters.Log]
    [ServiceFilter(typeof(ActionFilters.TokenVerify))]

    public class PayrollServiceController : ControllerBase
    {
        private PayrollService payrollService { get; set; }
        private IActivity<EmployeeView> activity { get; set; }
        
        public PayrollServiceController(PayrollService payrollService, IActivity<EmployeeView> activity)
        {
            this.payrollService = payrollService;
            this.activity = activity;
        }

        [HttpGet("{Status}")]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Payroll", EnumPermission.View })]
        public async Task<IActionResult> Get(string Status)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                var vList = await payrollService.GetDetails(Status);

                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Get Successfully";
                objHelper.Data = vList;

                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        [HttpPost]
        [ServiceFilter(typeof(ActionFilters.AuditLog))]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Payroll", EnumPermission.Add })]
        public async Task<IActionResult> Add(EmployeeView employee)
        {
            ResponseHelper objHelper = new ResponseHelper();
            if (!ModelState.IsValid)
            {
                objHelper.Status = StatusCodes.Status410Gone;
                objHelper.Message = ModelException.Errors(ModelState);
                return BadRequest(objHelper);
            }

            try
            {
                await activity.Execute(employee, "Open");
                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Saved Successfully";
                objHelper.Data = employee;
                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        [HttpPut("{id},{status}")]
        [ServiceFilter(typeof(ActionFilters.AuditLog))]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Payroll", EnumPermission.Edit })]
        public async Task<IActionResult> UpdateStatus(int id, string status)
        {
            ResponseHelper objHelper = new ResponseHelper();
            if (!ModelState.IsValid)
            {
                objHelper.Status = StatusCodes.Status410Gone;
                objHelper.Message = "Invalid Model State";
                return BadRequest(objHelper);
            }

            try
            {
                await payrollService.ToogleStatus(id, status);
                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Saved Successfully";
                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        [HttpPost]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "Payroll", EnumPermission.View })]
        public async Task<IActionResult> Export(ExportData exportData)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                string strexcelName = $"NewJoiningList-{DateTime.Now.ToString("yyyyMMddHHmmssfff")}" + exportData.Extension;
                var list = await payrollService.GetDetails(exportData.status);
                
                if(exportData.Extension == ".csv")
                {
                    CsvFileDescription outputFileDescription = new CsvFileDescription
                    {
                        SeparatorChar = ',',
                        FirstLineHasColumnNames = true,
                        EnforceCsvColumnAttribute = true
                    };

                    CsvContext cc = new CsvContext();

                    byte[] file = null;
                    using (MemoryStream memoryStream = new MemoryStream())
                    {
                        using (StreamWriter streamWriter = new StreamWriter(memoryStream))
                        {
                            cc.Write(list, streamWriter, outputFileDescription);
                            streamWriter.Flush();
                            file = memoryStream.ToArray();
                        }
                    }
                    return File(file, "text/csv", strexcelName);
                }

                else if (exportData.Extension == ".xlsx" || exportData.Extension == ".xls")
                {
                    var memory = new MemoryStream();

                    using (var package = new ExcelPackage(memory))
                    {
                        var workSheet = package.Workbook.Worksheets.Add("NewJoiningList");

                        workSheet.Cells.LoadFromCollection(list, true);
                        workSheet.Cells.AutoFitColumns();
                        package.Save();
                    }

                    memory.Position = 0;

                    objHelper.Status = StatusCodes.Status200OK;
                    objHelper.Message = "Saved Successfully";

                    return File(memory, GetMimeTypes()[exportData.Extension], strexcelName);
                }
                else
                {
                    objHelper.Status = StatusCodes.Status406NotAcceptable;
                    objHelper.Message = "Invalid Extension";
                    return Ok(objHelper);
                }
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }
        private Dictionary<string, string> GetMimeTypes()
        {
            return new Dictionary<string, string>
        {
            {".csv", "text/csv"},
            {".xls", "application/vnd.ms-excel"},
            {".xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}
        };
        }
    }
}