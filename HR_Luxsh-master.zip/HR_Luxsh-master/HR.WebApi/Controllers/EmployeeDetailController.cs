﻿using HR.CommonUtility;
using HR.WebApi.Model;
using HR.WebApi.ModelView;
using HR.WebApi.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using HR.WebApi.Common;
using HR.WebApi.Interfaces;

namespace HR.WebApi.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    [ActionFilters.Log]
    [ServiceFilter(typeof(ActionFilters.TokenVerify))]
    public class EmployeeDetailController : ControllerBase
    {
        public EmployeeDetailService employeeDetailService { get; set; }
        public IPaginated<EmployeeDetailView> paginatedQueryRepo { get; set; }
        IActivity<EmployeeView> activity { get; set; }
        public EmployeeDetailController(EmployeeDetailService commonRepository, IPaginated<EmployeeDetailView> paginatedQueryRepository, IActivity<EmployeeView> activity)
        {
            employeeDetailService = commonRepository;
            paginatedQueryRepo = paginatedQueryRepository;
            this.activity = activity;
        }

        //[HttpGet()]
        //[HttpGet("{recordLimit}")]
        //public async Task<IActionResult> GetAll(int recordLimit)
        //{
        //    ResponseHelper objHelper = new ResponseHelper();
        //    try
        //    {
        //        var vList = await employeeDetailService.GetAll(recordLimit);
        //        if (vList == null)
        //        {
        //            objHelper.Status = StatusCodes.Status200OK; ;
        //            objHelper.Message = "Get Empty Data";
        //        }
        //        else
        //        {
        //            objHelper.Status = StatusCodes.Status200OK; ;
        //            objHelper.Message = "Get Successfully";
        //            objHelper.Data = vList;
        //        }
        //        return Ok(objHelper);
        //    }
        //    catch
        //    {
        //        objHelper.Status = StatusCodes.Status500InternalServerError;
        //        objHelper.Message = "Get Unsuccessful";
        //        return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
        //    }
        //}

        //[HttpGet] old
        [HttpPost]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "EmployeeDetail", EnumPermission.View })]
        public async Task<IActionResult> Get(PaginationBy obj)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                var vList = await employeeDetailService.GetEmployee(obj);

                objHelper.Status = StatusCodes.Status200OK; ;
                objHelper.Message = "Get Successfully";
                objHelper.Data = vList;

                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        [HttpPost]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "EmployeeDetail", EnumPermission.View })]
        public async Task<IActionResult> GetBy(PaginationBy searchBy)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                var vList = await paginatedQueryRepo.GetPaginated(searchBy);

                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Get Successfully";
                objHelper.Data = vList;

                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "EmployeeDetail", EnumPermission.Add })]
        [ServiceFilter(typeof(ActionFilters.AuditLog))]
        [HttpPost]
        public async Task<IActionResult> Add(EmployeeView employee)
        {
            ResponseHelper objHelper = new ResponseHelper();
            if (!ModelState.IsValid)
            {
                objHelper.Status = StatusCodes.Status410Gone;
                objHelper.Message = ModelException.Errors(ModelState);
                return BadRequest(objHelper);
            }

            try
            {
                await employeeDetailService.Insert(employee);
                await activity.Execute(employee,"Open");

                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Saved Successfully";
                objHelper.Data = employee;
                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        //// PUT: api/Employee/5
        //[ActionFilters.AuditLog]
        ////Role + Module + Permission
        //[HttpPut]
        //public async Task<IActionResult> Edit(Employee employee)
        //{
        //    ResponseHelper objHelper = new ResponseHelper();
        //    if (!ModelState.IsValid)
        //    {
        //        objHelper.Status = StatusCodes.Status410Gone;
        //        objHelper.Message = "Invalid Model State";
        //        return BadRequest(objHelper);
        //    }

        //    try
        //    {

        //        await employeeDetailService.Update(employee);
        //        objHelper.Status = StatusCodes.Status200OK; ;
        //        objHelper.Message = "Saved Successfully";
        //        return Ok(objHelper);
        //    }
        //    catch
        //    {
        //        objHelper.Status = StatusCodes.Status500InternalServerError;
        //        objHelper.Message = "Get Unsuccessful";
        //        return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
        //    }
        //}

        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "EmployeeDetail", EnumPermission.Edit })]
        [ServiceFilter(typeof(ActionFilters.AuditLog))]
        [HttpPut("{id},{isActive}")]
        public async Task<IActionResult> UpdateStatus(int id, short isActive)
        {
            ResponseHelper objHelper = new ResponseHelper();
            if (!ModelState.IsValid)
            {
                objHelper.Status = StatusCodes.Status410Gone;
                objHelper.Message = "Invalid Model State";
                return BadRequest(objHelper);
            }

            try
            {
                await employeeDetailService.ToogleStatus(id, isActive);
                objHelper.Status = StatusCodes.Status200OK; ;
                objHelper.Message = "Saved Successfully";
                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "EmployeeDetail", EnumPermission.Delete })]
        [ServiceFilter(typeof(ActionFilters.AuditLog))]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                await employeeDetailService.Delete(id);
                objHelper.Status = StatusCodes.Status200OK;
                objHelper.Message = "Saved Successfully";
                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }


        [HttpGet("{id}")]
        [TypeFilter(typeof(ActionFilters.RolesValidate), Arguments = new object[] { "EmployeeDetail", EnumPermission.View })]
        public async Task<IActionResult> GetRepotingWiseEmployee(int id)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                var vList = await employeeDetailService.RepotingWiseEmployee(id);

                objHelper.Status = StatusCodes.Status200OK; ;
                objHelper.Message = "Get Successfully";
                objHelper.Data = vList;

                return Ok(objHelper);
            }
            catch (Exception ex)
            {
                objHelper.Status = StatusCodes.Status500InternalServerError;
                objHelper.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }
    }
}
