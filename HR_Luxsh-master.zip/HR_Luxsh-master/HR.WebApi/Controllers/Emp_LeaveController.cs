﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HR.CommonUtility;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HR.WebApi.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class Emp_LeaveController : ControllerBase
    {
        public ICommonRepository<Emp_Leave> emp_leaveRepository { get; set; }
        public ICommonRepository<Emp_Leave_Approve_History> emp_leaveApproveRepository { get; set; }

        private ResponseHelper objHelper = new ResponseHelper();
        public Emp_LeaveController(ICommonRepository<Emp_Leave> commonRepository, ICommonRepository<Emp_Leave_Approve_History> empleaveHistoryRepository)
        {
            this.emp_leaveRepository = commonRepository;
            this.emp_leaveApproveRepository = empleaveHistoryRepository;
        }

        [HttpPost]
        public async Task<IActionResult> Add(Emp_Leave empleave)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
               
                await emp_leaveRepository.Insert(empleave);
                objHelper.Status = 200;
                objHelper.Message = "Saved Successfully";
                objHelper.Data = empleave;
                return Ok(objHelper);
            }
            catch
            {
                objHelper.Status = 510;
                objHelper.Message = "Save Unsuccessful";
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        [HttpPut]
        public async Task<IActionResult> Update_Leave_Status(Emp_Leave empleave)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                await emp_leaveRepository.Update(empleave);
                objHelper.Status = 200;
                objHelper.Message = "Saved Successfully";
                objHelper.Data = empleave;
                return Ok(objHelper);
            }
            catch
            {
                objHelper.Status = 510;
                objHelper.Message = "Save Unsuccessful";
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get_Employee_Leave_By_EmpId(int id)
        {
            try
            {
                var vList = await emp_leaveRepository.Get(id);

                if (vList == null)
                {
                    objHelper.Status = 200;
                    objHelper.Message = "Get Empty Data";
                }
                else
                {
                    objHelper.Status = 200;
                    objHelper.Message = "Get Successfully";
                    objHelper.Data = vList;
                }
                return Ok(objHelper);
            }
            catch
            {
                objHelper.Status = 510;
                objHelper.Message = "Get Unsuccessful";
                return BadRequest(objHelper);
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get_Leave_Audit_By_LeaveId(int id)
        {
            try
            {
                var vList = await emp_leaveApproveRepository.Get(id);

                if (vList == null)
                {
                    objHelper.Status = 200;
                    objHelper.Message = "Get Empty Data";
                }
                else
                {
                    objHelper.Status = 200;
                    objHelper.Message = "Get Successfully";
                    objHelper.Data = vList;
                }
                return Ok(objHelper);
            }
            catch
            {
                objHelper.Status = 510;
                objHelper.Message = "Get Unsuccessful";
                return BadRequest(objHelper);
            }
        }

    }
}