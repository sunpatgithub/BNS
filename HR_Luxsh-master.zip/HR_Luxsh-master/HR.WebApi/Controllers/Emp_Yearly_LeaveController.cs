﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HR.CommonUtility;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HR.WebApi.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    [ActionFilters.Log]
    public class Emp_Yearly_LeaveController : ControllerBase
    {
        public ICommonRepository<Emp_Yearly_Leave> emp_YearlyleaveRepository { get; set; }
        public IEmp_Yearly_Leave<Emp_Yearly_Leave> Extra_EmpYearLeaveRepository { get; set; }
       // public IEmp_Yearly_Leave<Emp_Leave> Extra_EmpLeaveRepository { get; set; }

        private ResponseHelper objHelper = new ResponseHelper();

        public Emp_Yearly_LeaveController(ICommonRepository<Emp_Yearly_Leave> commonRepository, IEmp_Yearly_Leave<Emp_Yearly_Leave> commonEmpYearLeave)
        {
            this.emp_YearlyleaveRepository = commonRepository;
            this.Extra_EmpYearLeaveRepository = commonEmpYearLeave;
            //this.Extra_EmpLeaveRepository = commonEmpLeave;
        }

        //[ActionFilters.AuditLog]
        [HttpPost]
        public async Task<IActionResult> Add(Emp_Yearly_Leave empyearleave)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                await emp_YearlyleaveRepository.Insert(empyearleave);
                objHelper.Status = 200;
                objHelper.Message = "Saved Successfully";
                objHelper.Data = empyearleave;
                return Ok(objHelper);
            }
            catch
            {
                objHelper.Status = 510;
                objHelper.Message = "Save Unsuccessful";
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var vList = await emp_YearlyleaveRepository.Get(id);

                if (vList == null)
                {
                    objHelper.Status = 200;
                    objHelper.Message = "Get Empty Data";
                }
                else
                {
                    objHelper.Status = 200;
                    objHelper.Message = "Get Successfully";
                    objHelper.Data = vList;
                }
                return Ok(objHelper);
            }
            catch
            {
                objHelper.Status = 510;
                objHelper.Message = "Get Unsuccessful";
                return BadRequest(objHelper);
            }
        }

        [HttpGet("{empid}")]
        public async Task<IActionResult> Get_Employee_TotalLeave_By_EmpId(int empid)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                var vList = await emp_YearlyleaveRepository.GetAll(empid);
                if (vList == null)
                {
                    objHelper.Status = 200;
                    objHelper.Message = "Get Empty Data";
                }
                else
                {
                    objHelper.Status = 200;
                    objHelper.Message = "Get Successfully";
                    objHelper.Data = vList;
                }
                return Ok(objHelper);
            }
            catch
            {
                objHelper.Status = 510;
                objHelper.Message = "Get Unsuccessful";
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        [ServiceFilter(typeof(ActionFilters.AuditLog))]
        [HttpPut]
        public async Task<IActionResult> Update_Employee_Type(Emp_Yearly_Leave empyearleaveObj)
        {
            if (!ModelState.IsValid)
            {
                objHelper.Status = 410;
                objHelper.Message = "Invalid Model State";
                return BadRequest(objHelper);
            }

            try
            {
                await Extra_EmpYearLeaveRepository.Update_Employee_Type(empyearleaveObj.emp_id,empyearleaveObj.emp_type);
                objHelper.Status = 200;
                objHelper.Message = "Saved Successfully";
                return Ok(objHelper);
            }
            catch
            {
                objHelper.Status = 510;
                objHelper.Message = "Save Unsuccessful";
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }

        }

        //[ActionFilters.AuditLog]
        //[HttpPut]
        //public async Task<IActionResult> Update_Employee_TakenLeave(Emp_Leave objEmpLeave)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        objHelper.Status = 410;
        //        objHelper.Message = "Invalid Model State";
        //        return BadRequest(objHelper);
        //    }

        //    try
        //    {
        //        await Extra_EmpLeaveRepository.Update_Employee_TakenLeave(objEmpLeave.emp_yearly_leave_id, objEmpLeave.taken_leave,objEmpLeave.status);
        //        objHelper.Status = 200;
        //        objHelper.Message = "Saved Successfully";
        //        return Ok(objHelper);
        //    }
        //    catch
        //    {
        //        objHelper.Status = 510;
        //        objHelper.Message = "Save Unsuccessful";
        //        return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
        //    }

        //}

        [HttpGet("{emp_id},{leave_type_id}")]
        public async Task<IActionResult> Get_Employee_Leave_By_LeaveType_And_EmpId(int emp_id,int leave_type_id)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                var vList = await Extra_EmpYearLeaveRepository.Get_Employee_Leave_By_LeaveType_And_EmpId(emp_id,leave_type_id);
                if (vList == null)
                {
                    objHelper.Status = 200;
                    objHelper.Message = "Get Empty Data";
                }
                else
                {
                    objHelper.Status = 200;
                    objHelper.Message = "Get Successfully";
                    objHelper.Data = vList;
                }
                return Ok(objHelper);
            }
            catch
            {
                objHelper.Status = 510;
                objHelper.Message = "Get Unsuccessful";
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

    }
}