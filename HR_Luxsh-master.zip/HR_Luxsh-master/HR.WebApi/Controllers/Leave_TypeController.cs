﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HR.CommonUtility;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HR.WebApi.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    [ActionFilters.Log]
    public class Leave_TypeController : ControllerBase
    {
        public ICommonRepository<Leave_Type> leaveTypeRepository { get; set; }
        private ResponseHelper objHelper = new ResponseHelper();

        public Leave_TypeController(ICommonRepository<Leave_Type> commonRepository)
        {
            this.leaveTypeRepository = commonRepository;
        }

        //[ActionFilters.AuditLog]
        [HttpPost]
        public async Task<IActionResult> Add(Leave_Type leaveType)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                await leaveTypeRepository.Insert(leaveType);
                objHelper.Status = 200;
                objHelper.Message = "Saved Successfully";
                objHelper.Data = leaveType;
                return Ok(objHelper);
            }
            catch
            {
                objHelper.Status = 510;
                objHelper.Message = "Save Unsuccessful";
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var vList = await leaveTypeRepository.Get(id);

                if (vList == null)
                {
                    objHelper.Status = 200;
                    objHelper.Message = "Get Empty Data";
                }
                else
                {
                    objHelper.Status = 200;
                    objHelper.Message = "Get Successfully";
                    objHelper.Data = vList;
                }
                return Ok(objHelper);
            }
            catch
            {
                objHelper.Status = 510;
                objHelper.Message = "Get Unsuccessful";
                return BadRequest(objHelper);
            }
        }

        [HttpGet("{recordLimit}")]
        public async Task<IActionResult> GetAll(int recordLimit)
        {
            ResponseHelper objHelper = new ResponseHelper();
            try
            {
                var vList = await leaveTypeRepository.GetAll(recordLimit);
                if (vList == null)
                {
                    objHelper.Status = 200;
                    objHelper.Message = "Get Empty Data";
                }
                else
                {
                    objHelper.Status = 200;
                    objHelper.Message = "Get Successfully";
                    objHelper.Data = vList;
                }
                return Ok(objHelper);
            }
            catch
            {
                objHelper.Status = 510;
                objHelper.Message = "Get Unsuccessful";
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }
        }

        // GET: api/Company/5
        //[HttpGet("{pageIndex},{pageSize}")]
        //public async Task<IActionResult> PaginatedList(int pageIndex, int pageSize, string SearchValue)
        //{
        //    try
        //    {
        //        var vList = await leaveTypeRepository.FindPaginated(pageIndex, pageSize, SearchValue);
        //        if (vList == null)
        //        {
        //            objHelper.Status = 200;
        //            objHelper.Message = "Get Empty Data";
        //        }
        //        else
        //        {
        //            objHelper.Status = 200;
        //            objHelper.Message = "Get Successfully";
        //            objHelper.Data = vList;
        //        }
        //        return Ok(objHelper);
        //    }
        //    catch
        //    {
        //        objHelper.Status = 510;
        //        objHelper.Message = "Get Unsuccessful";
        //        return BadRequest(objHelper);
        //    }
        //}

        [ServiceFilter(typeof(ActionFilters.AuditLog))]
        [HttpPut]
        public async Task<IActionResult> Edit(Leave_Type leaveTypeObj)
        {
            if (!ModelState.IsValid)
            {
                objHelper.Status = 410;
                objHelper.Message = "Invalid Model State";
                return BadRequest(objHelper);
            }

            try
            {
                await leaveTypeRepository.Update(leaveTypeObj);
                objHelper.Status = 200;
                objHelper.Message = "Saved Successfully";
                return Ok(objHelper);
            }
            catch
            {
                objHelper.Status = 510;
                objHelper.Message = "Save Unsuccessful";
                return StatusCode(StatusCodes.Status500InternalServerError, objHelper);
            }

        }


    }
}