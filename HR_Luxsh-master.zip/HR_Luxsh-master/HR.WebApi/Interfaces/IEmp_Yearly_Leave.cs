﻿using HR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HR.WebApi.Interfaces
{
    public interface IEmp_Yearly_Leave<T>
    {
        Task<IEnumerable<T>> Update_Employee_Type(int EmpId,string Emp_Type);
        Task<IEnumerable<T>> Get_Employee_Anuual_Encashment(int CompanyId);
        Task<IEnumerable<T>> Get_Employee_Leave_By_LeaveType_And_EmpId(int Empid,int Leave_type_id);
    }
}
