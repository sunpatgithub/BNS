﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HR.WebApi.Interfaces
{
    public interface IAuthenticationFilter
    {
        //bool OnAuthentication(AuthenticationContext filterContext);

        //void OnAuthenticationChallenge(AuthenticationChallengeContext filterContext);
    }
}
