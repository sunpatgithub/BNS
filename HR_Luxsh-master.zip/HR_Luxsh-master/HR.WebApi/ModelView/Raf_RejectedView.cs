﻿using System;
using System.ComponentModel.DataAnnotations;

namespace HR.WebApi.ModelView
{
    public class Raf_RejectedView
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        public int Raf_Id { get; set; }
        
        [Required]
        public int Raf_Approval_Id { get; set; }
        
        [Required]
        public int Company_Id { get; set; }
        
        [Required]
        public int Dept_Id { get; set; }
        
        [Required]
        public int Desig_Id { get; set; }
        
        [MaxLength(1000)]
        public string Description { get; set; }

        [Required]
        public int RejectedBy { get; set; }

        public DateTime? RejectedOn { get; set; }

        [Required]
        public int AddedBy { get; set; }
        
        public DateTime AddedOn { get; set; } = DateTime.Now;

        public string Raf_Name { get; set; }
        public string raf_approval_Description { get; set; }
        public string Company_Name { get; set; }
        public string Dept_Name { get; set; }
        public string Desig_Name { get; set; }
    }
}