﻿using System;
using System.ComponentModel.DataAnnotations;

namespace HR.WebApi.ModelView
{
    public class VacancyView
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int Company_Id { get; set; }
        public string Company_Name { get; set; }

        [Required]
        public int Site_Id { get; set; }
        public string Site_Name { get; set; }

        [Required]
        public int Dept_Id { get; set; }
        public string Dept_Name { get; set; }

        [Required]
        [StringLength(500, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 3)]
        [RegularExpression(@"\b[\w\s.]+\b", ErrorMessage = "Value must contain any of the following: upper case (A-Z), lower case (a-z), number(0-9), dot(.)")]
        public string JobTitle { get; set; }

        [MaxLength(2000)]
        public string Description { get; set; }

        [MaxLength(2000)]
        public string Notes { get; set; }

        public DateTime ValidFrom { get; set; }

        public DateTime? ValidUpto { get; set; }

        [Required]
        public int NoOfPositions { get; set; }

        [RegularExpression(@"\b[0-1]{1}\b", ErrorMessage = "Value must be 0 or 1.")]
        public Int16 isActive { get; set; }
        
        [Required]
        public int AddedBy { get; set; }

        public DateTime AddedOn { get; set; } = DateTime.Now;

        public int? UpdatedBy { get; set; }

        public DateTime? UpdatedOn { get; set; }
    }
}
