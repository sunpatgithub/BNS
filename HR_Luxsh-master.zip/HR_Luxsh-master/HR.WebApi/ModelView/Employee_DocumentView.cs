﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HR.WebApi.ModelView
{
    public class Employee_DocumentView
    {
        [Key]
        public int Emp_Doc_Id { get; set; }
        [Required]
        public int Emp_Id { get; set; }
        public int? Doc_Id { get; set; }
        public int? Parent_Emp_Doc_Id { get; set; }
        //[Required]
        //public IList<IFormFile> files { get; set; }

        [Required]
        public IFormFile files { get; set; }
        public string Emp_Doc_Name { get; set; }
        [MaxLength(2000)]
        public string Emp_Doc_Path { get; set; }
   
        [MaxLength(2000)]
        public string Notes { get; set; }

        [RegularExpression(@"\b[0-1]{1}\b", ErrorMessage = "Value must be 0 or 1.")]
        public Int16 isActive { get; set; }
        public int AddedBy { get; set; }

        public DateTime AddedOn { get; set; } = DateTime.Now;

        public int? UpdatedBy { get; set; }

        public DateTime? UpdatedOn { get; set; }

        public int Company_Id { get; set; }
    }
}
