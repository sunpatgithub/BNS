﻿using LINQtoCSV;
using System;
using System.ComponentModel;

namespace HR.WebApi.ModelView
{
    public class PayrollView
    {
        [CsvColumn(Name = "TITLE", FieldIndex = 1)]
        [DisplayName("TITLE")]
        public string Title { get; set; }

        [CsvColumn(Name = "INITIAL", FieldIndex = 2)]
        [DisplayName("INITIAL")]
        public string Initial { get; set; }

        [CsvColumn(Name = "FORENAME", FieldIndex = 3)]
        [DisplayName("FORENAME")]
        public string FirstName { get; set; }

        [CsvColumn(Name = "SURNAME", FieldIndex = 4)]
        [DisplayName("SURNAME")]
        public string LastName { get; set; }

        [CsvColumn(Name = "COMPANY", FieldIndex = 5)]
        [DisplayName("Company")]
        public string Company_Name { get; set; }

        [CsvColumn(Name = "JOB TITLE", FieldIndex = 6)]
        [DisplayName("JOB TITLE")]
        public string JobTitle { get; set; }

        [CsvColumn(Name = "EMPLOYMENT TYPE", FieldIndex = 7)]
        [DisplayName("EMPLOYMENT TYPE")]
        public string EmpType { get; set; }

        [CsvColumn(Name = "DEPARTMENT", FieldIndex = 8)]
        [DisplayName("Department")]
        public string Dept_Name { get; set; }

        [CsvColumn(Name = "WORK START DATE", FieldIndex = 9)]
        [DisplayName("WORK START DATE")]
        public string WorkStartDate { get; set; }

        [CsvColumn(Name = "WORK END DATE", FieldIndex = 10)]
        [DisplayName("WORK END DATE")]
        public string WorkEndDate { get; set; }

        [CsvColumn(Name = "EMPLOYEE REFERENCE", FieldIndex = 11)]
        [DisplayName("EMPLOYEE REFERENCE")]
        public string EmpReference { get; set; }

        [CsvColumn(Name = "WORKS REFERENCE", FieldIndex = 12)]
        [DisplayName("WORKS REFERENCE")]
        public string WorksReference { get; set; }

        [CsvColumn(Name = "ADDRESS1", FieldIndex = 13)]
        [DisplayName("ADDRESS1")]
        public string Address1 { get; set; }

        [CsvColumn(Name = "ADDRESS2", FieldIndex = 14)]
        [DisplayName("ADDRESS2")]
        public string Address2 { get; set; }

        [CsvColumn(Name = "ADDRESS3", FieldIndex = 15)]
        [DisplayName("ADDRESS3")]
        public string Address3 { get; set; }

        [CsvColumn(Name = "ADDRESS4", FieldIndex = 16)]
        [DisplayName("ADDRESS4")]
        public string Address4 { get; set; }

        [CsvColumn(Name = "ADDRESS5", FieldIndex = 17)]
        [DisplayName("ADDRESS5")]
        public string Address5 { get; set; }

        [CsvColumn(Name = "POST CODE", FieldIndex = 18)]
        [DisplayName("POST CODE")]
        public string PostCode { get; set; }
        
        [CsvColumn(Name = "E-MAIL ADDRESS", FieldIndex = 19)]
        [DisplayName("E-MAIL ADDRESS")]
        public string Email { get; set; }

        [CsvColumn(Name = "TELEPHONE NUMBER", FieldIndex = 20)]
        [DisplayName("TELEPHONE NUMBER")]
        public string Number { get; set; }

        [CsvColumn(Name = "GENDER", FieldIndex = 21)]
        [DisplayName("GENDER")]
        public string Gender { get; set; }

        [CsvColumn(Name = "MARITAL STATUS", FieldIndex = 22)]
        [DisplayName("MARITAL STATUS")]
        public string MaritalStatus { get; set; }

        [CsvColumn(Name = "DATE OF BIRTH", FieldIndex = 23)]
        [DisplayName("DATE OF BIRTH")]
        public string DOB { get; set; }

        [CsvColumn(Name = "NI NUMBER NI CATEGORY", FieldIndex = 24)]
        [DisplayName("NI NUMBER NI CATEGORY")]
        public string NiNo { get; set; }

        [CsvColumn(Name = "TAX CODE", FieldIndex = 25)]
        [DisplayName("TAX CODE")]
        public string TaxCode { get; set; }

        [CsvColumn(Name = "WK1MTH1", FieldIndex = 26)]
        [DisplayName("WK1MTH1")]
        public string Wk1Mth1 { get; set; }

        [CsvColumn(Name = "BASIS", FieldIndex = 27)]
        [DisplayName("BASIS")]
        public string Basis { get; set; }

        [CsvColumn(Name = "PENSION1", FieldIndex = 28)]
        [DisplayName("PENSION1")]
        public string Pension1 { get; set; }

        [CsvColumn(Name = "PENSION2", FieldIndex = 29)]
        [DisplayName("PENSION2")]
        public string Pension2 { get; set; }

        [CsvColumn(Name = "PENSION3", FieldIndex = 30)]
        [DisplayName("PENSION3")]
        public string Pension3 { get; set; }

        [CsvColumn(Name = "PENSION4", FieldIndex = 31)]
        [DisplayName("PENSION4")]
        public string Pension4 { get; set; }

        [CsvColumn(Name = "PENSION5", FieldIndex = 32)]
        [DisplayName("PENSION5")]
        public string Pension5 { get; set; }

        [CsvColumn(Name = "PAYMENT METHOD", FieldIndex = 33)]
        [DisplayName("PAYMENT METHOD")]
        public string PaymentMethod { get; set; }

        [CsvColumn(Name = "PAYMENT FREQUENCY", FieldIndex = 34)]
        [DisplayName("PAYMENT FREQUENCY")]
        public string PaymentFrequency { get; set; }

        [CsvColumn(Name = "GROSS SALARY", FieldIndex = 35)]
        [DisplayName("GROSS SALARY")]
        public string GrossSalary { get; set; }

        [CsvColumn(Name = "SALARY PER PERIOD", FieldIndex = 36)]
        [DisplayName("SALARY PER PERIOD")]
        public string SalaryPerPeriod { get; set; }

        [CsvColumn(Name = "CONTRACTED HOURS", FieldIndex = 37)]
        [DisplayName("CONTRACTED HOURS")]
        public string ContractedHours { get; set; }

        [CsvColumn(Name = "CONTRACTED HOURS PER PERIOD", FieldIndex = 38)]
        [DisplayName("CONTRACTED HOURS PER PERIOD")]
        public string ContractedHoursPerPeriod { get; set; }

        [CsvColumn(Name = "ACCESS LEVEL", FieldIndex = 39)]
        [DisplayName("ACCESS LEVEL")]
        public string AccessLevel { get; set; }

        [CsvColumn(Name = "DIRECTOR STATUS", FieldIndex = 40)]
        [DisplayName("DIRECTOR STATUS")]
        public string DirectorStatus { get; set; }

        [CsvColumn(Name = "DATE DIRECTORSHIP BEGAN", FieldIndex = 41)]
        [DisplayName("DATE DIRECTORSHIP BEGAN")]
        public string DirectorStatusDate { get; set; }

        [CsvColumn(Name = "NOTES", FieldIndex = 42)]
        [DisplayName("NOTES")]
        public string Notes { get; set; }

        [CsvColumn(Name = "CONTACT", FieldIndex = 43)]
        [DisplayName("CONTACT")]
        public string RefContact { get; set; }

        [CsvColumn(Name = "CONTACT RELATIONSHIP", FieldIndex = 44)]
        [DisplayName("CONTACT RELATIONSHIP")]
        public string RefContactRelation { get; set; }

        [CsvColumn(Name = "CONTACT TELEPHONE NO.", FieldIndex = 45)]
        [DisplayName("CONTACT TELEPHONE NO.")]
        public string RefContactNo { get; set; }

        [CsvColumn(Name = "BANK ACCOUNT NUMBER", FieldIndex = 46)]
        [DisplayName("BANK ACCOUNT NUMBER")]
        public string BankAcc_Number { get; set; }

        [CsvColumn(Name = "BANK ACCOUNT NAME", FieldIndex = 47)]
        [DisplayName("BANK ACCOUNT NAME")]
        public string BankAcc_Name { get; set; }

        [CsvColumn(Name = "BANK ACCOUNT TYPE", FieldIndex = 48)]
        [DisplayName("BANK ACCOUNT TYPE")]
        public string BankAcc_Type { get; set; }

        [CsvColumn(Name = "SORT CODE", FieldIndex = 49)]
        [DisplayName("SORT CODE")]
        public string SortCode { get; set; }

        [CsvColumn(Name = "BUILDING SOC NUMBER", FieldIndex = 50)]
        [DisplayName("BUILDING SOC NUMBER")]
        public string Building_Soc { get; set; }

        [CsvColumn(Name = "BACS REFERENCE", FieldIndex = 51)]
        [DisplayName("BACS REFERENCE")]
        public string BacsRef { get; set; }

        [CsvColumn(Name = "BANK NAME", FieldIndex = 52)]
        [DisplayName("BANK NAME")]
        public string BankName { get; set; }

        [CsvColumn(Name = "BANK ADDRESS 1", FieldIndex = 53)]
        [DisplayName("BANK ADDRESS 1")]
        public string BankAdd_1 { get; set; }

        [CsvColumn(Name = "BANK ADDRESS 2", FieldIndex = 54)]
        [DisplayName("BANK ADDRESS 2")]
        public string BankAdd_2 { get; set; }

        [CsvColumn(Name = "BANK ADDRESS 3", FieldIndex = 55)]
        [DisplayName("BANK ADDRESS 3")]
        public string BankAdd_3 { get; set; }

        [CsvColumn(Name = "BANK ADDRESS 4", FieldIndex = 56)]
        [DisplayName("BANK ADDRESS 4")]
        public string BankAdd_4 { get; set; }

        [CsvColumn(Name = "BANK ADDRESS 5", FieldIndex = 57)]
        [DisplayName("BANK ADDRESS 5")]
        public string BankAdd_5 { get; set; }

        [CsvColumn(Name = "BANK POSTCODE", FieldIndex = 58)]
        [DisplayName("BANK POSTCODE")]
        public string BankPostcode { get; set; }

        [CsvColumn(Name = "BANK TELEPHONE", FieldIndex = 59)]
        [DisplayName("BANK TELEPHONE")]
        public string BankTelephone { get; set; }

        [CsvColumn(Name = "BANK FAX", FieldIndex = 60)]
        [DisplayName("BANK FAX")]
        public string BankFax { get; set; }

        [CsvColumn(Name = "MOBILE NUMBER", FieldIndex = 61)]
        [DisplayName("MOBILE NUMBER")]
        public string Mobile { get; set; }

        [CsvColumn(Name = "SEND PAYSLIP VIA EMAIL", FieldIndex = 62)]
        [DisplayName("SEND PAYSLIP VIA EMAIL")]
        public string SendPayslip { get; set; }

        [CsvColumn(Name = "DATE CONFIRMED", FieldIndex = 63)]
        [DisplayName("DATE CONFIRMED")]
        public string Confirmed_Date { get; set; }

        [CsvColumn(Name = "PAYSLIP EMAIL ADDRESS", FieldIndex = 64)]
        [DisplayName("PAYSLIP EMAIL ADDRESS")]
        public string PayslipEmail { get; set; }

        [CsvColumn(Name = "PAYSLIP EMAIL Password", FieldIndex = 65)]
        [DisplayName("PAYSLIP EMAIL Password")]
        public string PayslipPassword { get; set; }
    }
}