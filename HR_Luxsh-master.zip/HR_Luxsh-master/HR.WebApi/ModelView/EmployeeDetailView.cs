﻿using System;
using System.ComponentModel.DataAnnotations;

namespace HR.WebApi.ModelView
{
    public class EmployeeDetailView
    {
        [Key]
        public int Emp_Id { get; set; }
        [Required]
        public int Company_Id { get; set; }
        [Required]
        public int Site_Id { get; set; }
        [Required]
        public int JD_Id { get; set; }
        [Required]
        public int Dept_Id { get; set; }
        [Required]
        public int Desig_Id { get; set; }
        [Required]
        public int Zone_Id { get; set; }
        [Required]
        public int Shift_Id { get; set; }
        [Required]
        public string Emp_Code { get; set; }
        [Required]
        public DateTime JoiningDate { get; set; }
        public int? Reporting_Id { get; set; }
        public Int16? isSponsored { get; set; }
        public Int16? Tupe { get; set; }
        public string NiNo { get; set; }
        public string NiCategory { get; set; }
        public int? PreviousEmp_Id { get; set; }
        public Int16? isActive { get; set; }
        public int? AddedBy { get; set; }
        public DateTime? AddedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }

        [Required]
        public string FirstName { get; set; }
        [Required]
        public string MiddleName { get; set; }
        [Required]
        public string LastName { get; set; }

        public string Company_Name { get; set; }
        public string Dept_Name { get; set; }
        public string Zone_Name { get; set; }
        public string Shift_Name { get; set; }
        public string Desig_Name { get; set; }
        public string JD_Name { get; set; }
        public string Site_Name { get; set; }
    }
}