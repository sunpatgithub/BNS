﻿using System;
using System.Collections.Generic;

namespace HR.WebApi.ModelView
{
    public class VerifyLink
    {
       
        public string login_Id { get; set; }
        public string token_No { get; set; }
        public string password { get; set; }
    }
}
