﻿using HR.WebApi.Controllers;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using HR.WebApi.ModelView;
using HR.WebApi.Repositories;
using NUnit.Framework;
using System.Linq;

namespace HR.NUnitTest.Controller
{
    [TestFixture]
    class CompanyControllerTest
    {
        public ICommonRepository<Company> companyRepository { get; set; }
        public IDocuments document { get; set; }

        public CompanyRepository<Company> companyrepo;

        private CompanyController controller;

        #region Data
        #region Correct_data
        Company Correct_data = new Company
        {
           Company_Code = "0123Test",
           Company_Name = "Test Company",
           Registration_No = "124689",
           Registration_Date = null,
           Currency = "$",
           Language = "English",
           isActive = 1,
           AddedBy = 18,
           company_contact = null
        };
        #endregion Correct_data

        #region Incorrect_Data
        Company Incorrect_Data = new Company
        {
            Company_Code = " 0123Test ",
            Company_Name = "Test Company ",
            Registration_No = "@1!124689",
            Registration_Date = null,
            Currency = "$",
            Language = "English",
            isActive = 1,
            //AddedBy = 18,
            company_contact = null
        };
        #endregion Incorrect_Data

        #region pagination
        Pagination pagination_blank = new Pagination { };

        Pagination pagination_search = new Pagination
        {
            CommonSearch = "\"Ltd\""
        };
        #endregion pagination
        #endregion Data

        [SetUp]
        public void Setup()
        {
            controller = new CompanyController(companyRepository, document, companyrepo);
        }

        [TestCase(500)]
        [Test]
        public void CompanyController_GetAll(int recordLimit)
        {
            // Arrange

            // Set up Prerequisites

            // Act on Test - For GetAll
            var response = controller.GetAll(recordLimit);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [TestCase(1)]
        [Test]
        public void CompanyController_Get(int id)
        {
            // Arrange

            // Set up Prerequisites

            // Act on Test - For Get
            var response = controller.Get(id);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [Test]
        public void CompanyController_FindPagination()
        {
            // Arrange

            // Set up Prerequisites

            // Act on Test - For FindPagination
            var response = controller.FindPagination(pagination_blank);
            //var response1 = controller.FindPagination(pagination_search);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [Test]
        public void CompanyController_Add()
        {
            // Arrange

            // Set up Prerequisites
            CheckPropertyValidation cpv = new CheckPropertyValidation();

            // Act on Test - For Add
            var response = controller.Add(Correct_data);
            var errorcount = cpv.CheckValidation(Correct_data).Count();
            var errorcount1 = cpv.CheckValidation(Incorrect_Data).Count();

            // Assert the result
            Assert.IsNotNull(response);
            Assert.AreEqual(0, errorcount, "Test Performed Successfully.");
            Assert.AreNotEqual(0, errorcount1, "Total validation error : " + errorcount1.ToString());

            Assert.Pass();
        }

        [Test]
        public void CompanyController_Edit()
        {
            // Arrange

            // Set up Prerequisites
            CheckPropertyValidation cpv = new CheckPropertyValidation();

            // Act on Test - For Edit
            var response = controller.Edit(Correct_data);
            var errorcount = cpv.CheckValidation(Correct_data);
            var errorcount1 = cpv.CheckValidation(Incorrect_Data);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.AreEqual(0, errorcount.Count, "Test Performed Successfully.");
            Assert.AreNotEqual(0, errorcount1.Count, "Total validation error : " + errorcount1.Count.ToString());

            Assert.Pass();
        }

        [TestCase(1,0)]
        [Test]
        public void CompanyController_UpdateStatus(int id, short isActive)
        {
            // Arrange

            // Set up Prerequisites

            // Act on Test - For UpdateStatus
            var response = controller.UpdateStatus(id,isActive);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [TestCase(1)]
        [Test]
        public void CompanyController_delete(int id)
        {
            // Arrange

            // Set up Prerequisites

            // Act on Test - For Delete
            var response = controller.Delete(id);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }
    }
}
