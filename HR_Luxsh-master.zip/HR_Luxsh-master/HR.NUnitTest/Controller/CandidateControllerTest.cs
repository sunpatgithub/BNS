﻿using HR.WebApi.Controllers;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using HR.WebApi.ModelView;
using NUnit.Framework;
using System;
 

namespace HR.NUnitTest.Controller
{
    [TestFixture]
    class CandidateControllerTest
    {
        public ICommonRepository<Candidate> CandidateRepository { get; set; }
        private CandidateController controller;

        #region Data
        #region Correct_data
        Candidate Correct_data = new Candidate
        {
            FirstName = "Test",
            MiddleName = "Test",
            LastName = "Test",
            EMail = "Test@Test.com",
            TotalExperience = "2 years",
            JobStartDate = Convert.ToDateTime("2020-04-25 00:00:00"),
            Mobile = "6549875246",
            ReferenceBy = 2,
            ReferenceFrom = "abc",
            //Notes = "Something",
            AddedBy = 18,
        };
        #endregion Correct_data

        #region Incorrect_Data
        Candidate Incorrect_Data = new Candidate
        {
            FirstName = "Te st",
            MiddleName = "T",
            LastName = "Te st",
            EMail = "Test@ Test.com",
            TotalExperience = "2 years",
            JobStartDate = Convert.ToDateTime("2020-04-25 00:00:00"),
            Mobile = "+1234567890",
            ReferenceBy = 2,
            ReferenceFrom = "abc",
            AddedBy = 18,
        };
        #endregion Incorrect_Data

        #region pagination
        Pagination pagination_blank = new Pagination { };

        Pagination pagination_search = new Pagination
        {
            CommonSearch = "\"Ankit\""
        };
        #endregion pagination
        #endregion Data

        [SetUp]
        public void Setup()
        {
            controller = new CandidateController(CandidateRepository);
        }

        [TestCase(500)]
        [Test]
        public void CandidateController_GetAll(int recordLimit)
        {
            // Arrange

            // Set up Prerequisites

            // Act on Test - For Post
            var response = controller.GetAll(recordLimit);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [TestCase(1)]
        [Test]
        public void CandidateController_Get(int id)
        {
            // Arrange

            // Set up Prerequisites

            // Act on Test - For Post
            var response = controller.Get(id);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [Test]
        public void CandidateController_FindPagination()
        {
            // Arrange

            // Set up Prerequisites
           
            // Act on Test - For FindPagination
            var response = controller.FindPagination(pagination_blank);
            //var response1 = controller.FindPagination(pagination_search);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [Test]
        public void CandidateController_Add()
        {
            // Arrange

            // Set up Prerequisites
            CheckPropertyValidation cpv = new CheckPropertyValidation();
            var controller = new CandidateController(CandidateRepository);
            // Act on Test - For Post
            var response = controller.Add(Correct_data);
            var errorcount = cpv.CheckValidation(Correct_data).Count;
            var errorcount1 = cpv.CheckValidation(Incorrect_Data).Count;

            // Assert the result
            Assert.IsNotNull(response);
            Assert.AreEqual(0, errorcount, "Data Inserted Successfully.");
            Assert.AreNotEqual(0, errorcount1,"Total validation error : "+ errorcount1.ToString());

            //Assert.Pass();
        }

        [TestCase(1)]
        [Test]
        public void CandidateController_delete(int id)
        {
            // Arrange

            // Set up Prerequisites
            
            // Act on Test - For Delete
            var response = controller.Delete(id);

            // Assert the result
            Assert.IsNotNull(response);
            //Assert.Pass();
        }


    }
}
