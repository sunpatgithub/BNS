﻿using HR.WebApi.Controllers;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using HR.WebApi.ModelView;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HR.NUnitTest.Controller
{
    class Employee_RightToWorkControllerTest
    {
        public ICommonRepository<Employee_RightToWork> employee_RightToWorkRepository { get; set; }
        public IPaginated<Employee_RightToWorkView> paginatedQueryRepo { get; set; }

        #region Correct_data
        Employee_RightToWork employee_RightToWork = new Employee_RightToWork
        {
            Emp_Id = 1,
            RWC_Id= 1,
            IssueDate= Convert.ToDateTime("2020-04-25 00:00:00"),
            IssueAuthority= "Admin",
            IssueCountry= "Indian",
            ExpiryDate= Convert.ToDateTime("2021-04-25 00:00:00"),           
            Notes= "no resone",
            Emp_Doc_Id = 1,
            isActive = 1,
            AddedBy = 28,
            AddedOn = DateTime.Now,
            UpdatedBy = 28,
            UpdatedOn = DateTime.Now
        };
        #endregion

        #region data_with_space
        Employee_RightToWork employee_space = new Employee_RightToWork
        {
            Emp_Id = 1,
            RWC_Id = 1,
            IssueDate = Convert.ToDateTime("2020-04-25 00:00:00"),
            IssueAuthority = "Admin ",
            IssueCountry = "Indian ",
            ExpiryDate = Convert.ToDateTime("2021-04-25 00:00:00"),
            Notes = "no resone",
            Emp_Doc_Id = 1,
            isActive = 1,
            AddedBy = 28,
            AddedOn = DateTime.Now,
            UpdatedBy = 28,
            UpdatedOn = DateTime.Now
        };
        #endregion 

        #region data_with_RegularExpression
        Employee_RightToWork employee_RegularExpression = new Employee_RightToWork
        {
            Emp_Id = 1,
            RWC_Id = 1,
            IssueDate = Convert.ToDateTime("2020-04-25 00:00:00"),
            IssueAuthority = "Admin@#",
            IssueCountry = "Indian",
            ExpiryDate = Convert.ToDateTime("2021-04-25 00:00:00"),
            Notes = "no resone",
            Emp_Doc_Id = 1,
            isActive = 1,
            AddedBy = 28,
            AddedOn = DateTime.Now,
            UpdatedBy = 28,
            UpdatedOn = DateTime.Now
        };
        #endregion 

        #region pagination
        Pagination pagination_blank = new Pagination { };

        Pagination pagination_search = new Pagination
        {
            CommonSearch = "\"Home\""
        };
        #endregion pagination

        [SetUp]
        public void Setup()
        {
        }

        [TestCase(500)]
        [Test]
        public void Employee_RightToWorkController_GetAll(int recordLimit)
        {
            // Arrange
            
            // Set up Prerequisites
            var controller = new Employee_RightToWorkController(employee_RightToWorkRepository, paginatedQueryRepo);

            // Act on Test - For GetAll
            var response = controller.GetAll(recordLimit);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [TestCase(1)]
        [Test]
        public void Employee_RightToWorkController_Get(int id)
        {
            // Arrange
           
            // Set up Prerequisites
            var controller = new Employee_RightToWorkController(employee_RightToWorkRepository, paginatedQueryRepo);

            // Act on Test - For Get
            var response = controller.Get(id);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [Test]
        public void Employee_RightToWorkController_Get_FindPagination()
        {
            // Arrange

            // Set up Prerequisites
            var controller = new Employee_RightToWorkController(employee_RightToWorkRepository, paginatedQueryRepo);

            // Act on Test - For FindPagination
            var response = controller.FindPagination(pagination_blank);
            //var response1 = controller.FindPagination(pagination_search);

            // Assert the result
            Assert.IsNotNull(response);
            //Assert.IsNotNull(response1);
            Assert.Pass();
        }

        //[Test]
        //public void Employee_RightToWorkController_GetBy(PaginationBy searchBy)
        //{
        //    // Arrange

        //    // Set up Prerequisites
        //    var controller = new Employee_RightToWorkController(employee_AddressRepository, paginatedQueryRepo);

        //    // Act on Test - For Get
        //    var response = controller.GetBy(searchBy);

        //    // Assert the result
        //    Assert.IsNotNull(response);
        //}

        [Test]
        public void Employee_RightToWorkController_Add()
        {
            // Arrange

            #region Check Validation

            // Act
            var validationResults = new List<ValidationResult>();
            var actual = Validator.TryValidateObject(employee_RightToWork, new ValidationContext(employee_RightToWork), validationResults, true);

            // Assert
            Assert.IsTrue(actual, "Expected validation to succeed.");
            Assert.AreEqual(0, validationResults.Count, "Unexpected number of validation errors.");
            #endregion

            // Set up Prerequisites
            var controller = new Employee_RightToWorkController(employee_RightToWorkRepository, paginatedQueryRepo);

            // Act on Test - For Edit
            var response = controller.Add(employee_RightToWork);

            // Assert the result
            Assert.IsNotNull(response);

            Assert.Pass();
        }

        [Test]
        public void Employee_RightToWorkController_Edit()
        {
            // Arrange

            #region Check Validation

            // Act
            var validationResults = new List<ValidationResult>();
            var actual = Validator.TryValidateObject(employee_RightToWork, new ValidationContext(employee_RightToWork), validationResults, true);

            // Assert
            Assert.IsTrue(actual, "Expected validation to succeed.");
            Assert.AreEqual(0, validationResults.Count, "Unexpected number of validation errors.");
            #endregion

            // Set up Prerequisites
            var controller = new Employee_RightToWorkController(employee_RightToWorkRepository, paginatedQueryRepo);

            // Act on Test - For Edit
            var response = controller.Edit(employee_RightToWork);

            // Assert the result
            Assert.IsNotNull(response);

            Assert.Pass();
        }


        [Test]
        public void Employee_RightToWorkController_UpdateStatus()
        {
            // Arrange
            int id = 0;
            short isActive = 1;
            // Set up Prerequisites
            var controller = new Employee_RightToWorkController(employee_RightToWorkRepository, paginatedQueryRepo);

            // Act on Test - For UpdateStatus
            var response = controller.UpdateStatus(id, isActive);

            // Assert the result
            Assert.IsNotNull(response);
        }
        [Test]
        public void Employee_RightToWorkController_Delete()
        {
            // Arrange
            int id = 0;
            // Set up Prerequisites
            var controller = new Employee_RightToWorkController(employee_RightToWorkRepository, paginatedQueryRepo);

            // Act on Test - For Delete
            var response = controller.Delete(id);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }
    }
}
