﻿using HR.WebApi.Controllers;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using HR.WebApi.ModelView;
using NUnit.Framework;

namespace HR.NUnitTest.Controller
{
    [TestFixture]
    class EthinicityControllerTest
    {
        private ICommonRepository<Ethinicity> EthinicityRepository { get; set; }
       
        private EthinicityController controller;

        #region Data
        #region Correct_data
        Ethinicity Correct_data = new Ethinicity
        {
            Ethnicity_Code = "TestCase",
            Ethnicity_Name = "Test Case",
            Language = "English",
            Notes = "not available",
            isActive = 1,
            AddedBy = 18
        };
        #endregion Correct_data

        #region Incorrect_Data
        Ethinicity Incorrect_Data = new Ethinicity
        {
            Ethnicity_Code = " TestCase",
            Ethnicity_Name = "Test&Case  ",
            Language = "En glish",
            Notes = "not available",
            isActive = 10,
            AddedBy = 18
        };
        #endregion Incorrect_Data

        #region pagination
        Pagination pagination_blank = new Pagination { };

        Pagination pagination_search = new Pagination
        {
            CommonSearch = "\"email\""
        };
        #endregion pagination
        #endregion Data

        [SetUp]
        public void Setup()
        {
            controller = new EthinicityController(EthinicityRepository);
        }

        [TestCase(500)]
        [Test]
        public void EthinicityRepository_GetAll(int recordLimit)
        {
            // Arrange

            // Set up Prerequisites

            // Act on Test - For GetAll
            var response = controller.GetAll(recordLimit);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [TestCase(1)]
        [Test]
        public void EthinicityRepository_Get(int id)
        {
            // Arrange

            // Set up Prerequisites

            // Act on Test - For Get
            var response = controller.Get(id);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [Test]
        public void EthinicityRepository_FindPagination()
        {
            // Arrange

            // Set up Prerequisites

            // Act on Test - For FindPagination
            var response = controller.FindPagination(pagination_blank);
            //var response1 = controller.FindPagination(pagination_search);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [Test]
        public void EthinicityRepository_Add()
        {
            // Arrange

            // Set up Prerequisites
            CheckPropertyValidation cpv = new CheckPropertyValidation();

            // Act on Test - For Add
            var response = controller.Add(Correct_data);
            var errorcount = cpv.CheckValidation(Correct_data);
            var errorcount1 = cpv.CheckValidation(Incorrect_Data);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.AreEqual(0, errorcount.Count, "Test Performed Successfully.");
            Assert.AreNotEqual(0, errorcount1.Count, "Total validation error : " + errorcount1.Count.ToString());

            Assert.Pass();
        }

        [Test]
        public void EthinicityRepository_Edit()
        {
            // Arrange

            // Set up Prerequisites
            CheckPropertyValidation cpv = new CheckPropertyValidation();

            // Act on Test - For Edit
            var response = controller.Edit(Correct_data);
            var errorcount = cpv.CheckValidation(Correct_data);
            var errorcount1 = cpv.CheckValidation(Incorrect_Data);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.AreEqual(0, errorcount.Count, "Test Performed Successfully.");
            Assert.AreNotEqual(0, errorcount1.Count, "Total validation error : " + errorcount1.Count.ToString());

            Assert.Pass();
        }

        [TestCase(1, 0)]
        [Test]
        public void EthinicityRepository_UpdateStatus(int id, short isActive)
        {
            // Arrange

            // Set up Prerequisites

            // Act on Test - For UpdateStatus
            var response = controller.UpdateStatus(id, isActive);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [TestCase(1)]
        [Test]
        public void EthinicityRepository_delete(int id)
        {
            // Arrange

            // Set up Prerequisites

            // Act on Test - For Delete
            var response = controller.Delete(id);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }
    }
}
