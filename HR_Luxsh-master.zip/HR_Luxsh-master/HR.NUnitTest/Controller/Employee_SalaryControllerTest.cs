﻿using HR.WebApi.Controllers;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using HR.WebApi.ModelView;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HR.NUnitTest.Controller
{
    class Employee_SalaryControllerTest
    {
        public ICommonRepository<Employee_Salary> employee_SalaryRepository { get; set; }
        public IPaginated<Employee_Salary> paginatedQueryRepo { get; set; }

        #region Correct_data
        Employee_Salary employee_Salary = new Employee_Salary
        {
            Emp_Id = 1,
            Company_Id= 1,
            Dept_Id= 1,
            Desig_Id= 1,
            ApprisalFrom= Convert.ToDateTime("2020-01-01 00:00:00"),
            ApprisalTo= Convert.ToDateTime("2020-01-01 00:00:00"),
            Salary= "630000",
            Reporting_Id= 1,
            isActive = 1,
            AddedBy = 28,
            AddedOn = DateTime.Now,
            UpdatedBy = 28,
            UpdatedOn = DateTime.Now
        };
        #endregion

        #region data_with_space
        Employee_Salary employee_space = new Employee_Salary
        {
            Emp_Id = 1,
            Company_Id = 1,
            Dept_Id = 1,
            Desig_Id = 1,
            ApprisalFrom = Convert.ToDateTime("2020-01-01 00:00:00"),
            ApprisalTo = Convert.ToDateTime("2020-01-01 00:00:00"),
            Salary = "630000 ",
            Reporting_Id = 1,
            isActive = 1,
            AddedBy = 28,
            AddedOn = DateTime.Now,
            UpdatedBy = 28,
            UpdatedOn = DateTime.Now
        };
        #endregion 

        #region data_with_RegularExpression
        Employee_Salary employee_RegularExpression = new Employee_Salary
        {
            Emp_Id = 1,
            Company_Id = 1,
            Dept_Id = 1,
            Desig_Id = 1,
            ApprisalFrom = Convert.ToDateTime("2020-01-01 00:00:00"),
            ApprisalTo = Convert.ToDateTime("2020-01-01 00:00:00"),
            Salary = "630000$#",
            Reporting_Id = 1,
            isActive = 1,
            AddedBy = 28,
            AddedOn = DateTime.Now,
            UpdatedBy = 28,
            UpdatedOn = DateTime.Now
        };
        #endregion 

        #region pagination
        Pagination pagination_blank = new Pagination { };

        Pagination pagination_search = new Pagination
        {
            CommonSearch = "\"630000\""
        };
        #endregion pagination

        [SetUp]
        public void Setup()
        {
        }

        [TestCase(500)]
        [Test]
        public void Employee_SalaryController_GetAll(int recordLimit)
        {
            // Arrange
             
            // Set up Prerequisites
            var controller = new Employee_SalaryController(employee_SalaryRepository, paginatedQueryRepo);

            // Act on Test - For GetAll
            var response = controller.GetAll(recordLimit);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [TestCase(1)]
        [Test]
        public void Employee_SalaryController_Get(int id)
        {
            // Arrange
             
            // Set up Prerequisites
            var controller = new Employee_SalaryController(employee_SalaryRepository, paginatedQueryRepo);

            // Act on Test - For Get
            var response = controller.Get(id);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [Test]
        public void Employee_SalaryController_Get_FindPagination()
        {
            // Arrange

            // Set up Prerequisites
            var controller = new Employee_SalaryController(employee_SalaryRepository, paginatedQueryRepo);

            // Act on Test - For FindPagination
            var response = controller.FindPagination(pagination_blank);
            //var response1 = controller.FindPagination(pagination_search);

            // Assert the result
            Assert.IsNotNull(response);
            //Assert.IsNotNull(response1);
            Assert.Pass();
        }

        //[Test]
        //public void Employee_SalaryController_GetBy(PaginationBy searchBy)
        //{
        //    // Arrange

        //    // Set up Prerequisites
        //    var controller = new Employee_SalaryController(employee_AddressRepository, paginatedQueryRepo);

        //    // Act on Test - For Get
        //    var response = controller.GetBy(searchBy);

        //    // Assert the result
        //    Assert.IsNotNull(response);
        //}

        [Test]
        public void Employee_SalaryController_Add()
        {
            // Arrange

            #region Check Validation

            // Act
            var validationResults = new List<ValidationResult>();
            var actual = Validator.TryValidateObject(employee_Salary, new ValidationContext(employee_Salary), validationResults, true);

            // Assert
            Assert.IsTrue(actual, "Expected validation to succeed.");
            Assert.AreEqual(0, validationResults.Count, "Unexpected number of validation errors.");
            #endregion

            // Set up Prerequisites
            var controller = new Employee_SalaryController(employee_SalaryRepository, paginatedQueryRepo);

            // Act on Test - For Edit
            var response = controller.Add(employee_Salary);

            // Assert the result
            Assert.IsNotNull(response);

            Assert.Pass();
        }

        [Test]
        public void Employee_SalaryController_Edit()
        {
            // Arrange

            #region Check Validation

            // Act
            var validationResults = new List<ValidationResult>();
            var actual = Validator.TryValidateObject(employee_Salary, new ValidationContext(employee_Salary), validationResults, true);

            // Assert
            Assert.IsTrue(actual, "Expected validation to succeed.");
            Assert.AreEqual(0, validationResults.Count, "Unexpected number of validation errors.");
            #endregion

            // Set up Prerequisites
            var controller = new Employee_SalaryController(employee_SalaryRepository, paginatedQueryRepo);

            // Act on Test - For Edit
            var response = controller.Edit(employee_Salary);

            // Assert the result
            Assert.IsNotNull(response);

            Assert.Pass();
        }


        [Test]
        public void Employee_SalaryController_UpdateStatus()
        {
            // Arrange
            int id = 0;
            short isActive = 1;
            // Set up Prerequisites
            var controller = new Employee_SalaryController(employee_SalaryRepository, paginatedQueryRepo);

            // Act on Test - For UpdateStatus
            var response = controller.UpdateStatus(id, isActive);

            // Assert the result
            Assert.IsNotNull(response);
        }
        [Test]
        public void Employee_SalaryController_Delete()
        {
            // Arrange
            int id = 0;
            // Set up Prerequisites
            var controller = new Employee_SalaryController(employee_SalaryRepository, paginatedQueryRepo);

            // Act on Test - For Delete
            var response = controller.Delete(id);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }
    }
}
