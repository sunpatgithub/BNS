﻿using HR.WebApi.Controllers;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using HR.WebApi.ModelView;
using NUnit.Framework;
using System.Linq;

namespace HR.NUnitTest.Controller
{
    [TestFixture]
    class Contract_ControllerTest
    {
        private ICommonRepository<ContractView> ContractRepository { get; set; }
        private ICommonQuery<ContractView> commonQueryRepo { get; set; }

        private ContractController controller;

        #region Data
        #region Correct_data
        ContractView Correct_data = new ContractView
        {
            Company_Id = 1,
            Contract_Code = "Test123",
            Contract_Name = "Test 123",
            Contract_HoursDaily = 8,
            Contract_HoursWeekly = 40,
            Contract_Days = "1 year",
            Contract_Type = "Temporary",
            isActive = 1,
            AddedBy = 18
        };
        #endregion Correct_data

        #region Incorrect_Data
        ContractView Incorrect_Data = new ContractView
        {
            //Company_Id = 1,
            Contract_Code = "Test1 23",
            Contract_Name = " Test 123",
            Contract_HoursDaily = 8,
            Contract_HoursWeekly = 40,
            Contract_Days = "1 year ",
            Contract_Type = "Temporary ",
            isActive = 10,
            AddedBy = 18
        };
        #endregion Incorrect_Data

        #region pagination
        Pagination pagination_blank = new Pagination { };

        Pagination pagination_search = new Pagination
        {
            CommonSearch = "\"email\""
        };
        #endregion pagination
        #endregion Data

        [SetUp]
        public void Setup()
        {
            controller = new ContractController(ContractRepository, commonQueryRepo);
        }

        [TestCase(500)]
        [Test]
        public void ContractRepository_GetAll(int recordLimit)
        {
            // Arrange

            // Set up Prerequisites

            // Act on Test - For GetAll
            var response = controller.GetAll(recordLimit);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [TestCase(1)]
        [Test]
        public void ContractRepository_Get(int id)
        {
            // Arrange

            // Set up Prerequisites

            // Act on Test - For Get
            var response = controller.Get(id);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [Test]
        public void ContractRepository_FindPagination()
        {
            // Arrange

            // Set up Prerequisites

            // Act on Test - For FindPagination
            var response = controller.FindPagination(pagination_blank);
            //var response1 = controller.FindPagination(pagination_search);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [Test]
        public void ContractRepository_Add()
        {
            // Arrange

            // Set up Prerequisites
            CheckPropertyValidation cpv = new CheckPropertyValidation();

            // Act on Test - For Add
            var response = controller.Add(Correct_data);
            var errorcount = cpv.CheckValidation(Correct_data);
            var errorcount1 = cpv.CheckValidation(Incorrect_Data);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.AreEqual(0, errorcount.Count, "Test Performed Successfully.");
            Assert.AreNotEqual(0, errorcount1.Count, "Total validation error : " + errorcount1.Count.ToString());

            Assert.Pass();
        }

        [Test]
        public void ContractRepository_Edit()
        {
            // Arrange

            // Set up Prerequisites
            CheckPropertyValidation cpv = new CheckPropertyValidation();

            // Act on Test - For Edit
            var response = controller.Edit(Correct_data);
            var errorcount = cpv.CheckValidation(Correct_data);
            var errorcount1 = cpv.CheckValidation(Incorrect_Data);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.AreEqual(0, errorcount.Count, "Test Performed Successfully.");
            Assert.AreNotEqual(0, errorcount1.Count, "Total validation error : " + errorcount1.Count.ToString());

            Assert.Pass();
        }

        [TestCase(1, 0)]
        [Test]
        public void ContractRepository_UpdateStatus(int id, short isActive)
        {
            // Arrange

            // Set up Prerequisites

            // Act on Test - For UpdateStatus
            var response = controller.UpdateStatus(id, isActive);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [TestCase(1)]
        [Test]
        public void ContractRepository_delete(int id)
        {
            // Arrange

            // Set up Prerequisites

            // Act on Test - For Delete
            var response = controller.Delete(id);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }
    }
}
