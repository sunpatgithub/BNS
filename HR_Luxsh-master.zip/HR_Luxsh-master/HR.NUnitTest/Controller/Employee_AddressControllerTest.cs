﻿using HR.WebApi.Controllers;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using HR.WebApi.ModelView;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HR.NUnitTest.Controller
{
    class Employee_AddressControllerTest
    {
        public ICommonRepository<Employee_Address> employee_AddressRepository { get; set; }
        public IPaginated<Employee_AddressView> paginatedQueryRepo { get; set; }

        #region Correct_data
        Employee_Address employee_Address = new Employee_Address
        {
            Emp_Id = 1,
            Address_Type = "Home",
            Address1 = "Karelibaug",
            Address2 = null,
            Address3 = null,
            Address4 = null,
            PostCode = "3900060",
            City = "Vadodara",
            State = "Gujarat",
            Country = "India",
            LandlineNo = "988776546",
            isDefault = 1,
            Emp_Doc_Id = 1,
            isActive = 1,
            AddedBy = 28,
            AddedOn = DateTime.Now,
            UpdatedBy = 28,
            UpdatedOn = DateTime.Now
        };
        #endregion

        #region data_with_space
        Employee_Address employee_space = new Employee_Address
        {
            Emp_Id = 1,
            Address_Type = "Home",
            Address1 = "Karelibaug",
            Address2 = string.Empty,
            Address3 = string.Empty,
            Address4 = string.Empty,
            PostCode = "3900060",
            City = "Vadodara",
            State = "Gujarat",
            Country = "India",
            LandlineNo = " 9887765467 ",
            isDefault = 0,
            Emp_Doc_Id = 0,
            isActive = 1,
            AddedBy = 28,
            AddedOn = DateTime.Now,
            UpdatedBy = 28,
            UpdatedOn = DateTime.Now
        };
        #endregion 

        #region data_with_RegularExpression
        Employee_Address employee_RegularExpression = new Employee_Address
        {
            Emp_Id = 1,
            Address_Type = "Home",
            Address1 = "Karelibaug",
            Address2 = string.Empty,
            Address3 = string.Empty,
            Address4 = string.Empty,
            PostCode = "3900060",
            City = "Vadodara",
            State = "Gujarat",
            Country = "India",
            LandlineNo = "9887765467@",
            isDefault = 0,
            Emp_Doc_Id = 0,
            isActive = 1,
            AddedBy = 28,
            AddedOn = DateTime.Now,
            UpdatedBy = 28,
            UpdatedOn = DateTime.Now
        };
        #endregion 

        #region pagination
        Pagination pagination_blank = new Pagination { };

        Pagination pagination_search = new Pagination
        {
            CommonSearch = "\"Home\""
        };
        #endregion pagination

        [SetUp]
        public void Setup()
        {
        }

        [TestCase(500)]
        [Test]
        public void Employee_AddressController_GetAll(int recordLimit)
        {
            // Arrange
            //int recordLimit = 100;
            // Set up Prerequisites
            var controller = new Employee_AddressController(employee_AddressRepository, paginatedQueryRepo);

            // Act on Test - For GetAll
            var response = controller.GetAll(recordLimit);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [TestCase(1)]
        [Test]
        public void Employee_AddressController_Get(int id)
        {
            // Arrange
            //int id = 1;
            // Set up Prerequisites
            var controller = new Employee_AddressController(employee_AddressRepository, paginatedQueryRepo);

            // Act on Test - For Get
            var response = controller.Get(id);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [Test]
        public void Employee_AddressController_Get_FindPagination()
        {
            // Arrange

            // Set up Prerequisites
            var controller = new Employee_AddressController(employee_AddressRepository, paginatedQueryRepo);

            // Act on Test - For FindPagination
            var response = controller.FindPagination(pagination_blank);
            //var response1 = controller.FindPagination(pagination_search);

            // Assert the result
            Assert.IsNotNull(response);
            //Assert.IsNotNull(response1);
            Assert.Pass();
        }

        //[Test]
        //public void Employee_AddressController_GetBy(PaginationBy searchBy)
        //{
        //    // Arrange

        //    // Set up Prerequisites
        //    var controller = new Employee_AddressController(employee_AddressRepository, paginatedQueryRepo);

        //    // Act on Test - For Get
        //    var response = controller.GetBy(searchBy);

        //    // Assert the result
        //    Assert.IsNotNull(response);
        //}

        [Test]
        public void Employee_AddressController_Add()
        {
            // Arrange

            #region Check Validation

            // Act
            var validationResults = new List<ValidationResult>();
            var actual = Validator.TryValidateObject(employee_Address, new ValidationContext(employee_Address), validationResults, true);

            // Assert
            Assert.IsTrue(actual, "Expected validation to succeed.");
            Assert.AreEqual(0, validationResults.Count, "Unexpected number of validation errors.");
            #endregion

            // Set up Prerequisites
            var controller = new Employee_AddressController(employee_AddressRepository, paginatedQueryRepo);

            // Act on Test - For Edit
            var response = controller.Add(employee_Address);

            // Assert the result
            Assert.IsNotNull(response);

            Assert.Pass();
        }

        [Test]
        public void Employee_AddressController_Edit()
        {
            // Arrange

            #region Check Validation

            // Act
            var validationResults = new List<ValidationResult>();
            var actual = Validator.TryValidateObject(employee_Address, new ValidationContext(employee_Address), validationResults, true);

            // Assert
            Assert.IsTrue(actual, "Expected validation to succeed.");
            Assert.AreEqual(0, validationResults.Count, "Unexpected number of validation errors.");
            #endregion

            // Set up Prerequisites
            var controller = new Employee_AddressController(employee_AddressRepository, paginatedQueryRepo);

            // Act on Test - For Edit
            var response = controller.Edit(employee_Address);

            // Assert the result
            Assert.IsNotNull(response);

            Assert.Pass();
        }


        [Test]
        public void Employee_AddressController_UpdateStatus()
        {
            // Arrange
            int id = 0;
            short isActive = 1;
            // Set up Prerequisites
            var controller = new Employee_AddressController(employee_AddressRepository, paginatedQueryRepo);

            // Act on Test - For UpdateStatus
            var response = controller.UpdateStatus(id, isActive);

            // Assert the result
            Assert.IsNotNull(response);
        }
        [Test]
        public void Employee_AddressController_Delete()
        {
            // Arrange
            int id = 0;
            // Set up Prerequisites
            var controller = new Employee_AddressController(employee_AddressRepository, paginatedQueryRepo);

            // Act on Test - For Delete
            var response = controller.Delete(id);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

    }
}
