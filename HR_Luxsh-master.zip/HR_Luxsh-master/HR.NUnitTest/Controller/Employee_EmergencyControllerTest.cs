﻿using HR.WebApi.Controllers;
using HR.WebApi.Interfaces;
using HR.WebApi.Model;
using HR.WebApi.ModelView;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
namespace HR.NUnitTest.Controller
{
    class Employee_EmergencyControllerTest
    {
        public ICommonRepository<Employee_Emergency> employee_EmergencyRepository { get; set; }
        public IPaginated<Employee_EmergencyView> paginatedQueryRepo { get; set; }

        #region Correct_data
        Employee_Emergency employee_Emergency = new Employee_Emergency
        {
            Emp_Id = 1,
            ContactName= "Mona",
            ContactNo= "1234567899",
            Relationship= "Mother",
            isDefault= 0,
            isActive = 1,
            AddedBy = 28,
            AddedOn = DateTime.Now,
            UpdatedBy = 28,
            UpdatedOn = DateTime.Now
        };
        #endregion

        #region data_with_space
        Employee_Emergency employee_space = new Employee_Emergency
        {
            Emp_Id = 1,
            ContactName = "Mona",
            ContactNo = "1234567899 ",
            Relationship = "Mother",
            isDefault = 0,
            isActive = 1,
            AddedBy = 28,
            AddedOn = DateTime.Now,
            UpdatedBy = 28,
            UpdatedOn = DateTime.Now
        };
        #endregion 

        #region data_with_RegularExpression
        Employee_Emergency employee_RegularExpression = new Employee_Emergency
        {
            Emp_Id = 1,
            ContactName = "Mona",
            ContactNo = "1234567899*",
            Relationship = "Mother",
            isDefault = 0,
            isActive = 1,
            AddedBy = 28,
            AddedOn = DateTime.Now,
            UpdatedBy = 28,
            UpdatedOn = DateTime.Now
        };
        #endregion 

        #region pagination
        Pagination pagination_blank = new Pagination { };

        Pagination pagination_search = new Pagination
        {
            CommonSearch = "\"Mona\""
        };
        #endregion pagination

        [SetUp]
        public void Setup()
        {
        }

        [TestCase(500)]
        [Test]
        public void Employee_EmergencyController_GetAll(int recordLimit)
        {
            // Arrange
             
            // Set up Prerequisites
            var controller = new Employee_EmergencyController(employee_EmergencyRepository, paginatedQueryRepo);

            // Act on Test - For GetAll
            var response = controller.GetAll(recordLimit);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [TestCase(1)]
        [Test]
        public void Employee_EmergencyController_Get(int id)
        {
            // Arrange
            
            // Set up Prerequisites
            var controller = new Employee_EmergencyController(employee_EmergencyRepository, paginatedQueryRepo);

            // Act on Test - For Get
            var response = controller.Get(id);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }

        [Test]
        public void Employee_EmergencyController_Get_FindPagination()
        {
            // Arrange

            // Set up Prerequisites
            var controller = new Employee_EmergencyController(employee_EmergencyRepository, paginatedQueryRepo);

            // Act on Test - For FindPagination
            var response = controller.FindPagination(pagination_blank);
            //var response1 = controller.FindPagination(pagination_search);

            // Assert the result
            Assert.IsNotNull(response);
            //Assert.IsNotNull(response1);
            Assert.Pass();
        }

        //[Test]
        //public void Employee_EmergencyController_GetBy(PaginationBy searchBy)
        //{
        //    // Arrange

        //    // Set up Prerequisites
        //    var controller = new Employee_EmergencyController(employee_AddressRepository, paginatedQueryRepo);

        //    // Act on Test - For Get
        //    var response = controller.GetBy(searchBy);

        //    // Assert the result
        //    Assert.IsNotNull(response);
        //}

        [Test]
        public void Employee_EmergencyController_Add()
        {
            // Arrange

            #region Check Validation

            // Act
            var validationResults = new List<ValidationResult>();
            var actual = Validator.TryValidateObject(employee_Emergency, new ValidationContext(employee_Emergency), validationResults, true);

            // Assert
            Assert.IsTrue(actual, "Expected validation to succeed.");
            Assert.AreEqual(0, validationResults.Count, "Unexpected number of validation errors.");
            #endregion

            // Set up Prerequisites
            var controller = new Employee_EmergencyController(employee_EmergencyRepository, paginatedQueryRepo);

            // Act on Test - For Edit
            var response = controller.Add(employee_Emergency);

            // Assert the result
            Assert.IsNotNull(response);

            Assert.Pass();
        }

        [Test]
        public void Employee_EmergencyController_Edit()
        {
            // Arrange

            #region Check Validation

            // Act
            var validationResults = new List<ValidationResult>();
            var actual = Validator.TryValidateObject(employee_Emergency, new ValidationContext(employee_Emergency), validationResults, true);

            // Assert
            Assert.IsTrue(actual, "Expected validation to succeed.");
            Assert.AreEqual(0, validationResults.Count, "Unexpected number of validation errors.");
            #endregion

            // Set up Prerequisites
            var controller = new Employee_EmergencyController(employee_EmergencyRepository, paginatedQueryRepo);

            // Act on Test - For Edit
            var response = controller.Edit(employee_Emergency);

            // Assert the result
            Assert.IsNotNull(response);

            Assert.Pass();
        }


        [Test]
        public void Employee_EmergencyController_UpdateStatus()
        {
            // Arrange
            int id = 0;
            short isActive = 1;
            // Set up Prerequisites
            var controller = new Employee_EmergencyController(employee_EmergencyRepository, paginatedQueryRepo);

            // Act on Test - For UpdateStatus
            var response = controller.UpdateStatus(id, isActive);

            // Assert the result
            Assert.IsNotNull(response);
        }
        [Test]
        public void Employee_EmergencyController_Delete()
        {
            // Arrange
            int id = 0;
            // Set up Prerequisites
            var controller = new Employee_EmergencyController(employee_EmergencyRepository, paginatedQueryRepo);

            // Act on Test - For Delete
            var response = controller.Delete(id);

            // Assert the result
            Assert.IsNotNull(response);
            Assert.Pass();
        }
    }
}
